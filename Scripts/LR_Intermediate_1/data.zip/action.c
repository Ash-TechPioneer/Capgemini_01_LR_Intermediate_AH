Action()
{

	web_url("Catalog.action", 
		"URL=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("rxVisitorf4o018pw=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R; DOMAIN=localhost");

	web_add_cookie("dtSaf4o018pw=-; DOMAIN=localhost");

	web_add_cookie("rxvtf4o018pw=1779552953842|1779551153758; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=1$551153752_668h-vPVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3890200641&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"1%7C1%7C_load_%7C_load_%7C-%7C1779551141884%7C1779551153844%7Cdn%7C89%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C3%7C_event_%7C1779551141884%7C_vc_%7CV%7C11915%5Epc%7CVCD%7C1015%7CVCDS%7C1%7CVCS%7C12024%7CVCO%7C13031%7CVCI%7C0%7CTS%7C0%7CVE%7C654%5Ep106%5Ep124250%5Eps%5Es%23MainImageContent%3Eimg%3Anth-child%282%29%7CS%7C11911%2C2%7C4%7C_event_%7C1779551141884%7C_wv_%7ClcpT%7C-5%7Cfcp%7C11955%7Cfp%7C11955%7Ccls%7C0%7Clt%7C0%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551"
		"153844%7C1779551153844%7Cdn%7C89%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551141884%7C_view_%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_1078536306$rpId=377429148$domR=1779551153841$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551141884$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$nt=a0b1779551141884e89f89g89h89i89k6609l6660m6680o11934p11935q11937r11957s11960t11960u6457v6157w6157M377429148V0$ni=4g|1.55$egf="
		"1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551153752_668$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$nV=1$nVAT=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551154929", 
		LAST);

	web_custom_request("rb_bf32608msb_2", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=1125209950&co=snappy&si=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551155856&ss=0&qc=2720340760&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xE7\\xC7\\x02D{\"data_version\":2,\\x05\\x11\\xF4<\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"11512d37c493a9bf\",\"start_time\":1779551153600,\"duration\":136.2999999988824,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x04\",2\\xA5\\x00$time_origi\\x01\\xD1\r\\xEAH41883,\"dt.rum.schem=\\x8C\\x18\""
		"0.23.0:I\\x00\\x00s.2\\x01\\x181717.40\r\\x01\\x083736u\\x00(next_hop_pr\t\\xA1\\x08\":\":O\\x004domain_lookup_\\x05]\\x04\":~X\\x0065\\x00\\x08end\\x863\\x00\\x18connect\\x9Eb\\x00\\x11/\\x92\\\\\\x00\\x18secure_\r4\\x08ion\\x11f\\x0006\\x0F\\x01-\\xFD\\x11\\x1E\\x1811772.1IX\\x1099255>/\\x00\\x14sponse\\x190\\x10849.8-m\\x08074^0\\x00\r\\xB5\\x10853.6j^\\x00\\x08dir=\\x12B\\xAC\\x00\r\\x1F\\x05M:\\x1D\\x00\\x14worker\\x11\\x98:\\x1D\\x00\\x10fetch\\x11\\x1C~"
		"\\xCA\\x018render_blocking\\x017\\x14tus\":\"\\x11\\x12:/\\x02\\x14transf\\x01|\\x0Cize\">{\\x000encoded_body_\t\"\\x0C60146W\\x01\\x04deZ%\\x00-\\x9F(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xF6\\x00tE\\xE7\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.\\x85}|6343452934a6cc116081301249311005\\x19.$s_sampled\"\\x8D&NI\\x04,w3c_resource\r\\xAB\\x00s\\x110m\\xD0\\x18applicaA\\x91\t\\x83<ea7c4b59f27d43eb\\xBD-\\x10frame:/\\x05@0658723d03128701\"\\x95*\\x14agent.\\xB5\\xB5\\\\\""
		"1.337.9.20260504-112723>1\\x00\\x00t\\xA9\\x1F$javascript\\x19!\\x00b\\xAD\\xB5\\x00s%,|5FD5AE18A27F2D030298B0E6443492DC\\x198\t0\\x80PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-\\x81\\xC5-\\x16\\x00i\\xCD\\x13)\\x13\\xB1\n\\x905375531MFC41L7BDCA9O6K5LD4QJC198ENV9R\\x01w,evice.orient%[\\xA1\\xF0<andscape-primary\\x19)4screen.width\":\\xC1[\\x04,\"\rD\r\\x1B,height\":960,\\xD5\\xBC\\x14window67\\x001#\r\\x1C\\x118\\x08796B8\\x00\tb\\x1C_pixel_r\\x01\\xA7\\x10\":1.2\\x810\\x10age.u\\xA6v\\x06\\x04acA?$s/"
		"Catalog.\t\\x10a\\x95\\x01I1L\\x00_%\\xB6J0\\x02\\x05&$detected_n\\xC9\\x9E\\x00/\\xD9\\xD5\tO^_\\x00\\x0Ctitl\\xE1\\xDFPJPetStore Demo\",\"view:}\\x00<619a6ab6b5e385a7\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x05o\\xC6\\xC6\\x00\\x04},\\xFE\\xAD\\x08\\xD2\\xAD\\x08\\x0442.\\x92\\x07\\x0425:\\x94\\x07\\x04in:\\xAE\\x08u\\x8BNg\\x04\\xAD\\x14\\x91Z\\xAAN\\x01\\x10ruxit\\x85)pjs_ICA15789NPRTUVXfqrux_10337\\x891\\x890\\x0C.js\""
		"\\xFE\\xD5\\x08\\xFE\\xD5\\x08\\x1E\\xD5\\x08f9\\x07\\xF6\\xD5\\x08fX\\x00b\\xD5\\x08f3\\x00\\x1Ar\\x08\\xE16\\x00r\"7\t\\x86/\\x00\\xE5\\xD3\\xE9\\x9Af-\\x00\\xF2\\xD5\\x08\\x8A\\xA5\\x08\"\\xEB\t\\x0E\\xA7\\x08\\x005\\x1E\\xA7\\x08\\x086276\\xAE\\x07\\x00r\\x1E\\x05\t\r\\xB5\\x10860.0j.\\x00\\x1A\\xB6\\x08\r^\\x000>M\\x00\r\\x1F\\x05M:\\x1D\\x00\\xBE\\xD5\\x08f;\\x01\\xFE\\xD5\\x08\\x82\\xD5\\x08\\x1013290\\x86\\xD7\\x08\\x14362149&"
		"\\xB1\\x08\\x16\\x97\\x08\\x1A.\\x08\\x1E\\xD9\\x08@not_available_htt\\x0E:\\x0C\\x18requestV\\xE3\\x08\\x012\\x04se\\xE1\\xBDN2\\x04\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08\\xFE\\x99\\x08r\\x99\\x08.\\xE8\\x05\\x004:\\xEA\\x05B\\x99\\x08\\x04im\\x0E\\xFE\rNd\\x04\\x8D\\x9F\\xCA\\x96\\x08Timages/"
		"logo-topbar.gif\\xFEv\\x08\\xFEv\\x08\"v\\x08f8\\x07\\xF6v\\x08fX\\x00bv\\x08f3\\x00Rv\\x08\\x86/\\x00\\xE5t\\x16v\\x08f-\\x00\\xE2v\\x08\\x088572^\\x02>\\xF9\\x07BK\\x11\\x0459\\x8E0\\x00\r\\xB5\\x0Ev\\x08f\\xE7\\x12\\x00r\\x1EW\\x08\\xFEv\\x08\\x8Av\\x08f;\\x01bv\\x08\\x0Cnon-\\xFEO\\x11\\x1EO\\x11\\x0C38086[\\x01JO\\x11\t"
		"%m\\xA5Vv\\x08\\xEEO\\x11\\x12O\\x11x3881223f689a154f0643b8963dcd5a3\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\xFEO\\x11\\x8EO\\x11>Z\\x08\\x0Ey\\x154elf_monitoring\\x1Ea\\x08J*\\x00\\x1Cinternal\\x11#\\xA5\\xFB\\x0E[\r\\x00e.I\\x1A\\x007\\x12_\\x19\"I\\x1A\\x000\"B\\x15fl\\x19\\x1A\\xA7\\x14\\x0Csfm_*\\xF5\\x1A\\x0E\\xBF\\x19\\x10stamp2^\\x00\\x0C68,\"\\x0E\\xCD\\x164\":2000"
		",\"messag\\x0E3\\x13\\x12\\xD8\\x14\\x1C31483296\\x12\\x8A\\x12\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0E\\xEA\\x15\\x14 JavaS\\x12\\xB2\\x150 tag\\\\\",[]]\"}]\\x15\\xCE\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xFEj\\x16\\xDEj\\x16\\x005.\\xBE\\x1C\\x0449:\\x92\\x12\\xFE\\xD1\r\\xAE\\xD1\r\\x0Ccart\\xFE\\xCA\r\\xFE\\xCA\r2\\xCA\r\\x009\\x1E\\xA7\\x1D\\xFE\\x15\\x1F"
		":\\x15\\x1FfX\\x00b\\xCA\rf3\\x00R\\xCA\r\\x86/\\x00\\x1A\\x15\r\\x0E\\xFC\\x1Ff-\\x00\\xE6\\xCA\r\\x0461r\\xE6\\x0CB\\xCA\r\\x0062\\xF1\\x18:\\xEF\\x18F@\\x16\\x003\\xFE@\\x16\\xFE@\\x16\\x1A@\\x16f;\\x01\\xFE\\xCA\r\\x92\\xCA\r\\x0E7\\x1C\\x04pe&\\xC6\"J\\xC8\r\\x01#\\x00r\\x1A\n\\x16R<\\x16\\xEE\\xC6\r\\x12\\xC6\r|"
		"570492c08c75f09b297394998fb21c09\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F\\xFE\\x15\\x1F&\\x15\\x1F\\x045.\\x0E\\xFE \\x9D\\xF0\\xFE\\x9E\\x08\\xAE\\x9E\\x08\\x10separ\\x0E\"(\\xFE\\xA3\\x08\\xFE\\xA3\\x08\\xFE\\xA3\\x08\\xFE\\xA3\\x08\\xFE\\xA3\\x08\\xFE\\xA3\\x08\\xFE\\xA3\\x08\""
		"\\xA3\\x08\\xBA\\xB8'\\x0462>\\x7F\\x02N\\x98\\x08\\xFEb\\x16\\xFEb\\x16\\x16b\\x16\\xFE\\x98\\x08\\xFA\\x98\\x08\\x0446\\x82`\\x16\\x01#\\xFE\\x98\\x08v\\x98\\x08x348f55f2a3c0905ed28d9435f9189a9\\x0E\\x0B'\\x1A\\xDB'\\xFE\\xAD'\\xFE\\xAD'\\xFE\\xAD'\\xFE\\xAD'\\xFE\\xAD'\\xFE\\xAD'\\xFE\\xAD'.\\xAD'@battery.level\":99"
		">\\xAC'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'\\xFE\\xC7'v\\xC7'\\x0012t0\\x0486.\\x10\\x06\\x86\\xC7'\\xFE.\\x1Fj.\\x1F\\x18sm_fish\\xFE\\xBD\\x08\\xFE\\xBD\\x08*\\xBD\\x08\\x008j\\xC4\\x0F\\xEE*\\x1FnX\\x00Z`\\x11n3\\x00J`\\x11\\x8E/\\x00\"`\\x11n-\\x00\\xE2`\\x11\\x08903\\x8E\\xFA\\x1E\\x12\\xD1\\x18\\x0EX1\\x08904jn\\x01>\\xC8\\x08\\x01."
		":j\\x0B\\xFE\\x1F\\x1F\\xA6\\x1F\\x1Fn0\\x01\\xFEU\\x11\\x92U\\x11\\x08271\\x82\\xBE\\x08\\x05$\\xFE\\xBF\\x08v\\xBF\\x08|060253210f8790b19f045d76c7a63836\\xFEW\\x11\\xFEW\\x11\\xFEW\\x11\\xFEW\\x11\\xFEW\\x11\\xFEW\\x11\\xFEW\\x11VW\\x11\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x082\\xBF\\x08\\x009"
		":\\x88\\x17\\xFEo\\x11\\xB2o\\x11\\x14m_dogs\\xFE\\xB0\\x08\\xFE\\xB0\\x08\\xFE\\xB0\\x08\\xFE\\xB0\\x08\\xFE\\xB0\\x08\\xFE\\xB0\\x08\\xFE\\xB0\\x08\"\\xB0\\x08\\x007rl/>\\x10\\x1A\\x08908\\x8E0\\x00\\x1Ae\t\\x08911r\\xDE\\x08\\x1A10\\x1A\\x0E\t:30\"\\xDA\\x08\\x05M:\\x1D\\x00\\xB6P0\\xFE\\xBB\\x08\\xEE\\xBB\\x08\\x12\\xBB\\x08\\x0430\\x86y\\x11\\x05$\\xFE\\xBB\\x08v\\xBB\\x08x78c4449186f15ce3a8d1129d5513f44\\x0E\\xAB+"
		"\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11\\xFEz\\x11~z\\x11\\x0493\\xFE\\xD7\"\\xFE\\xD7\"\"\\xD7\"$sm_reptile\\xFE\\xCE\\x08\\xFE\\xCE\\x086\\xCE\\x08\\x003\\x1E\\xDE\"B\\x85@\\xF6~\\x11fX\\x00b~\\x11f3\\x00R~\\x11\\x86/\\x00\\xE5\\xCC\\x0E\\xA80\\x008j-\\x00\\xEA~\\x11\\x007rb\\x19N\\xCE\\x08n\\xF4/\r0\r\\xB5\\x0E\\xCE\\x08\\xFE~\\x11\\xEA~\\x11f]\\x01\\xFE~"
		"\\x11\\x92~\\x11\\x0439\\x8A\\x9C0\\x01$\\xFE\\xC3\\x08z\\xC3\\x08x10e236f5ffa28765b140d44712ee9b4\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11\\xFE~\\x11N~\\x11\\x005\\x0E9K\"h0\\x04146\\xE5(\\xFEk9\\xEEk9\\x14sm_cat\\xFE\\xBF\\x08\\xFE\\xBF\\x08*\\xBF\\x08\\x0469j\\xA8\\x06\\xEA\\xBF\\x08rX\\x00V\\xBF\\x08r3\\x00F\\xBF\\x08\\x92/\\x00\\x1A\n"
		"\\x08v-\\x00\\xEA\\xBF\\x08\\x008.\\x1D\\x0BBl\\x08\\x1A\\x8F\\x08\\x1A/\\x11\\x001\\x12\\x91\\x08\\x000j\\xAFA\r0\r\\xB5\\x0491v\\xCB+\\xFE\\x8D\\x11\\x9A\\x8D\\x11rh\\x01\\xFE\\xCA\\x08\\x92\\xCA\\x08\\x08289\\x86H\\x1A\\x01$\\x00r\\xFE\\x9F+r\\x9F+|"
		"99b04d0d3be1cf52ac7ae8a395db1efa\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xFE\\xCA\\x08\\xC2\\xCA\\x08\\x0Cbird\\xFE\\xCB\\x08\\xFE\\xCB\\x086\\xCB\\x08.RC63\\x06\\xF6\\xCB\\x08fX\\x00b\\xCB\\x08f3\\x00R\\xCB\\x08\\x86/"
		"\\x00\\x1A\\x16\\x08\\xE1\\x90f-\\x00\\xF2\\xCB\\x08nr+\\x1A\\x9B\\x082\\xCB\\x08n\\xF4I\r0\r\\xB5\\x0E\\xCB\\x08n.\\x00\\xFE\\xCB\\x08\\xA6\\xCB\\x08f;\\x01\\xFE\\xCB\\x08\\x96\\xCB\\x08\\x005\\x8A\\x13#\\x01$\\xFE\\xCB\\x08z\\xCB\\x08t816f19d7e450737bad8f89b94aa411\\xFEj4\\xFEj4\\xFEj4\\xFEj4\\xFEj4\\xFEj4\\xFEj4Zj4\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xFE\\x13#\\xF6\\x13#F\\x95\\x11:0\\x0F\\xFE\\x15#\\xAE\\x15#\\x0E\\xC2+"
		"\\x10_icon\\xFE\\x17#\\xFE\\x17#&\\x17#\\x006n\\x83I\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\x8E\\xBF\\x08n\\xDB\\x07\\x1A\\x8F\\x08*\\xBF\\x08\\x002j\\xF8\\x12B\\xC7+\\x0016B\\x146[\n\"\\xF8\"\r^:\\xFA\"\\x15\\x1F\\x12\\x0C\t:\\x1D\\x00\\xB2\\x17#r\""
		"\\x02\\xFE\\xBF\\x08\\x92\\xBF\\x08\\x0443\\x86\\x8A\\x11\\x05$\\xFE\\xBF\\x08v\\xBF\\x08x86a2d4a77c95efdf9919761e255ab39\\x0E\\xE0Z\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#\\xFE\\x17#B\\x17#F\\xBF\\x08.\\x89 >/(\\xFE\\xCC\\x08\\xAE\\xCC\\x08\\x0E\\xDE+\\xFE\\xCC\\x08\\xFE\\xCC\\x08F\\xCC\\x08f\\xEF\\x0F\\xF6\\xCC\\x08fX\\x00b\\x8B\\x11f3\\x00R\\x8B\\x11\\x86/"
		"\\x00\\xE5\\xCA\\x001\\x12\\x8B\\x11f-\\x00\\xEA\\x8B\\x11n\n\n\"\\x9C\\x08\\x1An\\x08\\x0EV\\x1A\\xBE\\xCC\\x08:y\\x0B\"\\xA2\\x08\rS:\\xA4\\x08\\x15\\x1F\\x05\\xF7:\\x1D\\x00\\xBE\\xC1\\x08f0\\x01\\xFE\\xC1\\x08\\x96\\xC1\\x08\\x006\\x86\\x15#\\x05$\\x00r\\xFEK\\x1ArK\\x1Ax0106cd0c159eb4f1e7918889de78244\\x0E,"
		"d\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\x82\\xC1\\x08\\x0042\\x01\\x0F\\xFE\\xC1\\x08\\xEE\\xC1\\x08\\x0E\\x12#\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x08\\xFE\\xC1\\x082\\xC1\\x08\\x0410\\xBAL\\x1A\\x002\\x8E\\x06,"
		"\\x12\\x7F\\x08\\x0E\\xEF\\x08:ZQ\"\\xA0\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\x8A\\xBF\\x08\\x000\\x8A\\xBF\\x08\\x01$\\xFE\\xBF\\x08v\\xBF\\x08xeec7500495dcb0651786aafded90a82\\x0E\\x17n\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\xFE\\xBF\\x08\\x8A\\xBF\\x08\\x002\\x1AJ)"
		"\\x8E\\x85v\\xFE\\x10Fj\\x10F\\x1E\\x934\\xFE\\xC2\\x08\\xFE\\xC2\\x08F\\xC2\\x08f\\xBCL\\xF6\\x83\\x11fX\\x00b\\x83\\x11f3\\x00R\\x83\\x11\\x86/\\x00\\x1A\r\\x08\\x0E\\x14\\x19f-\\x00\\xE6\\x83\\x11\\x0410r\\xAA\\x10NO\\x1Af\\x87\\x00\"\\xB3\\x11\r\\xB5\\x08914r7,\\xFE\\x0E#\\xA6\\x0E#n\\xB4\\x00Z\\x8Bv\\xFE@e.@e\\x0466\\x86O\\x1A\\x05$\\xFE\\xCF\\x08z\\xCF\\x08xd5d0691ccd800f0f220556020af570c\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+"
		"\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+\\xFE\\xD9+R\\xD9+\\x0Ej~*\\xA34\\x004.2\\x0F\\xFE\\xE0N\\xF2\\xE0N\\x12\\xD6+\\xFE\\xCD\\x08\\xFE\\xCD\\x08:\\xCD\\x08\\x007:v\\x18\\xEA\\xC0\\x08>K\\x00V\\xB3\\x08>&\\x00F\\xA6\\x08^\"\\x00\\xED\\xE4B \\x00\\xEA\\x8C\\x08:3*\"O\\x08\\x1A\\xF0\\x10\\x0E\\x13\\x11:`H\\x15#\r\\x8E\\x0Er\\x08n\\xDE+\\xFEr\\x08\\x9Ar\\x08"
		">4\\x01\\xFE\\xF3\\x19\\x96\\xF3\\x19\\x8A\\x86N\\x05$\\xFEe\\x08ve\\x08x6135b4ea1935207e91677816692dbfa\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11\\xFE4\\x11V4\\x11Be\\x08.$)\\xFE\\x08=\\xF2\\x08=\\x08pla\\xFEDW\\xFEDW.DW>\\x9A\\x06\\xFEa\\x08\\xFEa\\x08\\xFEa\\x08\\xBAa\\x08F\\x12\"F\\xE2\\x10v\\x03+\r0*p\\x08.k\\x02\\xFE1+\\xDA1+"
		">\\xD6\\x01\\xFEp\\x08\\x92p\\x08\\x0C3609:\\xF1\\x00JNh\r&\\xFEt\\x08vt\\x08xd2f3d162109b8290790e1f716620412\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_\\xFE\\xB9_F\\xB9_\\x1EC\\x8F&\\xD9\\x10\\x0C19602i\"6\\x0B\\x06B(+\\x10navig\\x0E\\xA4\\x89\\x0EW\\x89>jv\\xF64\\x90b_\\x89\\x04ne\\xFE9\\x90\\xF69\\x90\\x8A\\xDD\\x10\\x0E\\x8A\\x84\\x08/"
		"1.\\xA1\\xB2.\\xB7i6\\xBD\\x10\\x1A\\x10\\x10\\x0489.\\xEC\\x0FBL\\x1264\\x00\\xE5\\xB1z2\\x00:\\xFD\\x10\\x9A.\\x00\\x8EZ\\x00\\xDA\\x15\\x11\\x08660:\\xE4\\x006V\\x02\"\\xFF\\x10-\\x12\\x0466r\\x85\\x02\\x15/\\x05\\xB3\\x0C6679.\\x19\\x19\\x12)\\x8C*+k\\xFEo\"\\x96o\"ze\\x01b\\xCA\\x08\\x96\\xDB~\\x08645:\\xA3\\x08N-\\x90\\x001>%\\x00J\\xC8\\x08\t%\\xFE\\xC7\\x08v\\xC7\\x08xb6cac58b872225ccb8fa7548b47aee6n\\xC1_\\x12s\\x8D\\x16\\x18\\x90.\\xFD\\x8C\\x04\","
		"R\\\\\\x04\\x0E\\xAE\\x87\\x99\\x81\\x0E\\xC0z\\x04in&I\\x90N\\x8E\\x04\\x19.\\x1E\\xFBz.+\\x02\\x1A\\xE3\\x8F\r%\\x04e\"6\\xA6\\x02\\x14unload\\x16\\xD8zQ\\xAA:\\x0B\\x042#\\x00E\\x9E:!\\x00\\x08dom\\x16}{\\x81\\xDD\\x00v\\x0En{\\x081932L\\x16:\\x1A\\x14\\x011\\x1Ccontent_\\x01\\x7F\\x00e:\\x81\\x00\t@f\\xBC\\x0Bb@\\x00\\x05\\x9E\\x01>\\x006>M\\x0C\t3\\x0E\\xC4\\x91\\x00t\t"
		"\\xA1\\x0456ja\\x00\\x01\\x956\\x14\\x01\\xC9D\\x000\\x1A\\xEE\\x1FF\\x15\\x8B\\x1D2\\x11\\x85z\\xEF\\x03\\x1A\\xEF\\x14\\x08cou\\x0E\\xCE\\x92\\x040,1\\xA2\\x08ion1\\xB4\\x08har\\x0E\\x93\\x13-\\xBB\\x05\\x19\\x04ab!\\xA6\\x01\\xC4\\x0C\"new\\x1ES\\x8F\\x00s\\x0E).\\x0EU\\x97\\x1Cnumber\":\\x0E\\xB9f\\x16C\\x96\\xFE\t|\\xFE\t|\\xFE\t|\\xFE\t|\\xFE\t|\\xFE\t|\\x0E\t|\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xFE\\xF4>\\xF2\\xF4>\\x008"
		":\\x81\\x13\\x086.7\\x1A+X\\x14111758:\\x84\\x07B\r\\x0B\\x0Cothe\\x0E9\\x97Nz\\x06\\x00r\\x81x\\x00s\\xA6\\xF6\\x89\\x08fav\\x12\\xF0>\\x08ico\\xFE\\xE1\\x89\\xFE\\xE1\\x89\\x12\\xE1\\x89\\x0497nc#N\\x80\\x13\\xAE\\x04\\x0B\\x001z`\\x00J\\x05\\x0B~3\\x00:\\x06\\x0B\\x9E/\\x00\\xD1\\x93r\\xEF\\x00\\xDA\\x08\\x0B\\x01\\x84\\xB6\\x1F|\\x0498B\\x9F\\x076\\xFE\n\\x0C1198n\\xC5\\x9C\\xFE\\xFE\n\\x96\\xFE\n\\x01\\xD9n\\x1F\\x02b\\xFF\n\\xA6\\x9E$\\x009\\x0E\\x8D\\x84.\\xAD\tN\\x02\\x0B"
		">$\\x00N\\x01\\x0B\\x01$m\\x8DV\\x18|\\x0E\"\\x92\\xFET\\x92\\xFET\\x92\\xFET\\x92\\xFET\\x92\\xFET\\x92\\xFET\\x92\\xFET\\x92\\xCAT\\x92\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08Zz\\x08\\x08]}}", 
		LAST);

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CSign%20In%7C-%7C1779551156601%7C551153752_668%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%7C; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_3", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=2788409957&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551141884$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$rt="
		"1-1779551141884%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb11717e0f0g0h0i0k55l132m136v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb11718e0f0g0h0i0k140l142m143v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb11718e0f0g0h0i0k144l145m145v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb11718e0f0g0h0i0k144l145"
		"m146v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb11718e0f0g0h0i0k186l186m186v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb11718e0f0g0h0i0k190l191m193v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb11718e0f0g0h0i0k190l191m193v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_"
		"5Fcats.gif%7Cb11769e0f0g0h0i0k139l142m143v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb11770e0f0g0h0i0k139l142m143v251w251E1F495O33P15I7M-1591609649V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish_5Ficon.gif%7Cb11770e0f0g0h0i0k139l143m144v439w439E1F800O40P20I7M-1858137608V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fdogs_5Ficon.gif%7Cb11770e0f0g0h0i0k140l143m144v468w468E1F920O46P20I7M-39000523V0%7Chttp%3A%2F%2"
		"Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcats_5Ficon.gif%7Cb11770e0f0g0h0i0k141l143m144v408w408E1F860O43P20I7M-246443466V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Freptiles_5Ficon.gif%7Cb11770e0f0g0h0i0k141l143m144v669w669E1F1560O78P20I7M355865488V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fbirds_5Ficon.gif%7Cb11770e0f0g0h0i0k141l143m144v471w471E1F1000O50P20I7M1303219330V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsplash.gif%7Cb11770e0f0g0h0i0k142l143m145v36"
		"097w36097E2F124250O350P355Q357R347I7M-266518883V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Ffavicon.ico%7Cb11971e0f0g0h0i0k1l16m17u983v683w683I22$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551153752_668$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551156610", 
		LAST);

	web_url("Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A", 
		"URL=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("rb_bf32608msb_4", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=106305991&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551156615%7C_wv_%7CAAI%7C1%7CfIS%7C14499%7CfID%7C3%2C1%7C7%7C_event_%7C1779551156694%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551141884%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C8%7C_event_%7C1779551156694%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$rId=RID_1078536306$rpId=377429148$domR=1779551153841$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551141884$tvm="
		"i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551153752_668$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$nV=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551156698", 
		LAST);

	web_custom_request("rb_bf32608msb_5", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=1499031505&co=snappy&si=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551156704&ss=1&qc=395051120&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xAA.D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"11512d37c493a9bf\",\"view.fo\\x11?,_time\":14816\r\\x1D\\x0Cback\t\\\\\r\\x1D\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!#8us\":\"reported\",\\x05\\x18)^:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x11\\x0E\\x1C11954.80\r\\x01\\x0C745,"
		"\\x05\\x1F\\x1Cloading_\\x01b!\\x85,dom_content_\\x01\\x1C\\x05k\\x01H\\x01!>\\x83\\x00\\x08fidb\\x18\\x00\\x01=.Y\\x00$complete\",\\x117\\x04rt-\\x8C\\x1814499.3\r\\x9B\\x000\t\\x9C\\x14id.dur%J\\x08\":8\t5\\x04na!\\xD8,\"pointerdown\rN\\x18process\rp\\x04rt!\\xFD\\x14502.19\r\\x01\\x0425\\x01\\xF0\\x04id.*\\x00\\x08end\\x11(F|\\x00<cancelable\":true\t\\x818ui_element.tag_\r\\x90\\x00A\r\\x86\\x1D\\x1E\\xA8xpath\":[\"html\",\"body\",\"div[@id=\\\\\"Header\\\\\"]\""
		".\\x16\\x00\\x0CMenuN\\x14\\x00\\x00C)\\x92\t\\x1B a[2]\"],\"fv\\xDD\\x01\\x00pB\\x83\\x01V\\xDC\\x01\\x00pR\\xC3\\x01\\x04in\\x1D\\x184below_thresholA}\\x04lc\\x1D\\x1F]\\x95\\x01\\x186\\x95\\x02\\x041,\\x05\\x15\\x04st=\\xF0\\x141975.5\t\\x19A(Q\\x08\\x141950.8\t\\x18\\x08siza\\xC4\\x1023879\t\\x12\\x14url\":\"a$\\xB8://localhost:8080/jpetstore/images/splash.gif\",\\x05\\x81\\x1Cresource\tqY[\\x10144.5M&\\x14962747\rn9\\xEBDrender_delay\":60.9Q\\xAB\\x1037253\t0:`\\x00\t,\\x145109.6\\x11^E\\x85"
		"!\"\rQ\\x8D\\xA7.\\x0E\\x01\\x1Dv]a\\x08IMG\r\\xC6\\x1D \\x82c\\x0225\\x02Yz\\x0CMainII6\\x14\\x00\\x00I!9b\\x19\\x002M\\x00\\x08imgA\\x81 long_task!\\xDE\\x89\\x1D\\x0Cnot_]\\x0F\\x0Cttfb\\x19\\x1D>\\x19\\x00\\x8D\\xA9\\x106660.6\\x82\\x03\\x058\\x0Cwaita\\xD29\\xAC\\x0C89.4:{\\x01\\x05*\\x10cache\\x1D(\\x040,\t\\x18\\x08dnsJ\\x16\\x00\\x14connec\\xA5\\xA3\\x19[\\x113\\x18request\\x1D\\x1A\\x08657:\\xF2\\x01 ,\"perform\\x81$\\x14.activ\\x85\\xA8\\xA1E\\x00r\\xC9C\\x00v\\xC1\\x92\\x00s\\x01L"
		"(nce_number\"a\\x0C\\x05\\x19\\x08pre2\\x03\\x02X0,\"characteristics.has_\\x01,\\x1C_summary\\x91\\x86\\x10navig\\x05n\\xE1\\x1B\\x01r\\xA5\\xB7\\x10new\",2\\x1D\\x00\\x04yp\\xA1\\xCF\\x08hara\\xAF.\\xB0\\x00Av\\\\_origin\":1779551141883,\"2\\xA6\\x036\\x1B\\x009+\\xEDX,dt.rum.schem\\xFD\\xFC\\x18\"0.23.0\\x81\\xED\t!\\x14applic\t\\xB3Xid\":\"ea7c4b59f27d43eb\",\\xF5\\xEE\\x18frame.i2\\xF0\\x07<0658723d03128701\\x1DZ\\x00g\\xA1\\x89\"v\\x08\\\\\"1.337.9.20260504-112723>1\\x00-\\x1B$javascript\\x19"
		"!\\x00b\\x1Av\\x08\\x00s\\x05\\xA9|5FD5AE18A27F2D030298B0E6443492DC\\x198\t0\\x80PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-=\\x16\\x11\\xE4)\\x131l\\x905375531MFC41L7BDCA9O6K5LD4QJC198ENV9R\\x01w,evice.orient%[<\":\"landscape-priE4\\x04,\"\r)@battery.level\":99\\x15\\x1A$screen.wid\\xC1\\xB0\\x0C1536>\\x1B\\x00(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x08796B8\\x00\t\\x97\\x1C_pixel_r\\x01\\xC1\\x10\":1.2aZ(age.url.ful\\x8E\\xEF\\x05\\x00ae\\xC9 s/"
		"Cataloge\\x8E\\x00o\\x0E\\x17\\x08\\x05I1f\\x00_%\\xD0JJ\\x02\\x05&\\x1Cdetected\\xF1\\xD0\\xDDNv_\\x00\\x08tit\\x0E \\x08\\x14\"JPetS\\xC1~\\x14 Demo\"\\x1At\n6}\\x00<619a6ab6b5e385a7\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x00v\\x81n\\xC6\\xC6\\x00\\x04},\\xFE\\x88\\x0B:\\x88\\x0B%N&\\xC7\\x0B\\xD1\\xE1\\x104817,\t"
		"\\x1D\\x00b\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xFE\\x88\\x0B\\xBA\\x88\\x0BNW\\x0B\\xC1\\xA6\\x00_:W\\x0B\\x01\\x14N\\x97\\x0B\\xFEo\\x0B\\xFEo\\x0B\\x1Ao\\x0B\\x047,"
		"\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\xFEo\\x0B\\x0Eo\\x0B\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779552956787|1779551153758; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=1$551156741_369h-vPVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_6", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3609811264&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CSign%20In%7CC%7C-%7C551153752_668%7C1779551156601%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%2Fjpetstore%2Factions%2FCatalog.action%7C1779551141884%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551156611%7C1779551156789%7Cdn%7C67%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%2C2%7C3%7C_event_%7C1779551156611%7C_vc_%7CV%7C164%5Epc%7CVCD%7C1024%7CVCDS%7C0%7CVCS%7C23"
		"2%7CVCO%7C1248%7CVCI%7C0%7CTS%7C1%7CVE%7C491%5Ep260%5Ep67947%5Eps%5Es%23Banner%7CS%7C162%2C2%7C4%7C_event_%7C1779551156611%7C_wv_%7ClcpT%7C-5%7Cfcp%7C-6%7Cfp%7C-6%7Ccls%7C0%7Clt%7C52%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551156788%7C1779551156789%7Cdn%7C67%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551156611%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551141884%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk"
		"0%5Esh0$dO=localhost,$rId=RID_-1637738179$rpId=2139443415$domR=1779551156784$tvn=%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A$tvt=1779551156611$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$nt=a0b1779551156611e13f13g13h13i13k15l78m80o164p164q168r173s177t178u4903v4603w4603M2139443415V0$ni=4g|1.55$egf=1589PRTUX$url="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551156741_369$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$time=1779551157872", 
		LAST);

	web_custom_request("rb_bf32608msb_7", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=1344193327&co=snappy&si=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551158802&ss=0&qc=63400298&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xB1\\xE7\\x01D{\"data_version\":2,\\x05\\x11\\xF4,\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"11512d37c493a9bf\",\"start_time\":1779551156713,\"duration\":0,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x08\",\".\\xA5\\x00(time_origin.\\xDA\\x00@611,\"dt.rum.schem=|\\x18\"0.23.0:I\\x00\\x00s.\""
		"\\x01\\x0C02.56h\\x00(next_hop_pr\t\\x94\\x08\":\":B\\x004domain_lookup_\\x05P\\x04\":JK\\x006(\\x00\\x08endR&\\x00\\x18connectjH\\x00\\x11\"^B\\x00\\x18secure_\r'\\x08ion\\x11L\\x0006\\xDB\\x00-\\xBCb\\x1E\\x00\\x14sponse~\\x1F\\x00^\\x86\\x00\\x10redir\\x1D\\xC9B}\\x00\r\\x1F\\x05@:\\x1D\\x00\\x14workerZz\\x00\\x10fetch\\x11\\x1CJg\\x018render_blocking\\x01*\\x14tus\":\"\\x11\\x12:\\xBF\\x01\\x14transf\\x01o\\x0Cize\">\\x8B\\x000encoded_body_\t\"\\x0C60146J\\x01\\x04deZ%\\x00-c"
		"(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xBA\\x00tEw\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.e\\xF0|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\xA9N\\xCC\\x03,w3c_resource\r\\xAB\\x00s\\x110mS\\x18applicaAU\t\\x83<ea7c4b59f27d43eb\\x9D\\xA0\\x10frame:\\xA2\\x04@3bfacf5ece47ced4\"u\\xAD\\x14agent.\\xB5(\\\\\"1.337.9.20260504-112723>1\\x00\\x04ty\\x85\\xA2$javascript\\x19!\\x00b\\xAD(\\x00s%,|5FD5AE18A27F2D030298B0E6443492DC\\x198\t"
		"0\\x80PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-\\x81H-\\x16\\x00i\\xAD\\x86)\\x13\\x001\\xB1g\\xD0375531MFC41L7BDCA9O6K5LD4QJC198ENV9R\",\"device.orienta![L\":\"landscape-primary\\x01\\xA0\\x00e\\x05)Dscreen.width\":1536\\x15D\r\\x1B,height\":960,\\xD5/\\x14window67\\x001#\r\\x1C\\x118\\x08796B8\\x00\t}\\x1C_pixel_rA\\x02\\x10\":1.2\\xA1.\\x10age.u\\xA6\\xF9\\x05\\x04ac\\x01\\xE4$s/Account.\t\\x10\\x10;jses\\xE1$\\xB8id=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm="
		"a\\xCD\\x01\\x811\\x84\\x00_%\\xEEJh\\x02\\x05&$detected_n\\xC9Y\\x00/\\xD9\\x90\t\\x87\\xEE\\x97\\x00\\x11\\x8B\\x0Ctitl\\xE1\\xB6PJPetStore Demo\",\"view:\\xA9\\x00880a604bf9d9dbe1A\\xE0\\x05&\\xFEP\\x01\\xEEP\\x01\\x05\\x81\\xFE*\\x01v*\\x01\\x04},\\xFE\\xE8\\x08\\xFE\\xE8\\x08N\\xE8\\x08\\x95BN\\x1E\\x05\\xAD\\xCB\\xB1\\x11\\xAA\\xA1\\x01\\x10ruxit\\x85\\xE0pjs_ICA15789NPRTUVXfqrux_10337\\x89\\xE8\\x89\\xE7\\x0C.js\"\\xFE\\x0F\t\\xFE\\x0F\t\\x1A\\x0F\t\\x009\r"
		"\\x01\\x10627476\\xF7\\x06\\xF2\\x1C\t\rWNX\\x00^)\tj3\\x00\\x1A\\xED\\x08\\xE1\\xED\\x00r\\x1E~\t\\x8A/\\x00\\x12}\\x08\\x12D\\x08j-\\x00\\xFEP\t\\xDEP\tj\\x93\\x00\\xFE]\t\\xAA]\tr\\x86\\x00\\xFEj\tzj\t\\x1013290\\x86l\t\\x14362149&F\t\\x16,\t\\x1A\\xC3\\x08\\x1En\t@not_available_htt\\x0ER\\x0Cm\\xD5Vx\t\\x012\\x04se\\x0ER\\x08N\\x10\\x04\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xFE.\t\\xEE.\t"
		"\\x12.\t\\x04im\\x0EJ\\x0FN\\x1B\\x05\\xADV\\xCA+\tTimages/logo-topbar.gif\\xFE\\x0B\t\\xFE\\x0B\t\\x1A\\x0B\t\\x006\\xF1\\x0B\\x1025494\\xFE\\x0B\t&\\x0B\tnX\\x00Z\\x0B\tn3\\x00J\\x0B\t\\x8E/\\x00\"\\x0B\tn-\\x00\\xFE\\x0B\t\\xDA\\x0B\tn\\x93\\x00\\xFE\\x0B\t\\xA6\\x0B\tv\\x86\\x00Z\\x0B\t\\x0Cnon-\\xFEy\\x12\\x1Ey\\x12\\x0C38086w\\x02Jy\\x12\t%m\\x83V\\x0B\t"
		"\\xEEy\\x12\\x12y\\x12x3881223f689a154f0643b8963dcd5a3\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xFEy\\x12\\xC2y\\x12\\xFEK\tjK\t\\x0Ccart\\xFED\t\\xFED\t*D\t\\x007\\x1AD\t\\x148882416\\xCD\\x06\\xEEO\\x12nX\\x00ZD\tn3\\x00JD\t\\x8E/\\x00\"D\tn-\\x00\\xFED\t\\xDAD\tn\\x93\\x00\\xFED\t\\xA6D\tv\\x86\\x00\\xFED\t\\x8AD\t"
		"\\x0E\\xDB\\x18.H\\x1EJB\t\\x01#\\xFE@\tv@\t|570492c08c75f09b297394998fb21c09\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xFE\\xB9\\x1B\\xBE\\xB9\\x1B\\xFE@\tj@\t\\x1Cseparato\\xFE\\x89\\x12\\xFE\\x89\\x12.\\x89\\x12\\x0490\r\\x01\\x1037253\\xFEE\t&E\t"
		"nX\\x00ZE\tn3\\x00JE\t\\x8E/\\x00\"E\tn-\\x00\\xFEE\t\\xDAE\tn\\x93\\x00\\xFEE\t\\xA6E\tv\\x86\\x00\\xFEE\t\\x8AE\t\\x04466u\\x02JE\t\\x01#\\xFEE\tvE\t|348f55f2a3c0905ed28d9435f9189a91\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xFEE\t\\xEEE\t\\x1AE\t\\x004\\xAE\\xE6-\\xFEE\tnE\t\\x14m_fish\\xFE\\x88\\x12\\xFE\\x88\\x12\"\\x88\\x12\\xFE4\t\"4\t:I\\x00R%\t:$\\x00B\\x16\tZ \\x00\\x1A\\x07\t"
		":\\x1E\\x00\\xFE\\xF8\\x08\\xD2\\xF8\\x08:\\x84\\x00\\xFE\\xE9\\x08\\x9E\\xE9\\x08Bw\\x00\\xFE\\xDA\\x08\\x8A\\xDA\\x08\\x0427:\\x95\\x14J\\xDB\\x08\\x05$\\xFE\\xDC\\x08v\\xDC\\x08|"
		"060253210f8790b19f045d76c7a63836\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x08\\xFE\\xDC\\x086\\xDC\\x08\\x0Cdogs\\xFE\\xDC\\x08\\xFE\\xDC\\x08&\\xDC\\x08\\x04.0\\x1Ad\\x1BN[-\\xE6d\\x1BvX\\x00V\\xFA\\x08r\\x8B\\x00F\t\t\\x92/"
		"\\x00\\x1E\\x18\tr-\\x00\\xFE'\t\\xD6'\tr\\x93\\x00\\xFE6\t\\xA26\tz\\x86\\x00\\xFEE\t\\x8AE\t\\x0430\\x86 \\x12\\x05$\\x14reques\\xFE\\xA6$^\\xA6$x78c4449186f15ce3a8d1129d5513f44\\x0EW(\\x1AM7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xFE\\x1F7\\xE2\\x1F7\\xFE!\\x12\\xFE!\\x12*!\\x12\\x18reptile\\xFEI\t\\xFEI\t.I\t\\x001\\x1EI\t"
		"\\xFE\\xF1-2\\xF1-\\x003rX\\x00ZI\tn\\x8B\\x00JI\t\\x8E/\\x00\"I\tn-\\x00\\xFEI\t\\xDAI\tn\\x93\\x00\\xFEI\t\\xA6I\tv\\x86\\x00\\xFEI\t\\x8EI\t\\x009\\x8A\\xF0-\\x01$\\xFEI\tzI\tt10e236f5ffa28765b140d44712ee9b\\x0E\\xC6?\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t\\xFEI\t*I\t\\x08cat\\xFEE\t\\xFEE\t.E\t\\x004\\x1A\\xAC$\\xFE\\xAD$6\\xAD$\\x003rX\\x00ZE\tn\\x8B\\x00JE\t\\x8E/"
		"\\x00\"E\tn-\\x00\\xFEE\t\\xDAE\tn\\x93\\x00\\xFEE\t\\xA6E\tv\\x86\\x00\\xFEE\t\\x8AE\t\\x08289\\x82\\xAE$\\x05$\\xFEE\tvE\t|"
		"99b04d0d3be1cf52ac7ae8a395db1efa\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B\\xFE\\xD3\\x1B6\\xD3\\x1B\\x0Cbird\\xFEF\t\\xFEF\t.F\t\\x0EhM\\x04er\"\\xA3S\\xEE\\xC7\\x1B:K\\x00Z,\t:&\\x00J\\x1F\tZ\"\\x00\"\\x12\t: \\x00\\xFE\\x05\t"
		"\\xDA\\x05\t:\\x86\\x00\\xFE\\xF8\\x08\\xA6\\xF8\\x08By\\x00\\xFE\\xEB\\x08\\x8E\\xEB\\x08\\x005\\x8A\\xBE$\\x01$\\xFE\\xEB\\x08z\\xEB\\x08t816f19d7e450737bad8f89b94aa411\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xFE\\xDF6\\xAE\\xDF6>\\x1FI\\x0Ek 4elf_monitoring\\x1E&IJ*\\x00\\x1Cinternal\\x11#\\x12"
		"[Z\\x0E\\xD7N\\x00e.\\xF3Z\\x0476\\x0E\\x01V.\\xCD[\\x1A\\x97Vf\\x00[\\x11!\\x08fm_*y\\\\ timestamp2^\\x00\\x0C55,\"\\x0E\\xDEX4\":2000,\"messag\\x0E\\xE0T\\x12\\xE9V\\x1C31483296\\x12\\xD3S\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0E\\xFBW\\x14 JavaS\\x12\\xC3W0 tag\\\\\",[]]\"}]&!X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X\\xFE{X^{X>\\xB9\\x05\\x0E\\x17a long_taskz\\xBB\\x05\\x0012\\xBB\\x05\\x005\\x0E\\x1Eb~"
		"\\xBC`\\x15[\\x00.\\x1A\\xC4Z\\xC1P\\x04\",\\x1D\\x18\\x18attribu\\x0Ef[\\x0E\\xB8\r\\x14tainer\\x16\\x18[\\x8A(\\x00\rV\\x8A*\\x00\\x08src\\x16\ra\\x19\\x93V{\\x00\\x1A\\xA5]\\x16f\\\\bY\\x00\ry\\x18unknown\\x0E\\xF0\\\\)"
		"\\x0B\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05\\xFE\\xF9\\x05b\\xF9\\x05V\\x8F\\x0B\\x006\\x12\\x82f\"\\x8F\\x0B\\x08177>\\x0B\\x12B`g\\x10navig\\x0ESa\\x81\\xF6NO\\x06\\x1A\\xAF\\x11\\xD1M\\xAA|^\\xEE\\xD6`\\x16\\xD6`:ma\\x04ne\\xFE\\xA3g\\xF6\\xA3g\\x0006\\xCC\\x1BN\t\\x15\\x0E\\xDC"
		"[\\x08/1.\\x0E\\x01@.4\\x156\\xE9\\x14%\\xBD\\x08\":1>\\x8E'\\x0026`\\x0065\\x00\\x16\\xDC\\x14z3\\x00>+\\x15\\x9A/\\x00\\x92\\\\\\x00\\xDAE\\x15\\x0C15.2\\x1A\\xCC(\\x16yMB[96\\xECg\\x0478z\\xB7\\x1D\r/\\x05\\xB4\\x0479>\\xE1\\x02\\xFEe\\x15\\x9Ae\\x15zY\\x01\\xFA\\x08h\\x0449\\x0E\\xAC\\x0E.A\\x02J\\x0Bh\\x0446>%\\x00J0:\t%m\\xC4\\xFE\\x92UZ\\x92Uxc429431052ba355a2211759e2169b81\\x0Edh^\\xA3'\\x12\\x19e\\x16\\xF6g\\xCEwd\\x18Catalog\\x1A\\xC7eZ'l\\x0E-_\\x99\\xE6\\x0E\\xC3\\x10\\x04in&]"
		"hN\\xF3\\x04\\x19.\\x91\\xF6.\\x8B\\x01\\x1AR\n\r%\\x00e\\x0Eze*\\x1E\\x19\\x14unload\\x16\\xDB\\x10q\\xE9:8\\x042#\\x00E\\xC7:!\\x00\\x08dom\\x16\\x80\\x11\\xA1B\\x00v\\x0Eq\\x11\\x0463>\\xE8\\x02\\x01$\\x1Ccontent_\\x01r\\x00e:t\\x00\\x013n5Xb@\\x00\\x05\\x91\\x0C167.n~a\t>\\x0E\\xD6i\\x00t\\x01\\x9F\\x007v\\x13#\\x01\\xA06\\x12\\x01\\xC1\\x9A2\\x16\\x046\\xFA\\x04\\x1D1\t\\x8FF\\xC9\\x06u\\xE8\\x12\\xC9g\\x00\"!C-\\x92\\x08ion1\\xA4\\x08harA~.\\x19\\x00\\x04ab!\\x96\\x01\\xB6\\x08\""
		"ex\\x0EMn\\x04ng\\x1E\\x1Eg\\x00s\\x0E\\x124\\x0E\\xD1n\\x1Cnumber\":&\\xCFm\\xFE\\x08\\x0C\\xFE\\x08\\x0C\\xFE\\x08\\x0C\\xFE\\x08\\x0C\\xFE\\x08\\x0C\\xFE\\x08\\x0C\\x0E\\x08\\x0C@battery.level\":99>{j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xFE\\x96j\\xF6\\x96j\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_8", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=581099856&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551159545%7C_wv_%7CAAI%7C1%7CfIS%7C2685%7CfID%7C5$rId=RID_-1637738179$rpId=2139443415$domR=1779551156784$tvn=%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A$tvt=1779551156611$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$title=JPetStore%20Demo$latC=0$app="
		"ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551156741_369$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$time=1779551159883", 
		LAST);

	web_custom_request("rb_bf32608msb_9", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3388654157&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A$tvt=1779551156611$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$rt="
		"1-1779551156611%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb103e0f0g0h0i0m0v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb103e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb103e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb103e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F"
		"%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb103e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb103e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb103e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb103e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Floc"
		"alhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb104e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551156741_369$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$time=1779551159894", 
		LAST);

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CLogin%7C-%7C1779551162234%7C551156741_369%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D%7C%7C%7C%7C; DOMAIN=localhost");

	web_submit_data("Account.action", 
		"Action=http://localhost:8080/jpetstore/actions/Account.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=Ash", ENDITEM, 
		"Name=password", "Value=Ashlesha", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		"Name=_sourcePage", "Value=uhbjP3Np6J57SC6GcwK03a0gvNAvvXK2rYY3x_H65PRM9XIdy_Sllbs2-LaAP20Azr03QZER2axrxmh00TKKqZrvM5iO4q5FTZXUAhz1O50=", ENDITEM, 
		"Name=__fp", "Value=2JxgJS8vBV7viQSgUHDMKLwKmmXPynuON0OrfMF5ccLlwSBcYGRDTxk-KIanLJFo", ENDITEM, 
		LAST);

	web_custom_request("rb_bf32608msb_10", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=301330638&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C7%7C_event_%7C1779551162335%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%7Csvt%7C1779551156611%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C8%7C_event_%7C1779551162335%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007...$rId=RID_-1637738179$rpId=2139443415$domR=1779551156784$tvn="
		"%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A$tvt=1779551156611$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551156741_369$v=10337260504112723$vID="
		"177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D$time=1779551162339", 
		LAST);

	web_custom_request("rb_bf32608msb_11", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3044570138&co=snappy&si=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551162347&ss=1&qc=2158323868&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Account.action;jsessionid=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xA24D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"11512d37c493a9bf\",\"view.fo\\x11?(_time\":5731\r\\x1C\\x0Cback\t[\r\\x1C\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!\"8us\":\"reported\",\\x05\\x18)]:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x11\\x0E\\x14210.69\r\\x01\\x1425494,"
		"\\x05\\x1F\\x1Cloading_\\x01b!\\x84 complete\"\t\\x1F\\x01\\x17>y\\x00\\x08fidb\\x18\\x00nO\\x00\t7\\x04rt-\\x82\\x102685,\\x05M\\x08dur%2\\x0C\":16\t\\x12\\x04na!\\xC0,\"pointerdown\\x01\\x90$id.process\r\\xB2$rt\":2690.2\r\\xD9\\x0C8882\\x01\\xD96*\\x00\\x08endf(\\x00<cancelable\":true\t\\x818ui_element.tag_\r\\x90\\x10INPUT\r\\x8A\\x1D\"\\xA8xpath\":[\"html\",\"body\",\"div[@id=\\\\\"Content\\\\\"]6\\x17\\x00\\x18atalog\\\\\\x05\\x17Hform\",\"p[2]\",\"input\\x01\\x0B\\x0C],\""
		"fv\\xC5\\x01\\x00pru\\x01\\x00pR\\xAB\\x01\\x04in\\x1D\\x184below_thresholA[\\x04lc\\x1D\\x1F]s\\x01\\x186s\\x02\\x041,\\x05\\x15\\x04st=\\xD8Ij\t\\x19A\\x10-\\xF0\\x08166\t\\x14(size\":17220\t\\x11\\x14url\":\"A\\xFD\\xC8://localhost:8080/jpetstore/images/logo-topbar.gif\"\tC\\x1Cresource\tqYQ\\x11b9\\xCFTrender_delay\":107.9990\\x05\\x01\\x1074507RP\\x00\t-\\x04246i\\x02\\x0413\\x11-\\x05S\\x89u2\\xFF\\x00\\x1Dx.G\\x02\\x08MG\"\t:\\x1D \\x82E\\x02\\x14HeaderI-Y"
		"[\\x0CLogoN\\x14\\x002s\\x02\\x00aAR\\x04mgAM long_task!\\xB4B\\xDB\\x03\\x19\\x1E\\x0Call.\\xAD\\x12!\\xE4\\x156\\x01\\x18\\x08avg=c\\x0852,:8\\x00@slowest_occurrenc\\xA1\\xFF\\x08[{\".&\\x02\\x10105,\"9\\xA8\\x0C52}].G\\x00\\x0CselfR\\x80\\x00\\x05\\x19n\\x81\\x00\\x05!\\xE2\\x82\\x00\\x0CttfbR\\x1A\\x01\\x05\\x19\\x00v\\xA9Z\\x0C78.4E1 00037253,\t\\x1F\\x0Cwait\\x81\\x9A\\x19\\xD7\\x0C13.1\\x8D\\x9B\\xA9u\\x002\r+\\x10cache\\x1D)\\x000\r"
		"\\x18\\x08dnsJ\\x16\\x00\\x14connec\\xC5U\\x19\\\\\\x113\\x0Crequ!n\\x19\\x1A\\x0C65.2\\x01\\x9C4000111759,\"per\\x81a\\x81\\xEC\\x14.activ\\xA5q\\xA1\\xF6\\x00r\\xC9\\xF4\\x00v\\xE1B\\x00s\\x01K(nce_number\"!\\xFB\\x05\\x19\\x08prem8I\\xE5X0,\"characteristics.has_\\x01,\\x1C_summary\\xB1N\\x10navig\\x05n\\xE1\\xCB\\x01r\\xC5h\\x04ex\\x018\\x0Cng\",2\"\\x00\\x04yp\\xC1\\x85\\x08har\\x81\\x87.\\xB5\\x00\\x01x\\x14_origi\\xC1'0779551156611,6X\\x026\\x1B\\x009\\x15D5730,\""
		"dt.rum.schem*\\xB0\\x08\\x18\"0.23.0\\xA1\\x9E\t!\\x14applic\t\\xB7Xid\":\"ea7c4b59f27d43eb\",\"\\xA2\\x08\\x10frame:\\xA4\\x08<3bfacf5ece47ced4\\x1DZ\\x00g\\xC1U\"*\t\\\\\"1.337.9.20260504-112723>1\\x00-\\x1A$javascript\\x19!\\x00b\\x1A*\t\\x00s\\x05\\xA9|5FD5AE18A27F2D030298B0E6443492DC\\x198\t0\\x80PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-=\\x16\\x00i\\x1A\\x88\t)\\x135k\\xD0375531MFC41L7BDCA9O6K5LD4QJC198ENV9R\",\"device.orientaA\\xCE<\":\"landscape-priE8\\x15)@battery.level\""
		":99\\x15\\x1A$screen.wid\\xE1x\\x0C1536>\\x1B\\x00(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x008a\\xAA:\\x1C\\x00\t\\xC0\\x1C_pixel_rA\\x1CL\":1.25,\"page.url.ful\\x8E\\xCB\\x06\\x00ae\\xCC\\x0Cs/Ac\\xA5ce\\x92\\x18on;jses\\x0E@\\x0B\\xB8id=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=\\x0E6\\x08\\x01\\x811\\x9E\\x00_E\\x08J\\x82\\x02\\x05&\\x1Cdetected\\x1E\\xD4\\x08\\xFDb\\xEE\\x97\\x00\t\\x97\\x11\\x8B\\x08tit\\x0EP\t\\x14\"JPetS\\xE1\\xBE\\x14 Demo\""
		"\\x1A\\x8D\\x0B6\\xA9\\x00880a604bf9d9dbe1A\\xFA\\x00v\\x81\\x8D\\xFEP\\x01\\xEEP\\x01\\x05\\x81\\xFE*\\x01v*\\x01\\x04},\\xFE\\x04\r:\\x04\r%\\xDE&C\r\\xAD\\xAA\\x0457\\x0E\\x04\r\\x05\\x1C\\x04ba\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\r"
		"\\xFE\\x04\r\\xFE\\x04\r\\xFE\\x04\rz\\x04\rN\\xD3\\x0C\\xE1:\\x00_:\\xD3\\x0C\\x01\\x14N\\x13\r\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C*\\xEB\\x0C\\x001\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C\\xFE\\xEB\\x0C2\\xEB\\x0C\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779552962427|1779551153758; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=1$551162385_171h-vPVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_12", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1026391166&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CLogin%7CC%7C-%7C551156741_369%7C1779551162234%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D%7C%7C%7C%2Fjpetstore%2Factions%2FAccount.action%3Bjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%7C1779551156611%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551162238%7C1779551162430%7Cdn%7C91%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Faction"
		"s%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%3FsignonForm%3D%2C2%7C3%7C_event_%7C1779551162238%7C_vc_%7CV%7C182%5Epc%7CVCD%7C1016%7CVCDS%7C0%7CVCS%7C263%7CVCO%7C1270%7CVCI%7C0%7CTS%7C1%7CVE%7C491%5Ep500%5Ep67947%5Eps%5Es%23Banner%7CS%7C180%2C2%7C4%7C_event_%7C1779551162238%7C_wv_%7ClcpT%7C-5%7Cfcp%7C-6%7Cfp%7C-6%7Ccls%7C0%7Clt%7C52%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551162429%7C1779551162430%7Cdn%7C91%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2"
		"C1%7C5%7C_event_%7C1779551162238%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FAccount.action%5Esjsessionid%3DB0E9E2EE641BA9253D7C9AE279D8007A%7Csvt%7C1779551156611%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_1078536306$rpId=-296151352$domR=1779551162426$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551162238$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$nt="
		"a0b1779551162238c10d38e38f38g38h38i38k39l93m95o181p182q185r188s191t192u6039v5739w5739M-296151352V0$ni=4g|1.55$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551162385_171$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551163522", 
		LAST);

	web_custom_request("rb_bf32608msb_13", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=2262346269&co=snappy&si=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551164443&ss=0&qc=1605248802&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xC6\\xB8\\x02D{\"data_version\":2,\\x05\\x11\\xF4,\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"11512d37c493a9bf\",\"start_time\":1779551162354,\"duration\":0,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x08\",\".\\xA5\\x00(time_origin.\\xDA\\x00@237,\"dt.rum.schem=|\\x18\"0.23.0:I\\x00\\x00s.\""
		"\\x01\\x1017.90\r\\x01\\x10372536u\\x00(next_hop_pr\t\\xA1\\x08\":\":O\\x004domain_lookup_\\x05]\\x04\":~X\\x0065\\x00\\x08end\\x863\\x00\\x18connect\\x9Eb\\x00\\x11/\\x92\\\\\\x00\\x18secure_\r4\\x08ion\\x11f\\x0006\\x0F\\x01-\\xFDb\\x1E\\x00\\x14sponse~\\x1F\\x00\\x92\\x93\\x00\\x10redir\\x1D\\xF0B\\x8A\\x00\r\\x1F\\x05M:\\x1D\\x00\\x14workerZ\\x87\\x00\\x10fetch\\x11\\x1C~\\xA8\\x018render_blocking\\x017\\x14tus\":\"\\x11\\x12:\r\\x02\\x14transf\\x01|\\x0Cize\">\\x98\\x000encoded_body_\t\""
		"\\x0C60146d\\x01\\x04deZ%\\x00-}(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xD4\\x00tE\\xC5\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.\\x85K|6343452934a6cc116081301249311005\\x19.$s_sampled\"\\x8D\\x04N'\\x04,w3c_resource\r\\xAB\\x00s\\x110m\\xAE\\x18applicaAo\t\\x83<ea7c4b59f27d43eb\\x9D\\xFB\\x10frame:\\xFD\\x04@5d0433c52667b3ec\"\\x95\\x08\\x14agent.\\xB5\\x83\\\\\"1.337.9.20260504-112723>1\\x00\\x04ty\\x85\\xFD$javascript\\x19!\\x00b\\xAD\\x83\\x00s%,|"
		"5FD5AE18A27F2D030298B0E6443492DC\\x198\t0\\x80PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-\\x81\\xA3-\\x16\\x00i\\xAD\\xE1)\\x13\\x001\\xAD\\xC2\\x905375531MFC41L7BDCA9O6K5LD4QJC198ENV9R\\x01w,evice.orient%[L\":\"landscape-primary\\x19)Lscreen.width\":1536,\"\rD\r\\x1B,height\":960,\\xD5\\x8A\\x14window67\\x001#\r\\x1C\\x118\\x08842B8\\x00\tb\\x1C_pixel_r\\x01\\xA74\":1.25,\"page.u\\xA6T\\x06\\x04acA?$s/Catalog.\t\\x10a\\x95\\x01I1L\\x00_)\\xB6F0\\x02\\x05&$detected_n\\xC9|\\x00/\\xD9\\xB3\tO^"
		"_\\x00\\x0Ctitl\\xE1\\xADPJPetStore Demo\",\"view:}\\x00<4ccc7849dc73aa79\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x05o\\xC6\\xC6\\x00\\x04},\\xFE{\\x08\\x9A{\\x08\\x005\\xAE{\\x08uzNV\\x04\\xAD\\x03\\x91I\\xAA=\\x01\\x10ruxit\\x85\\x18pjs_ICA15789NPRTUVXfqrux_10337\\x89 \\x89\\x1F\\x0C.js\"\\xFE\\xA2\\x08\\xFE\\xA2\\x08\\x0E\\xA2\\x08\\x0086 \\x06\\xE6\\x93\\x08:I\\x00R\\x84\\x08:$\\x00\\x1A\\x12\\x08\\xC1\\xF8\\x00r\\x12\\xD7\\x08Z \\x00\\xE5\\x86\\x001>\\x1E\\x00\\xFEW\\x08\\xD2W\\x08"
		":\\xA2\\x00\\xFEH\\x08\\x9EH\\x08Bw\\x00\\xFE9\\x08z9\\x08\\x1013290\\x86;\\x08\\x14362149&\\x15\\x08\\xE9\\xFB\\xED\\x92\\x1E=\\x08@not_available_htt\\x0E|\\x0BmlVG\\x08\\x012\\x04se\\xE1!N\\xA7\\x03\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xFE\\xFD\\x07\\xE2\\xFD\\x07\\x04im\\x0EQ\r"
		"NS\\x04\\x8D\\x8E\\xCA\\xFA\\x07Timages/logo-topbar.gif\\xFE\\xDA\\x07\\xFE\\xDA\\x07\\xE9\\xDA\\x04.2\\x1A{\\x10\\x14111759\\xFE\\xE9\\x07\\xF5\\xE9rX\\x00V\\xF8\\x07r3\\x00F\\x07\\x08\\x92/\\x00\\x1E\\x16\\x08r-\\x00\\xFE%\\x08\\xD6%\\x08r\\x93\\x00\\xFE4\\x08\\xA24\\x08z\\x86\\x00ZC\\x08\\x0Cnon-\\xFE\\x80\\x10\\x1E\\x80\\x10\\x08380:\\xBA\\x08J\\x80\\x10\t"
		"%m\\x83VC\\x08\\xEE\\x80\\x10\\x12\\x80\\x10x3881223f689a154f0643b8963dcd5a3\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xFE\\x80\\x10\\xA2\\x80\\x10\\xFE\\x83\\x08j\\x83\\x08\\x0Ccart\\xFE|\\x08\\xFE|\\x08*|\\x08\\x003\\x1A|\\x08\\x14074506\\xFE|\\x08&|\\x08nX\\x00Z|\\x08n3\\x00J|\\x08\\x8E/\\x00\"|"
		"\\x08n-\\x00\\xFE|\\x08\\xDA|\\x08n\\x93\\x00\\xFE|\\x08\\xA6|\\x08v\\x86\\x00\\xFE|\\x08\\x8A|\\x08\\x009:u\\x02Jz\\x08\\x01#\\xFEx\\x08vx\\x08x570492c08c75f09b297394998fb21c0\\x0E\\xA9\\x15\\x1A&"
		"\\x19\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18\\xFE\\xF8\\x18v\\xF8\\x18\\xFEx\\x08jx\\x08\\x1Cseparato\\xFE\\xF9\\x10\\xFE\\xF9\\x10.\\xF9\\x10n}\\x06\\xEA\\xE2\\x18rX\\x00\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x082}\\x08\\x004\\x86}\\x08\\x01#\\xFE}\\x08v"
		"}\\x08|348f55f2a3c0905ed28d9435f9189a91\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\xFEu!\\x9Eu!\\xFE}\\x08n}\\x08\\x14m_fish\\xFE\\xF8\\x10\\xFE\\xF8\\x10*\\xF8\\x10\\x0Eg$\\x04er\"\\xFD*\\xEEn\\x08:K\\x00Za\\x08:&\\x00J\\xD1\\x10Z\"\\x00\"\\xC4\\x10: \\x00\\xFE\\xB7\\x10\\xDA\\xB7\\x10:\\x86\\x00\\xFE\\xAA\\x10\\xA6\\xAA\\x10By\\x00\\xFE\\x9D\\x10\\x8A\\x9D\\x10\\x082716\\x13\\x13J\\x9E\\x10\\x05$\\xFE\"\\x08v\"\\x08|"
		"060253210f8790b19f045d76c7a63836\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\xFE\"\\x08\\x16\"\\x08\\x0Cdogs\\xFE\"\\x08\\xFE\"\\x08*\"\\x08\\x007\\x1A\\x1A\\x19\\xFE\\x96!>\\x96!nX\\x00Z<\\x08n3\\x00JI\\x08\\x8E/\\x00\"V\\x08n-\\x00\\xFEc\\x08\\xDAc\\x08n\\x93\\x00\\xFEp\\x08\\xA6p\\x08v\\x86\\x00\\xFE}\\x08\\x8A}\\x08\\x003"
		">\\x90\\x1BJ}\\x08\\x05$\\xFE}\\x08v}\\x08x78c4449186f15ce3a8d1129d5513f44\\x0EE%\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xFE\\x1C\\x19\\xEE\\x1C\\x19\\x12\\x1C\\x19 "
		"m_reptile\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x08\\xFE\\x81\\x086\\x81\\x08\\x009\\x8A\\x16*\\x01$\\xFE\\x81\\x08z\\x81\\x08x10e236f5ffa28765b140d44712ee9b4\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE"
		"\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\xFE\\xFE\\x10\\x16\\xFE\\x10\\x08cat\\xFE}\\x08\\xFE}\\x08.}\\x08\\xFE\\x10CV\\x10C\\x008rX\\x00Z\\xFE\\x10n\\x8B\\x00J\\xFE\\x10\\x8E/\\x00\"\\xFE\\x10n-\\x00\\xFE\\xFE\\x10\\xDA\\xFE\\x10n\\x93\\x00\\xFE\\xFE\\x10\\xA6\\xFE\\x10v\\x86\\x00\\xFE\\xFE\\x10\\x8A\\xFE\\x10\\x0428:\n5J\\xFE\\x10\\x05$\\xFE}\\x08v}\\x08|99b04d0d3be1cf52ac7ae8a395db1efa\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}"
		"\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08\\xEA}\\x08\\x0EfE\\xA2\\x8DK\\xFE\\x9D!v\\x9D!\\x0Cbird\\xFE~\\x08\\xFE~\\x08&~\\x08:\\xF9\\x05\\xE6\\x9C!:I\\x00R`\\x08:$\\x00BQ\\x08Z \\x00\\x1AB\\x08:\\x1E\\x00\\xFE3\\x08\\xD23\\x08:\\x84\\x00\\xFE$\\x08\\x9E$\\x08Bw\\x00\\xFE\\x15\\x08\\x8E\\x15\\x08\\x005\\x8A\\x90!\\x01$\\xFE\\x15\\x08z\\x15\\x08t816f19d7e450737bad8f89b94aa411\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xFE/"
		"2\\xFE/2\\xFE/2\\xFE/2\\xFE/2\\xEE/2\\xFE\\x15\\x08\\xFE\\x15\\x08\\x1E\\x15\\x08\\x0E\\xAF)\\x10_icon\\xFE\\x92!\\xFE\\x92!\"\\x92!\\x0C9.09\r\\x01\\x10627476\\x99'\\xEA%\\x08rX\\x00V4\\x08r3\\x00FC\\x08\\x92/\\x00\\x1ER\\x08r-\\x00\\xFEa\\x08\\xD6a\\x08r\\x93\\x00\\xFEp\\x08\\xA2p\\x08z\\x86\\x00\\xFE\\x7F\\x08\\x8A\\x7F\\x08\\x0443:\\xF5\\x08J\\x94\\x10\\x05$\\x14reques\\xFE&C^&Cx86a2d4a77c95efdf9919761e255ab39\\x0EHR\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92"
		"!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xFE\\x92!\\xDE\\x92!\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\x1E\\x7F\\x08\\x0E\\x0C*\\xFE\\x7F\\x08\\xFE\\x7F\\x08>\\x7F\\x08\\xFE\\xA7KV\\xA7K\\x0E\\x91X\t\\x01Ni*Z\\x7F\\x08n\\x8B\\x00J\\x7F\\x08\\x8E/\\x00\"\\x7F\\x08n-\\x00\\xFE\\x7F\\x08\\xDA\\x7F\\x08n\\x93\\x00\\xFE\\x7F\\x08\\xA6\\x7F\\x08v\\x86\\x00\\xFE\\x7F\\x08\\x8E\\x7F\\x08\\x006\\x86\\x90"
		"!\\x05$\\x00r\\xFE\\x7F\\x08r\\x7F\\x08x0106cd0c159eb4f1e7918889de78244\\x0ER[\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\x0E\\x8D!\\xFE\\x7F\\x08\\xFE\\x7F\\x08>\\x7F\\x08\\xFE-CV-C\\x009rX\\x00Z\\x7F\\x08n\\x8B\\x00J\\x7F\\x08\\x8E/\\x00\""
		"\\x7F\\x08n-\\x00\\xFE\\x7F\\x08\\xDA\\x7F\\x08n\\x93\\x00\\xFE\\x7F\\x08\\xA6\\x7F\\x08v\\x86\\x00\\xFE\\x7F\\x08\\x8E\\x7F\\x08\\x000\\x8A\\x7F\\x08\\x01$\\xFE\\x7F\\x08v\\x7F\\x08xeec7500495dcb0651786aafded90a82\\x0E\\xFDd\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\x7F\\x08\\xFE\\"
		"x7F\\x08\\x1E\\x8D2\\xFE\\x83\\x08\\xFE\\x83\\x08>\\x83\\x08\\x004\\x16\\xA9\\x10\\x000\\xFE%m6%m\\x009rX\\x00Z\\x83\\x08n\\x8B\\x00J\\x83\\x08\\x8E/\\x00\""
		"\\x83\\x08n-\\x00\\xFE\\x83\\x08\\xDA\\x83\\x08n\\x93\\x00\\xFE\\x83\\x08\\xA6\\x83\\x08v\\x86\\x00\\xFE\\x83\\x08\\x8A\\x83\\x08\\x0466\\x86\\x81\\x19\\x05$\\xFE\\x83\\x08z\\x83\\x08td5d0691ccd800f0f220556020af570\\x0E\\x85l\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\x83\\x08\\xFE\\"
		"x83\\x08\\x12\\x12*\\xFE\\x80\\x08\\xFE\\x80\\x08>\\x80\\x08:\\x03J\\xEE\\xF4!:K\\x00Zf\\x08:&\\x00JY\\x08Z\"\\x00\"L\\x08: \\x00\\xFE?\\x08\\xDA?\\x08"
		":\\x86\\x00\\xFE2\\x08\\xA62\\x08By\\x00\\xFE%\\x08\\x8A%\\x08\\x004\\x8A\\xB5K\\x05$\\xFE%\\x08v%\\x08x6135b4ea1935207e91677816692dbfa\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\xFE\\xA8\\x10\\x0E\\xA8\\x10\\x0Cspla\\xFE\\xD6S\\xFE\\xD6S*\\xD6S\\x089.5\\x1A!*\\xFE\"*>\""
		"*nX\\x00^;\\x08j\\x8B\\x00NH\\x08\\x8A/\\x00&U\\x08j-\\x00\\xFEb\\x08\\xDEb\\x08j\\x93\\x00\\xFEo\\x08\\xAAo\\x08r\\x86\\x00\\xFE|\\x08\\x8A|\\x08\\x0C3609:\\x9A,J$*\r&\\xFE\\x80\\x08v\\x80\\x08xd2f3d162109b8290790e1f716620412\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\xFEW\\\\\\x8EW\\\\"
		">\\x84u\\x0E\\xFEh4elf_monitoring\\x1E\\x8BuJ*\\x00\\x1Cinternal\\x11#\\x12\\x15\\x85\\x0Etz\\x00e.\\xBA\\x85\\x0440\\x0E\\xBA\\x85.\\x07;\\x1A\\x03\\x81f\\xC7\\x85\\x11!\\x08fm_*@\\x87 timestamp.^\\x00\\x10399,\"\\x0EJ\\x83\\x04\":\\x0E\\xBE'\\x1C,\"messag\\x0E\\xB0\\x7F\\x12U\\x81\\x1C31483296\\x12\\x07\\x7F\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0Eg\\x82\\x14 JavaS\\x12/\\x820 tag\\\\\",[]]\"}]&"
		"\\x8D\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82\\xFE\\xE7\\x82>\\xE7\\x82>\\xF1\\x04\\x0E\\x16\\x8B long_taskv\\xF3\\x04\\x003\\x0EE\\x85\\x99\\xF3\\x005\\x0E\\x1D\\x8C~\\xBB\\x8A\\x15[\\x00.\\x1A\\xA0\\x84\\xA1\\x88\\x04\",\\x1D\\x18\\x18attribu\\x0E\n\\x85\\x0E`\\x0C\\x14tainer\\x16\\xF4\\x84\\x8A(\\x00\r"
		"V\\x8A*\\x00\\x08src\\x16\\xFF\\x8A\\x19\\x93V{\\x00\\x1AI\\x87\\x16\n\\x86bY\\x00\ry\\x14unknow\\x0E\\xB4\\x85-\\x0B\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05\\xFE1\\x05B1\\x05V\\xFF\t\\x16\\xB9\\x8F\"\\xFF\t\\x08191>3\\x18B\\x97\\x90\\x10navig\\x0E/\\x8A\\x81.N\\x87\\x05\\x1AW\\x0F\\xB1\\x85\\xAA \\x88b\\xEA\\x89\\x04ne\\xFE\\xA2\\x90\\xF6\\xA2\\x90\\x000\\x86\\xED<\\x0E\\xB1\\x85\\x08"
		"/1.\\x0E\\xD7\\x0F.\\xD9f6\\x9E\\x12%\\x85\\x0C\":37\\xBE\\xD2\\x12z2\\x00:\\xD1\\x12\\x9A.\\x00\\x12\\xD0\\x12z,\\x00\\xDA\\xCF\\x12\\x003~.<6\\xA5\\x90\\x0493z\\xDC\"\r/\\x05\\xB2\\x0494r>\\x01>\\xEE\\x12\\x04106\\xBB+\\x005:F+\\x150\\x05]z\\x0F\\x01\\xA6\\xD5\\x90zI\\x00\\xFA\\xD4\\x90\\x0460>\\x0B=J\\xD7\\x90\\x0457>%\\x00J\\x0C\\x13\t%m\\xB4\\xFEW\\x80ZW\\x80x1b4e517cefee92f74c7cfe6b25d999d\\x0Ed\\x90^\\xB0#\\x12\\x1D\\x8E\\x16\\xC2\\x90\\xCE\\xA7\\x8D\\x18Account\\x1A\\x93\\x8E\\x10;"
		"jses\\x0E\\x12\\x96\\xB8id=B0E9E2EE641BA9253D7C9AE279D8007A?signonForm=Z\\x86\\x95\\x0Eb\\x89\\xB9\\x0E\\x0E[\\x0F\\x04in&a\\x91N\\x1B\\x05\\x19.\\xB1\\x1E.,\\x04\\x1A\\xB2\t\r%\\x00e\\x0EA\\x8F*#k\\x14unload\\x16s\\x0F\\x91I:\\x98\\x042#\\x00E\\xCF:!\\x00\\x08dom\\x16\\x18\\x10\\xA1j\\x00v\\x0E\t\\x10\\x0481rz\\x03\\x011\\x1Ccontent_\\x01\\x7F\\x00e:\\x81\\x00\\x08182r\\x17@b@\\x00\\x05\\x9E\\x081842\\xE7a>\\x0Er\\x10om_co\\x0E\\xE6\\x92\\x00t\\x05\\xAB"
		":\\xB9\\x03\\x01\\x906\\x0F\\x01\\xC1\\xBFn\\xA7/\\x1D2\t\\x80F\\xEF\\x06\\x95\\x0EE8\\x0C\":1,1\\x90\\x08ion1\\xA2\\x08har\\x0E?\\x1E-\\xA9\\x05\\x19\\x04ab!\\x94\\x01\\xA8\\x08\"ex\\x0E\\xAA\\x97\\x04ng\\x1E^\\x90\\x00s\\x0E\\x0E8\\x0E.\\x98\\x14number\\x05T\\xFEf\\x0B\\xFEf\\x0B\\xFEf\\x0B\\xFEf\\x0B\\xFEf\\x0B\\xFEf\\x0B*f\\x0B8battery.level\":\\x0E\\xB2\\x12\\x16\\x1B\\x93\\x1E}"
		"\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xFE\\x98\\x93\\xD6\\x98\\x93\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_14", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3275647597&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551162238$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$rt="
		"1-1779551162238%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb118e0f0g0h0i0m0v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb118e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb118e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb118e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F"
		"%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb119e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb119e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb119e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb119e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Floc"
		"alhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb119e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish_5Ficon.gif%7Cb119e0f0g0h0i0m0v439w439E1F800O40P20I7M-1858137608V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fdogs_5Ficon.gif%7Cb119e0f0g0h0i0m0v468w468E1F920O46P20I7M-39000523V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcats_5Ficon.gif%7Cb119e0f0g0h0i0m0v408w408E1F860O43P20I7M-246443466V0%7Chttp%3A%2F%2Flocal"
		"host%3A8080%2Fjpetstore%2Fimages%2Freptiles_5Ficon.gif%7Cb119e0f0g0h0i0m0v669w669E1F1560O78P20I7M355865488V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fbirds_5Ficon.gif%7Cb120e0f0g0h0i0m0v471w471E1F1000O50P20I7M1303219330V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsplash.gif%7Cb120e0f0g0h0i0m0v36097w36097E1F124250O350P355Q357R347I7M-266518883V0$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi="
		"PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551162385_171$v=10337260504112723$vID=177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551165539", 
		LAST);

	web_reg_find("Text=Welcome", 
		LAST);

	web_reg_find("Text=Welcome", 
		LAST);

	web_reg_find("Text=Various Breeds", 
		LAST);

	lr_think_time(8);

	web_custom_request("rb_bf32608msb_15", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_1_sn_5FD5AE18A27F2D030298B0E6443492DC_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=1&flavor=post&vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=902038206&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551171640%7C_wv_%7CAAI%7C1%7CfIS%7C8062%7CfID%7C1$rId=RID_1078536306$rpId=-296151352$domR=1779551162426$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551162238$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.55$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=PVNPHECWETRFGMPCSGEPUQUKSHRAQNTK-0$fId=551162385_171$v=10337260504112723$vID="
		"177955115375531MFC41L7BDCA9O6K5LD4QJC198ENV9R$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551173645", 
		LAST);

	return 0;
}