Search()
{

	web_url("Catalog.action", 
		"URL=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("rxVisitorf4o018pw=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM; DOMAIN=localhost");

	web_add_cookie("dtSaf4o018pw=-; DOMAIN=localhost");

	web_add_cookie("rxvtf4o018pw=1779553738717|1779551938632; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=4$551938627_465h-vHHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3179702999&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"1%7C1%7C_load_%7C_load_%7C-%7C1779551926719%7C1779551938719%7Cdn%7C89%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C3%7C_event_%7C1779551926719%7C_vc_%7CV%7C11954%5Epc%7CVCD%7C1019%7CVCDS%7C1%7CVCS%7C12059%7CVCO%7C13070%7CVCI%7C0%7CTS%7C0%7CVE%7C654%5Ep106%5Ep124250%5Eps%5Es%23MainImageContent%3Eimg%3Anth-child%282%29%7CS%7C11951%2C2%7C4%7C_event_%7C1779551926719%7C_wv_%7ClcpT%7C-5%7Cfcp%7C11994%7Cfp%7C11994%7Ccls%7C0%7Clt%7C0%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551"
		"938719%7C1779551938719%7Cdn%7C89%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551926719%7C_view_%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_1078536306$rpId=-1058516884$domR=1779551938716$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551926719$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$nt=a0b1779551926719e92f92g92h92i92k6590l6649m6665o11975p11975q11977r11997s12000t12000u6459v6159w6159M-1058516884V0$ni=4g|1.6$egf="
		"1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551938627_465$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$nV=1$nVAT=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551939803", 
		LAST);

	web_custom_request("rb_bf32608msb_2", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3949032844&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551940732&ss=0&qc=3810048901&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xF9\\xC5\\x02D{\"data_version\":2,\\x05\\x11\\xF0\\x96\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"start_time\":1779551933423,\"duration\":5190.3000\\x05\\x03t745,\"performance.initiator_typ\\x01\\x8F\\xF0Xlink\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/\\x15\\x0Eh.css\",\"network.protocol.nam\\x01\\x81\\x01L\\x00\"6\\xA5\\x00(time_origin\\x19\\xEAH26719,\""
		"dt.rum.schem=\\x8C\\x18\"0.23.0:I\\x00\\x00s=2\\x0C67046g\\x00 next_hop_\\x11\\x93\\x08\":\":A\\x004domain_lookup_\\x05O\\x00\"JJ\\x006'\\x00\\x08endN%\\x00\\x18connectfF\\x00\\x11!Z@\\x00\\x18secure_\r&\\x08ion\\x11J\\x0006\\xD7\\x00-\\xB7\\x11\\x1E\\x0C1185n\\x12\\x02\\x1Cresponse\\x1D0\\x0C92.3E?\\x0400FB\\x02\\x150\\x05\\xA7\\x1011894r.\\x00\\x08dir\\x1D\\xF6B\\xAC\\x00\r\\x1F\\x05M:\\x1D\\x00A/\\x04er\\x11\\x98:\\x1D\\x00\\x10fetch\\x11\\x1CF\\xDC\\x018render_blocking\\x01)\\x14tus\":\""
		"\\x11\\x12:\\xE9\\x01\\x14transf\\x01n\\x0Cize\">m\\x000encoded_body_\t\"\\x08601:O\\x02\\x04deZ%\\x00-\\x91(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xE8\\x00tE\\xA1\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.\\x85)|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\xD2N\\xF5\\x03,w3c_resource\r\\xAB\\x00s\\x110m|\\x18applicaA\\x83\t\\x83<ea7c4b59f27d43eb\\x9D\\xD9\\x0Cfram\\x81v\\x00s\\x9D\\xDB@96c882976875e951\"u\\xD6\\x14agent.\\xB5a\\\\\"1.337.9.20260504-112723"
		">1\\x00\\x8D\\xCB$javascript\\x19!\\x00b\\xADa\\x00s%,|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-\\x81q-\\x16\\x00i\r\\xE4)\\x13\\x001\\xB1\\xA0\\xD08630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\",\"device.orienta![L\":\"landscape-primary\\x01\\xA0\\x00e\\x05)Dscreen.width\":1536\\x15D\r\\x1B,height\":960,\\xD5h\\x14window67\\x001#\r\\x1C\\x118\\x08796B8\\x00\t}\\x1C_pixel_rA\\x02\\x10\":1.2\\xC1d\\x10age.u\\xA6\"\\x06\\x04ac\\x01\\xE4$s/Catalog.\t"
		"\\x10a\\x95\\x01I1L\\x00_%\\xB6J0\\x02\\x05& detected_\\xCDJ\\x00/\\xD5sz_\\x00\\x0Ctitl\\xC1{PJPetStore Demo\",\"view:}\\x00<e371f51b0a4e9039\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x05o\\xC6\\xC6\\x00\\x04},\\xFEY\\x08\\xDAY\\x08\\x085.4\\xC1\\x13\\x01\\x01\\x0437%\\xF6nZ\\x08u\\x8BNg\\x04\\xAD\\x14\\x91Z\\xAAN\\x01\\x10ruxit\\x85)"
		"pjs_ICA15789NPRTUVXfqrux_10337\\x891\\x890\\x04.j\\xFE\\x81\\x08\\xFE\\x81\\x08\\x1E\\x81\\x08j*\\x07\\xEE\\x8E\\x08jW\\x00Z\\x9B\\x08j2\\x00\\x1Aa\\x08\\xE13\\x04rt\\x16\\xC9\\x08\\x8A.\\x00\\xE5\\xC1\\xE1\\x88j,\\x00\\xF2\\xC2\\x08\\x007Aw\\x180001118>\\xF1\\x08N\\xC2\\x08\\x81\\x95]\\x9FF\\xB7\\x08\\x009rS\\x00\\x1A\\x98\\x08\\x1A\\xF3\t\\x000>r\\x00\r\\x1F\\x05\\xF6:\\x1D\\x00\\xB6\\xB7\\x08j/\\x01\\xFE\\xC4\\x08\\x82\\xC4\\x08\\x0C1329>\\x15\\x0BJ\\xC6\\x08\\x14362149&"
		"\\xA0\\x08\\x16\\x86\\x08\\x1A\\x1D\\x08\\x1E\\xC8\\x084not_available_\\x1A\\xD5\\x0Bm\\xE6V\\xD2\\x08\\x012\\x04se\\xE1\\xACN!\\x04\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08\\xFE\\x88\\x08v\\x88\\x08\\x008\\xC1\n\\x01\\x01\\x86\\xE1\\x10\\x04im\\x0E\\xEC\rNc\\x04\\x8D\\x9E\\xCA\\x84\\x08Timages/"
		"logo-topbar.gif\\xFE\\xE5\\x10\\xFE\\xE5\\x10\\x1A\\xE5\\x10n\\xA5\t\\xF2e\\x08j\\xFD\t^f\\x08j3\\x00Ng\\x08\\x8A/\\x00\\xE5r\\x12h\\x08j-\\x00\\xE6i\\x08\\x1097.09\r\\x01\\x08627>\\xF7\\x07Fi\\x08\\x088.9A\\x88\\x01\\x01\\x08373Z0\\x00\\x05\\xB5\\x1811900.2\\x01*Z\\xC7\\x08\\x1AU\\x08\\xFEt\\x08\\x86t\\x08j;\\x01bu\\x08\\x0Cnon-\\xFE=\\x11\\x1E=\\x11\\x08380:\\xC4\tNw\\x08\\x05%\\x00r\\x16\\x85\\x14Vu\\x08\\xEE=\\x11\\x12=\\x11x3881223f689a154f0643b8963dcd5a3\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE"
		"=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\xFE=\\x11\\x8E=\\x11>Z\\x08\\x0Eg\\x154elf_monitoring\\x1Ea\\x08J*\\x00\\x1Cinternal\\x11#\\xA5\\xFB\\x0EZ\r\\x00e&\\xF9\\x18\\x1038658.\\xE3\\x19\\x000\"0\\x15f\\x06\\x19\\x1A\\x95\\x14\\x0Csfm_*\\x8F\\x1A\\x0EY\\x19\\x10stamp2^\\x00\\x0C44,\"\\x0E\\xBB\\x16\\x04\":\\xC1\\x9D\\x1C,\"messag\\x0E!\\x13\\x12\\xC6\\x14\\x1C31483296\\x12x\\x12\\x8AB\\x00\\x003.B\\x00\\x18"
		"[\\\\\"OneA\\x0E\\xD8\\x15\\x14 JavaS\\x12\\xA0\\x150 tag\\\\\",[]]\"}]\\x15\\xCE\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xFEX\\x16\\xE2X\\x16\\x00967\\x0BB\\xA4\\x1E\\xFE\\xC3\rj\\xC3\r\\x0Ccart\\xFE\\xBC\r\\xFE\\xBC\r.\\xBC\r:\\xB6\\x14\\xF2\\xB0\r:L\\x00^\\xA4\r:'\\x00N\\x98\rZ#\\x00\\x12\\xD7\\x0C\\x12\\x8C\r:!\\x00\\xE2\\x80\r\\x08902\\xB2\\x80\r\\x010f\\x0C\\x10"
		">\\xF4\\x15\\x08903>\\xAA\\x00\\x00r\\xFEu\r\\xA6u\r:$\\x01\\xFEi\r\\x92i\r\\x0E\\xC4\\x1B.\\x06\\x17Jg\r\\x01#\\xFEe\rve\rx570492c08c75f09b297394998fb21c0\\x0ES\\x1B\\x1A\\xD0\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xFE\\xA2\\x1E\\xEE\\xA2\\x1E\\x12\\xA2\\x1E\\x0E+\"\t"
		"\\x01F'\\x1C\\xFEW\\x08\\xAEW\\x08\\x10separ\\x0Eg'\\xFE\\\\\\x08\\xFE\\\\\\x082\\\\\\x08\\x1A\\xD8\\x14\\x0E\\xD9\\x14:\\x8D\\x06\\xF6h\\x08fX\\x00bt\\x08f3\\x00R\\x80\\x08\\x86/\\x00*\\x8C\\x08f-\\x00\\xF2\\x98\\x08*5\\x15^\\xE8\\x15\\x12\\xBF\\x0F\\x00\"\\x12\\xEA\\x15\\x002\\xBA\\x98\\x08n\\xC6\\x08\\xFE\\x18\\x16\\xA2\\x18\\x16j;\\x01\\xFE\\xAF\\x08\\x92\\xAF\\x08\\x04466\n\\x0CJ\\xAF\\x08\\x01#\\xFE\\xAF\\x08v\\xAF\\x08x348f55f2a3c0905ed28d9435f9189a9\\x0E\\xAF&"
		"\\xFE\\xAF\\x08\\xFE\\xAF\\x08\\xFE\\xAF\\x08\\xFE\\xAF\\x08\\xFE\\xAF\\x08\\xFE\\xAF\\x08\\xFE\\xAF\\x08J\\xAF\\x088battery.level\":\\x0E\\x94\\x0E\\x16\\xEE&\\x1EP'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xFEk'\\xAEk'\\x08239.o\\x06\\x82k'\\xFE!\\x11j!\\x11\\x18sm_fish\\xFE\\xC8\\x08\\xFE\\xC8\\x08.\\xC8\\x08f+\\x07\\xF2\\xC7\\x08fW\\x00^\\xC6\\x08f2\\x00N\\xC5\\x08\\x86.\\x00&\\xC4\\x08f,\\x00\\xE6\\xC3\\x08\\x0443\\xB6"
		"[\\x11\\x004J-\\x11\\x1A\\x00\\x1F\\x05\\xA9\\x1011944\\xFE\\xD0\\x1E\\xFE\\xD0\\x1E\\x16\\xD0\\x1Ef/\\x01\\xFE\\xB7\\x08\\x92\\xB7\\x08\\x08271\\x82\\xB8\\x08\\x05$\\xFE\\xB9\\x08v\\xB9\\x08|060253210f8790b19f045d76c7a63836\\xFE\n0\\xFE\n0\\xFE\n0\\xFE\n0\\xFE\n0\\xFE\n0\\xFE\n0V\n"
		"0\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x08\\xFE\\xB9\\x086\\xB9\\x08\\x0445nE\\x0E\\xFE\\x83\\x11\\xB2\\x83\\x11\\x14m_dogs\\xFE\\xB9\\x08\\xFE\\xB9\\x08.\\xB9\\x08**&>\\xD3\t\\xF2\\xBA\\x08jX\\x00^\\xBB\\x08j3\\x00N\\xBC\\x08\\x8A/\\x00\\x12\\x14\\x08\\x12\r\\x1Aj-\\x00\\xEA\\xBE\\x08\\x007FA\\x19\\x1A\\x8E\\x08&v\\x11\\x04482~"
		"\\x026\\x95\\x07B\\x0E\\x1A\\x0450FS\\x00\\xFEk\\x11\\xA2k\\x11j%\\x01\\xFE\\xB4\\x08\\x92\\xB4\\x08\\x0430\\x86l\\x11\\x05$\\xFE\\xB4\\x08v\\xB4\\x08x78c4449186f15ce3a8d1129d5513f44\\x0ET+\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11\\xFEm\\x11Fm\\x11\\x004.N'\\x005\\x12\\xB4\\x086+"
		"\\x06\\xFE\\xA8\\x08\\xBA\\xA8\\x08\\x18reptile\\xFE\\xAC\\x08\\xFE\\xAC\\x08*\\xAC\\x08\\x0052+\\x10:\\x1E\\x01\\xEA\\xAC\\x08rX\\x00V\\xAC\\x08r3\\x00F\\xAC\\x08\\x92/\\x00\\x1E\\xAC\\x08r-\\x00\\xF2\\xAC\\x08n\\x92\\x10\\xEE\\xB7\\x08\\x1A\\xB7\\x08*\\xE3\\x1A6\\xBA\\x02\\xFE\\xD0\"\\xA2\\xD0\"r;"
		"\\x01\\xFE\\xC2\\x08\\x96\\xC2\\x08\\x009\\x8AD0\\x01$\\xFE\\xC2\\x08z\\xC2\\x08x10e236f5ffa28765b140d44712ee9b4\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11\\xFEv\\x11Rv\\x11>\\xC2\\x08\\x086.3\\xCD\\x13\\x0485:\\x8C\\x16\\xFE\\xCC\\x08\\xBA\\xCC\\x08\\x08cat\\xFE\\xC8\\x08\\xFE\\xC8\\x082\\xC8\\x08\\x0E\\xD30\\x01\\x01F\\x10$\\xF2\\xC7\\x08fW\\x00^"
		"\\xC6\\x08f2\\x00N\\xC5\\x08\\x86.\\x00&\\xC4\\x08f,\\x00\\xEA\\xC3\\x08:\\\\\\x07\"=\\x11&m\\x11\\x005:\\xF8@\\x15#\\x05\\x9A\\x1011951r\\x8E\\x11\\xFEk\\x11\\x9Ak\\x11\\x005j \\x01\\xFE\\xA8\\x08\\x92\\xA8\\x08\\x0428:\\xE0.J\\xD6\"\\x05$\\xFE\\xA8\\x08v\\xA8\\x08|"
		"99b04d0d3be1cf52ac7ae8a395db1efa\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\x9A\\xA8\\x08\\x008\\xFE\\xA8\\x08\\xFE\\xA8\\x08\\x1A\\xA8\\x08\\x0Cbird\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\xFE\\xA9\\x08\\x16\\xA9\\x08rBIBl\\x11"
		">\\x1F\\x0BF\\xB6\\x08v\\x824\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xA2\\xB6\\x08>)\\x01N\\xB6\\x08\\x01$\\xFE\\xB6\\x08z\\xB6\\x08t816f19d7e450737bad8f89b94aa411\\xFE<4\\xFE<4\\xFE<4\\xFE<4\\xFE<4\\xFE<4\\xFE<4Z<4\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFE\\xD4\"\\xFA\\xD4\">^\\x11\\x087.1\\x1A\\xB6\\x08\\x08925:\r\\x19\\xFE_\\x11\\xAE_\\x11\\x0E\\x89+\\x10_icon\\xFE\\xD5\"\\xFE\\xD5\"&\\xD5\"\\x005j~\\x07\\xF2a\\x11f\\x81Z^"
		"a\\x11f2\\x00Na\\x11\\x86.\\x00\\x12\\xC7\\x10\\x0467r\\xE3\\x00\\xEEa\\x11F}\"J\\xAD\\x08.\\x07.^v4\\x05\\xA9\\x0Ep\\x11\\x002FS\\x00\\xFE\\xAF\\x08\\xA2\\xAF\\x08fP\\x01\\xFEe\\x11\\x92e\\x11\\x0443\\x86e\\x11\\x05$\\xFE\\xAF\\x08v\\xAF\\x08x86a2d4a77c95efdf9919761e255ab39\\x0E/Z\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\xFE\\xCF\"\\x86\\xCF\""
		"\\x007j~ \\xFE\\xAF\\x08\\xAE\\xAF\\x08\\x0E\\x7F+\\xFE\\xAF\\x08\\xFE\\xAF\\x08B\\xAF\\x08*\\xC6;\\xFE\\x84+*\\x84+r\\x1A]^\\xB1\\x08j\\x8B\\x00N\\xB2\\x08\\x8A/\\x00\\x12\n\\x08\\x12\\xB3\\x08j-\\x00\\xF2\\xB4\\x08*\\xB7*^\\x8F\\x08*\"\\x1A\\x002>\\x9D\"\\x1A\\xE2\\x08\\x05\\xA8\\x0E\\xB2\\x08\\x003r\\x9D\\x19\\xFE\\xBD\\x08\\xA2\\xBD\\x08j.\\x01\\xFE\\xBE\\x08\\x96\\xBE\\x08\\x006"
		":o\\x1BJm\\x11\\x05$\\x00r\\xFE\\x0ESr\\x0ESx0106cd0c159eb4f1e7918889de78244\\x0Exc\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\x86\\xBE\\x08:\n\\x05\\xFE\\xB1\\x08\\xAE\\xB1\\x08\\x0E\\xBC\""
		"\\xFE\\xB1\\x08\\xFE\\xB1\\x08\\xFE\\xB1\\x08\\xFE\\xB1\\x08\\xFE\\xB1\\x08\\xFE\\xB1\\x08\\xFE\\xB1\\x086\\xB1\\x08\\x009r\\xE4c\\x1A\\x8E\\x08.\\xB1\\x08r\\x90\\x08\r0*\\xBE\\x08*9\\x08B\\x0F\t\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xA6\\xBE\\x08\\x000"
		":\\xB4\\x03N\\xBE\\x08\\x01$\\xFE\\xBE\\x08v\\xBE\\x08xeec7500495dcb0651786aafded90a82\\x0Ebm\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\xFE\\xBE\\x08\\x8A\\xBE\\x08\\xFE+\\x1A\\xFE+\\x1A\\x1A+"
		"\\x1A\\x1ES4\\xFE\\xCF\\x08\\xFE\\xCF\\x08\\xFE\\xCF\\x08\\xFE\\xCF\\x08\\xFE\\xCF\\x08\\xFE\\xCF\\x08\\xFE\\xCF\\x082\\xCF\\x08br+2\\xC2\\x08n\\x8A\\x19F\\xC2\\x08\\xFEK4\\xFEK4\\x12K4*G\t>\\x95\\x13\\xFE\\x80\\x11\\x92\\x80\\x11\\x0466\\x86>\\x1A\\x05$\\xFE\\xC2\\x08z\\xC2\\x08xd5d0691ccd800f0f220556020af570c\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+\\xFE\\xA3+"
		"\\x92\\xA3+\\x088.1\\x0E03\\x0E\\xA3j\\x0E\\xF5q.>\\\\\\xFE\\x8C\\x11\\xAE\\x8C\\x11\\x12\\xA0+\\xFE\\xBE\\x08\\xFE\\xBE\\x08B\\xBE\\x08..\\x07:\t$\\xF2\\xEE\"jX\\x00^>\\x1Aj3\\x00N>\\x1A\\x8A/\\x00\\x12\\xD8\\x10\\x12>\\x1Aj-\\x00\\xE6>\\x1A\\x0450.\\xE8\\x07B/\\x11\\x1A\\x9B\\x08\\xEA\\xCB\\x08n\"v\\xFE\\x8D\\x11\\xA2\\x8D\\x11j;"
		"\\x01\\xFE\\xCB\\x08\\x92\\xCB\\x08\\x004\\x8A\\x8CN\\x05$\\xFE\\xCB\\x08v\\xCB\\x08x6135b4ea1935207e91677816692dbfa\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\xFE\\x8D\\x11\\x9E\\x8D\\x11jY\\x0E\\xFE\\xCD\\x08\\xAE\\xCD\\x08\\x0Cspla\\xFEDW\\xFEDW.DWr\\xA5O\\xFE\\xC9\\x08\\xFE\\xC9\\x08\\xFE\\xC9\\x08"
		"\\xFE\\xC9\\x08\\x8E\\xC9\\x08\\xBA\\x07#r\\x9B\\x08\\x1A\\xF9\\x08\\x12~\t\\x0E\\x14#:W\\x86\\xFE\\xD2E\\xAA\\xD2E\\xFE\\xBC\\x08\\xFE\\xBC\\x08\\x0C3609:\\xD0FJK\\x1A\r&\\xFE\\xC0\\x08v\\xC0\\x08xd2f3d162109b8290790e1f716620412\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`\\xFE\\x05`F\\x05`\\x1E\\xDF\\x8E\"\\xC9\\x8F\\x001\\x0E\\xD7C6@)"
		"B\\xB3\\x08\\x10navig\\x0E\\x87\\x89\\x0E:\\x89>_v\\xF6\\xC3\\x8F\\x16\\x91\\x89J\\xA1\\x89\\xFE\\xC8\\x8F\\xFE\\xC8\\x8F:\\x14\\x01N\\xAE\\x08\\x0E~\\x84\\x08/1.\\xA1\\xA5.\\xBF\\x126J\\x11\\x1Ai\\x10\\x0096\\xEF;\\x004>\\x80\\x062\\x01\\x90\\xE5\\xA4z2\\x00:}\\x11\\x9A.\\x00\\x8EZ\\x00\\xDA{\\x11\\x08659:4\\x01\"\\xF4<-\\x04\\x08664n9k\\x15/\\x05\\xA5\\x08666:\\xFA\\x12\\xFE\\xA2\\x08\\x96\\xA2\\x08zI\\x01b]\\x11\\x96\\xB4~\\x08645:\\x03\\x1AN\\xF4\\x8F\\x001>%\\x00J\\x9F\\x08\t"
		"%\\xFE\\x9E\\x08v\\x9E\\x08x3c50d0c368b06d0c6acae1cd3df7c55n^\\x11\\x12:\\x8D\\x16\\xDF\\x8F.\\xC4\\x8CZ\\x03\\x94\\x0E\\x86\\x87\\x99e\\x0E\\x99z\\x04in&\\x10\\x90Nr\\x04\\x19.\\x1E\\xD4z.\\x83\\x03\\x1A\\xAA\\x8F\r%\\x00e\\x0E\\xF0\\x8D*\\xA4\\x89\\x14unload\\x16\\xB1zQ\\x9C:\\xBB\\x022#\\x00E\\x90:!\\x00\\x08dom\\x16V{\\x81\\xC1\\x00v\\x0EG{\\x0C1974j\\x81\\x0B\\x011\\x1Ccontent_\\x01\\x7F\\x00e:\\x81\\x00\t@f\\xD0Qb@\\x00\\x05\\x9E\\x01>FS\\x04\\x08_co\\x0E\\x89\\x91\\x00t\t"
		"\\x9F\\x0496jP\\x0C\\x01\\x936\\x12\\x01\\x001\\x0E\\x8D:\\x962\\x00\t\\x83FI\\x06u\\xB2\\x08cou\\x0E\\x86\\x92\\x040,1\\x93\\x08ion1\\xA5\\x08harAI-\\xAC\\x05\\x19\\x04ab!\\x97\\x01\\xB7\\x0C\"new\\x1E\\x0B\\x8F\\x00s\\x0E\\x95.\\x0E\\xB9\\x96 number\":1\\xFE\\xD3{\\xFE\\xD3{\\xFE\\xD3{\\xFE\\xD3{\\xFE\\xD3{\\xFE\\xD3{2\\xD3{\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xFEM?\\xEEM?\\x088722\\xBB\\x80\\x0E\\xC9\\x80.\\xF2\\x05B\\xD2\n\\x0Cothe\\x0E\\xE1\\x96N"
		"[\\x06\\xEDT\\xD1X\\x824\\x92\\x08fav\\x12-?\\x08ico\\xFE\\x9B\\x89\\xEE\\x9B\\x89\\x1A\\x9B\\x89\\xA1\\x87\\x009>\\xA1=\\xFE\\xBE\nRU\\x00J\\xB4\nR(\\x00:\\xAA\nr$\\x00\\xD5JB\\xC3\\x00\\xDA\\x96\n\\x1012010j\\x97\\x07\"u\n\\x1A\\xA4\n\\x001\\x0E\\x04\\x98\\x8E0\\x00\\x11\\xAA\\x006J1b\\xFE\\x06\\x1C\\x8E\\x06\\x1CRG\\x01b\\x9E\n\\xA6V\\x89\\x0498:3\\x1DN\\xA1\n>$\\x00N\\xA0\n"
		"\\x01$mKVV\\x89\\x0E\\x99\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xFE\\xCB\\x91\\xCA\\xCB\\x91\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08\\xFE(\\x08Z(\\x08\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_3", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=4108626099&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551926719$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$rt="
		"1-1779551926719%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb6704e0f0g0h0i0k5146l5188m5190v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb6704e0f0g0h0i0k5193l5195m5196v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb6705e0f0g0h0i0k5198l5198m5199v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb6705e0f0g0h0i0k5"
		"198l5198m5199v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb6705e0f0g0h0i0k5238l5239m5239v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb6705e0f0g0h0i0k5243l5244m5246v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb6705e0f0g0h0i0k5243l5244m5246v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore"
		"%2Fimages%2Fsm_5Fcats.gif%7Cb6705e0f0g0h0i0k5243l5245m5246v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb6705e0f0g0h0i0k5243l5246m5247v251w251E1F495O33P15I7M-1591609649V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish_5Ficon.gif%7Cb6705e0f0g0h0i0k5243l5246m5247v439w439E1F800O40P20I7M-1858137608V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fdogs_5Ficon.gif%7Cb6705e0f0g0h0i0k5244l5247m5248v468w468E1F920O46P20I7M-39"
		"000523V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcats_5Ficon.gif%7Cb6705e0f0g0h0i0k5244l5247m5248v408w408E1F860O43P20I7M-246443466V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Freptiles_5Ficon.gif%7Cb6705e0f0g0h0i0k5245l5247m5248v669w669E1F1560O78P20I7M355865488V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fbirds_5Ficon.gif%7Cb6706e0f0g0h0i0k5245l5247m5248v471w471E1F1000O50P20I7M1303219330V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsplash.gif%7Cb6"
		"706e0f0g0h0i0k5245l5247m5248v36097w36097E2F124250O350P355Q357R347I7M-266518883V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Ffavicon.ico%7Cb12010e0f0g0h0i0k1l17m58u983v683w683I22$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551938627_465$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time="
		"1779551941812", 
		LAST);

	lr_start_transaction("Search_Transaction");

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CSearch%7C-%7C1779551957432%7C551938627_465%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%7C; DOMAIN=localhost");

	lr_think_time(15);

	web_submit_data("Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Action=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=keyword", "Value=", ENDITEM, 
		"Name=searchProducts", "Value=Search", ENDITEM, 
		"Name=_sourcePage", "Value=4w7x4brvdcJFkSFGh7AnpanZGY_ihgv-T4x_g7NoQ93CE0nBsBIdoJL68hg1iiSEDzWW4nV2mpaPcJIkUA6V6q_nNyKDIPa9", ENDITEM, 
		"Name=__fp", "Value=HN_IfeZzmnxxR_s-ydw-ZzgPTk3IfjOQ4i4QZkYCrD7juqi_MNr75iD8CMH9beHQ", ENDITEM, 
		LAST);

	web_custom_request("rb_bf32608msb_4", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1679147176&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551957438%7C_wv_%7CAAI%7C1%7CfIS%7C29916%7CfID%7C2%2C1%7C7%7C_event_%7C1779551958080%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551926719%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C8%7C_event_%7C1779551958080%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$rId=RID_1078536306$rpId=-1058516884$domR=1779551938716$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551926719$tvm="
		"i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551938627_465$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$nV=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551958084", 
		LAST);

	web_custom_request("rb_bf32608msb_5", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3495390667&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551958092&ss=1&qc=3607670295&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xA8.D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11?,_time\":31368\r\\x1D\\x0Cback\t\\\\\r\\x1D\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!#8us\":\"reported\",\\x05\\x18)^:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x11\\x0E\\x1C11993.5,\\x05\\x14\\x1Cloading_\\x01W!z"
		",dom_content_\\x01\\x1C\\x05`\\x01=\\x01!>x\\x00\\x08fidb\\x18\\x00\\x01=.Y\\x00$complete\",\\x117\\x04rt-\\x81\\x1C29916.20\t\\x01\\x0C1118\t$\\x08dur%?\\x0C\":16\t\\x12\\x04na!\\xCE,\"pointerdown\rO\\x18process\rq\\x08rt\"\\x05U\\x048.\tS\\x14001863\tC\\x1D*\\x08end\\x15(\\x009\r\\x01\\x08627\t(<cancelable\":true\t\\x168ui_element.tag_\r\\x90\\x10INPUT\r\\x8A\\x1D\"\\xA8xpath\":[\"html\",\"body\",\"div[@id=\\\\\"Header\\\\\"]\".\\x16\\x00\\x14SearchV\\x16\\x00\\x00C)\\x9B\t\\x1DLform\",\"input[2"
		"]\"],\"fJ\\xE6\\x01\\x00pB\\x8C\\x01V\\xE5\\x01\\x00pR\\xCC\\x01\\x04in\\x1D\\x184below_thresholA{\\x04lc\\x1D\\x1F]\\x93\\x01\\x186\\x93\\x02\\x041,\\x05\\x15\\x04st9\\xF9\\x1812014.2\t\\x19A1M\\x11A\\xA2\\x101.599\t\\x1A(size\":12387\r\\x12\\x14url\":\"a$\\xB8://localhost:8080/jpetstore/images/splash.gif\",\\x05\\x83\\x1Cresource\tsYf\\x145248.4Q3\\x0C3725\t\\x80=\\xD3<render_delay\":60U\\xB6\\x01\\x01\\x0473\t0:`\\x00\t,"
		"\\x0C56.3Md\\x188509884\\x11-\\x05R\\x89\\xA82\\x11\\x01\\x1Dw.l\\x02\\x04MG\r\\xC7\\x1D \\x82j\\x0228\\x02Y\\x81\\x0CMainIL6\\x14\\x00\\x00I!:b\\x19\\x002M\\x00\\x08imgAy long_task!\\xE1\\x89)\\x0Cnot_]\\x12\\x0Cttfb\\x19\\x1D>\\x19\\x00\\x8D\\xAA\\x0C66495T\\x89\n\\x058\\x0Cwaita\\xDD9\\xAD\\x0C92.0-Pa\\xB5\\x0847,\t*\\x10cache\\x1D(\\x000\r\\x18\\x08dnsJ\\x16\\x00\\x14connec\\xA5\\xA4\\x19[\\x113\\x18request\\x1D\\x1A\\x146557.1!\\xEC\\x81T\\x1849,\""
		"pera\\x87\\x81-\\x14.activ\\x85\\xB2\\xA1O\\x00r\\xC9B\\x00v\\xC1\\x91\\x00s\\x01J(nce_number\"a\r\\x05\\x19\\x08preMSI\\x01X0,\"characteristics.has_\\x01,\\x1C_summary\\x91\\x8F\\x10navig\\x05n\\xE1\\x1A\\x01r\\xA5\\xC1\\x10new\",2\\x1D\\x00 ype\":\"hara\\xB0.\\xB0\\x00\\x01s\\x14_origi\\xA1c4779551926719,\"2\\xA7\\x036\\x1B\\x009)\\xEDW,dt.rum.schem\\xFD\\xFB\\x18\"0.23.0\\x81\\xF2\t!\\x14applic\t\\xB3\\x04id\\xE1\\xC0Ha7c4b59f27d43eb\",\"b\\xED\\xED\\x18frame.i2\\xEF\\x07"
		"<96c882976875e951\\x1DZ\\x00g\\xA1\\x92\"u\\x08\\x18\"1.337.AJ0260504-112723>1\\x00-\\x1B$javascript\\x19!\\x11\\x88\\x00s\\x05\\xA9|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16\\x11\\xE4)\\x13\\x001-l\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE4\\x04,\"\r)8battery.level\":\\xA1c\r\\x1A$screen.wid\\xC1\\xB5\\x0C1536\\x155\r\\x1B(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x08796B8\\x00\t}"
		"\\x1C_pixel_r\\x01\\xC1\\x0C\":1.\\xA1z0page.url.fullA\\xC1\\x04ttr\\xEE\\x05\\x00ae\\xC7 s/Cataloge\\x8E\\x00o\\x0E \\x08\\x05I1f\\x00_%\\xD0\\x0496BJ\\x02\\x05&\\x1Cdetected\\xF1\\xD9\\xDDMv_\\x00\\x08tit\\x0E)\\x08\\x14\"JPetS\\xC1}\\x18 Demo\",i\\xE66}\\x00<e371f51b0a4e9039\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x00v\\x81n\\xC6\\xC6\\x00\\x04},\\xFE\\x87\\x0B:\\x87\\x0B%N&\\xC6\\x0B\\x8D\\xDE\\x810\\xA14"
		"!\\xDA\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xFE\\x87\\x0B\\xBA\\x87\\x0BNV\\x0B\\xC1\\x88\\x00_:V\\x0B\\x01\\x14N\\x96\\x0B\\xFEn\\x0B\\xFEn\\x0B\\x1An\\x0B\\x049,"
		"\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\xFEn\\x0B\\x0En\\x0B\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779553758182|1779551938632; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=4$551958129_869h-vHHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_6", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1744574938&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CSearch%7CC%7C-%7C551938627_465%7C1779551957432%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%2Fjpetstore%2Factions%2FCatalog.action%7C1779551926719%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551957438%7C1779551958184%7Cdn%7C58%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%2C2%7C3%7C_event_%7C1779551957438%7C_vc_%7CV%7C732%5Epc%7CVCD%7C1020%7CVCDS%7C0%7CVCS%7C801%7"
		"CVCO%7C1814%7CVCI%7C0%7CTS%7C1%7CVE%7C491%5Ep168%5Ep67947%5Eps%5Es%23Banner%7CS%7C731%2C2%7C4%7C_event_%7C1779551957438%7C_wv_%7ClcpT%7C-5%7Cfcp%7C-6%7Cfp%7C-6%7Ccls%7C0%7Clt%7C60%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551958184%7C1779551958184%7Cdn%7C58%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551957438%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551926719%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5"
		"Esh0$dO=localhost,$rId=RID_1338253259$rpId=-2095100744$domR=1779551958180$tvn=%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551957438$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$nt=a0b1779551957438e10f10g10h10i10k12l638m639o732p733q736r742s746t746u4171v3871w3871M-2095100744V0$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title="
		"JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551958129_869$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551959264", 
		LAST);

	web_custom_request("rb_bf32608msb_7", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=2265783772&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551960198&ss=0&qc=3234485776&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\x96\\xE5\\x01D{\"data_version\":2,\\x05\\x11\\xF4,\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"start_time\":1779551958101,\"duration\":0,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x08\",\".\\xA5\\x00(time_origin\\x1D\\xDAD7438,\"dt.rum.schem=|\\x18\"0.23.0:I\\x00\\x00s=\""
		"\\x086636f\\x00(next_hop_pr\t\\x92\\x08\":\":@\\x004domain_lookup_\\x05N\\x00\"FI\\x006&\\x00\\x08endJ$\\x00\\x18connectbD\\x00\\x11 V>\\x00\\x18secure_\r%\\x08ion\\x11H\\x0006\\xD3\\x00-\\xB2b\\x1E\\x00\\x14sponse~\\x1F\\x00V\\x84\\x00\\x10redir\\x1D\\xC3B{\\x00\r\\x1F\\x05>:\\x1D\\x00\\x14workerZx\\x00\\x10fetch\\x11\\x1CB\\xA6\\x018render_blocking\\x01(\\x14tus\":\"\\x11\\x12:\\xB3\\x01\\x14transf\\x01m\\x0Cize\">\\x89\\x000encoded_body_\t\"\\x0C60146F\\x01\\x04deZ%\\x00-_"
		"(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xB6\\x00tEk\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.e\\xE2|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\x9BN\\xBE\\x03,w3c_resource\r\\xAB\\x00s\\x110mE\\x18applicaAQ\t\\x83<ea7c4b59f27d43eb\\x9D\\x92\\x10frame>\\x94\\x04<2bdfeb8975cfed7\"u\\x9F\\x14agent.\\xB5\\x1A\\\\\"1.337.9.20260504-112723>1\\x00\\x04ty\\x85\\x94$javascript\\x19!\\x00b\\xAD\\x1A\\x00s%,|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t"
		"0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-\\x81:-\\x16\\x00i\\xADx)\\x13\\x001\\xADY\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[L\":\"landscape-primary\\x19)Lscreen.width\":1536,\"\rD\r\\x1B,height\":960,\\xD5!\\x14window67\\x001#\r\\x1C\\x118\\x08796B8\\x00\tb\\x1C_pixel_r\\x01\\xA74\":1.25,\"page.u\\xA6\\xEB\\x05\\x04acA?$s/Catalog.\t\\x10\\x10;jses\\xE1\\x16\\x88id=E81E6C649276A0CA5A2415B36BA98F99a\\xC1\\x01u1x\\x00_%\\xE2J\\\\\\x02\\x05&$detected_n\\xC9?\\x00/\\xD9v\t"
		"{\\xFE\\x8B\\x00\\x01\\x8B\\x0Ctitl\\xE1\\x9CPJPetStore Demo\",\"view:\\xA9\\x00827e683efd3d3059a\\x05\\x05&\\x00u\\xFED\\x01\\xBAD\\x01\\x05u\\xFE\\x1E\\x01v\\x1E\\x01\\x04},\\xFE\\xC2\\x08\\xFE\\xC2\\x08N\\xC2\\x08\\x95*N\\x06\\x05\\xAD\\xB3\\x91\\xF9\\xAA\\x95\\x01\\x10ruxit\\x85\\xC8pjs_ICA15789NPRTUVXfqrux_10337\\x89\\xD0\\x89\\xCF\\x0C.js\"\\xFE\\xE9\\x08\\xFE\\xE9\\x08\\x12\\xE9\\x08\\x08.09\t\\x01\\x10776486\\xDE\\x06\\xEA\\xF7\\x08nW\\x00V\\x05\t"
		"n2\\x00\\x1A\\xCE\\x08\\xE1\\xD2\\x04rt\\x123\t\\x8E.\\x00\\x12_\\x08\\x0466r,\\x00\\xFE/\t\\xD6/\tn\\xBE\\x00\\xFE=\t\\xA2=\tv\\x85\\x00\\xFEK\tzK\t\\x1013290\\x86M\t\\x14362149&'\t\\x16\r\t\\x1A\\xA4\\x08\\x1EO\t@not_available_htt\\x0E%\\x0C\\x18requestVY\t\\x012\\x04se\\x0E3\\x08N\t\\x04\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t"
		"\\xFE\\x0F\t\\xFE\\x0F\t\\xA2\\x0F\t\\x04im\\x0E\\x13\\x0FN\\x03\\x05\\xAD>\\xCA\\x0C\tTimages/logo-topbar.gif\\xFE\\xEC\\x08\\xFE\\xEC\\x08\\x1A\\xEC\\x08\\x002\\x16\\xEB\\x08\\x1097019\\xFE\\xEC\\x08*\\xEC\\x08jW\\x00Z\\xEC\\x08j2\\x00J\\xEC\\x08\\x8A.\\x00\"\\xEC\\x08j,\\x00\\xFE\\xEC\\x08\\xDA\\xEC\\x08j\\x92\\x00\\xFE\\xEC\\x08\\xA6\\xEC\\x08r\\x85\\x00Z\\xEC\\x08\\x0Cnon-\\xFE;\\x12\\x1E;\\x12\\x08380:q\\x02J;\\x12\t%m|V\\xEC\\x08\\xEE;\\x12\\x12;\\x12x3881223f689a154f0643b8963dcd5a3\\xFE;"
		"\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12b;\\x12\\xFE,\tj,\t\\x0Ccart\\xFE%\t\\xFE%\t*%\t\\x003\\x1A%\t\\x1085099\\xFE\\x11\\x12&\\x11\\x12jW\\x00Z%\tj2\\x00J%\t\\x8A.\\x00\"%\tj,\\x00\\xFE%\t\\xDA%\tj\\x92\\x00\\xFE%\t\\xA6%\tr\\x85\\x00\\xFE%\t\\x8A%\t\\x0E~\\x18.\\xDD\\x1DJ#\t\\x01#\\xFE!\tv!\t|"
		"570492c08c75f09b297394998fb21c09\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B^\\\\\\x1B\\xFE!\tj!\t\\x1Cseparato\\xFEK\\x12\\xFEK\\x12.K\\x12j,\\x07\\xEE7\\x1BjW\\x00\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\x1E&\t\\x04466\\x95\\x0BJ&\t"
		"\\x01#\\xFE&\tv&\t|348f55f2a3c0905ed28d9435f9189a91\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xCE&\t\\x14m_fish\\xFEJ\\x12\\xFEJ\\x12*J\\x12\\x005\\x1AJ\\x12\\xFE[$:[$jW\\x00Z$\tj2\\x00JJ\\x12\\x8A.\\x00\"J\\x12j,\\x00\\xFEJ\\x12\\xDAJ\\x12j\\x92\\x00\\xFEJ\\x12\\xA6J\\x12r\\x85\\x00\\xFEJ\\x12\\x8AJ\\x12\\x08271\\x82%\t\\x05$\\xFE&\tv&\t|"
		"060253210f8790b19f045d76c7a63836\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xD6&\t\\x0Cdogs\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\x12&\t\\x0430\\x86K\\x12\\x05$\\xFE&\tv&\tx78c4449186f15ce3a8d1129d5513f44\\x0E="
		"(\\x1A\\xFC6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE6\\xFE\\xCE66\\xCE6\\xFEr\\x1Bnr\\x1B m_reptile\\xFE*\t\\xFE*\t.*\t\\x006\\x1AP\\x12\\x08925\\x0E\\x154.+\"\\xEEt\\x1BjW\\x00ZP\\x12j2\\x00JP\\x12\\x8A.\\x00\"P\\x12j,"
		"\\x00\\xFEP\\x12\\xDAP\\x12j\\x92\\x00\\xFEP\\x12\\xA6P\\x12r\\x85\\x00\\xFEP\\x12\\x8AP\\x12\\x0439\\x8A\\xBE-\\x01$\\xFE*\tz*\tx10e236f5ffa28765b140d44712ee9b4\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xFEP\\x12\\xD6P\\x12\\x08cat\\xFE&\t\\xFE&\t.&\t\\x008\\x1A&\t\\xFE\\xC0-:\\xC0-jW\\x00Z&\tj2\\x00J&\t\\x8A.\\x00\"&\tj"
		",\\x00\\xFE&\t\\xDA&\tj\\x92\\x00\\xFE&\t\\xA6&\tr\\x85\\x00\\xFE&\t\\x8A&\t\\x0428:00J\\x9B$\\x05$\\xFE&\tv&\t|99b04d0d3be1cf52ac7ae8a395db1efa\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xAA&\t\\x0EhR\\xA2\\xE0Q\\xFEP\\x12vP\\x12\\x0Cbird\\xFE'\t\\xFE'\t&'\t\\x0046\\x1F\"\\xE6?\\x12:I\\x00R\\x0B\t:$\\x00B\\xFD\\x08Z \\x00\\x1A\\xEF\\x08:\\x1E\\x00\\xFE\\xE1\\x08\\xD2\\xE1\\x08"
		":\\x84\\x00\\xFE\\xD3\\x08\\x9E\\xD3\\x08Bw\\x00\\xFE\\xC5\\x08\\x8E\\xC5\\x08\\x005\\x8A;$\\x01$\\xFE\\xC5\\x08z\\xC5\\x08t816f19d7e450737bad8f89b94aa411\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876\\xFE\\x876N\\x876>\\x89H\\x0E\\xEF\\x1F4elf_monitoring\\x1E\\x90HJ*\\x00\\x1Cinternal\\x11#\\x12\\x82Y\\x0E)N\\x00e*\\x18Z\\x0C8159"
		":\\xF2Z\\x1A\\xCAUf%Z\\x11!\\x08fm_*\\x9E[ timestamp2^\\x00\\x0Ex3\\x0E\\x11X4\":2000,\"messag\\x0E\\x1FT\\x12\\x1CV\\x1C31483296\\x12\\x1ESZB\\x00\\x047,\\x19B\\x003.B\\x00\\x18[\\\\\"OneA\\x0E.W\\x14 JavaS\\x12\\xF6V0 tag\\\\\",[]]\"}]&TW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW\\xFE\\xAEW>\\xA1\\x05\\x0E$` long_taskz\\xA3\\x05\\x0E\\x17T&"
		"\\xB5\\x0E\\x0E\\xCAZ\\xB1\\x83b\\xC9_\\x15[\\x00.\\x1A\\xEBY\\xC18\\x04\",\\x1D\\x18\\x18attribu\\x0E\\x81Z\\x0E\\x80\r\\x14tainer\\x16?Z\\x8A(\\x00\rV\\x8A*\\x00\\x08src\\x16\\x1C`\\x19\\x93V{\\x00\\x1A\\xC0\\\\\\x16\\x81[bY\\x00\ry\\x1Cunknown\""
		"\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xB9\\xE1R_\\x0B\\x1Awe\"q\\x14\\x08746n\\xD1@Baf\\x10navig\\x0Eb`\\x81\\xEANC\\x06\\x1As\\x11\\xD1A\\xAA\\xA3]\\xFE\\xF1_\\x12\\xF1_\\x04ne\\xFE\\x98f\\xF6\\x98f\\x000\\x86\\xB5\\x14\\x0E\\xFEZ\\x08/1.\\x0E\\x80?"
		".\\x1F'6\\x97\\x14%\\xBD\\x14\":10.1\\x1A,\\x1E\\x009\\x0ER'\\x04426`\\x0065\\x00\\x12\\x8E\\x14~3\\x00:\\xDB\\x14\\x9E/\\x00\\x92\\\\\\x00\\xDA\\xF9\\x14\\x04126\\xE9\\\\\\x002:\\xF4.\\x00r:\\xEBf\\x08637v\\xBF8\\x1A\\x1Ag\\x05\\xB4\\x086396D\\x016B\\x01\\xFE(\\x15\\x96(\\x15~f\\x01\\xFA\\x18g\\x0441>M9J\\x1Bg\\x0438>%\\x00J\\xFC\\x1D\t%m\\xC5\\xFE\\xE0TZ\\xE0T|2cb7b1d6fac4d63b48ffb13e7a617108j\\xFD\\x1D\\x125d\\x16\\x06g\\xEE\\x93c\\x16\\x93cZ)k\\x0E\\\\^\\x99\\xE7\\x0E\\xA0\\x10\\x04in&"
		"mgN\\xF4\\x04\\x19.\\x91\\xF7.\\xD9\\x03\\x1AG\n\r%\\x00e\\x0E!e\\x04er\"\\xC3k\\x14unload\\x16\\xB8\\x10q\\xF6:E\\x042#\\x00E\\xD4:!\\x00\\x08dom\\x16]\\x11\\xA1C\\x14ve\":73F(\\x04\\x0Epj\\x10tent_\\x01p\\x00e:r\\x00\\x0C732.\\x0E/f\\x1D\\x99\\x01U\\x04coJ3\\x00\\x05\\x82\\x087366\\xB4\\x036V\\x03\t=\\x0E\\xD6h\\x00t\\x01\\x8F\\x004:\\xE1\\x036-\\x00\\x01\\x916\\x01\\x01\\xC1\\x96\\x000\\x8D\\xF8J\\x9A>\\x1D1\t\\x8Dv\\xC5\\x06u\\xE3\\x08cou\\x0E\\xDDi\\x040,"
		"1\\x8D\\x08ion1\\x9F\\x08har\\x0E\\xEDi-\\xA6\\x05\\x19\\x04ab!\\x91\\x01\\xC1\\x08\"ex\\x0EJm\\x04ng\\x1E5f\\x00s\\x0E\\xBB`\\x0E\\xCEm number\":1\\xFE\\xF8\\x0B\\xFE\\xF8\\x0B\\xFE\\xF8\\x0B\\xFE\\xF8\\x0B\\xFE\\xF8\\x0B\\xFE\\xF8\\x0B2\\xF8\\x0B8battery.level\":\\x0E$S\\x16$i\\x1E\\x86i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\xFE\\xA1i\\x96\\xA1i\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_8", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=2286841549&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551957438$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$rt="
		"1-1779551957438%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb663e0f0g0h0i0m0v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb663e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb663e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb663e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F"
		"%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb664e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb664e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb664e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb664e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Floc"
		"alhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb664e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551958129_869$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551961286", 
		LAST);

	web_custom_request("rb_bf32608msb_9", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=676692714&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C9%7C_event_%7C1779551964738%7C_view_%7Ctvtrg%7C1%7Ctvm%7Ci2%5Esk2%5Esh0$rId=RID_1078536306$rpId=-1058516884$domR=1779551938716$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551964738$tvm=i2%3Bk2%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551938627_465$v=10337260504112723$vID="
		"1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$nV=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551964746", 
		LAST);

	web_custom_request("rb_bf32608msb_10", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1827701163&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551964756%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7Csvt%7C1779551957438%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C7%7C_event_%7C1779551964756%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$rId=RID_1338253259$rpId=-2095100744$domR=1779551958180$tvn="
		"%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551957438$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551958129_869$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551964760", 
		LAST);

	web_custom_request("rb_bf32608msb_11", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3289484076&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551964786&ss=1&qc=241251252&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xCC.D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11?(_time\":7343\r\\x1C\\x0Cback\t[\r\\x1C\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!\"8us\":\"reported\",\\x05\\x18)]:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x11\\x0E\\x14759.79\t\\x01\\x1470198,"
		"\\x05\\x1E\\x1Cloading_\\x01a!\\x83 complete\"\t\\x1F\\x01\\x17>x\\x00\\x08fid\\x19\\x18\\x0Cnot_\\x1D\\x94\\x00frp\\x00\\x00pro\\x00\\x00p\\x19V\\x1DR\\x04in\\x1D\\x184below_threshol!\\x05\\x04lc\\x1D\\x1F\\x1D7\\x01\\x186\\x1D\\x01\\x041,\\x05\\x15\\x10startM\\x04-\\x14\t\\x19!\n\\x11\\x18\\x0433!,\t\\x18(size\":17220\t\\x11\\x14url\":\"!\\xAB\\xC8://localhost:8080/jpetstore/images/logo-topbar.gif\"\tC\\x1Cresource\tu\\x08durE1%\\xB3\\x05\\xB9xi_element.render_delay\""
		":96.4990\\x01\\x01\\x1029802\r\\xD4:O\\x00\t,\\x0C25.6)\\xEF\\x1C99254942\\x11|\\x05Rm\"I\\x16\t\\x1A\\x1Dw\\x14tag_naaD\\x10\"IMG\"B \\x000xpath\":[\"htmla\\xAD`ody\",\"div[@id=\\\\\"Header\\\\\"]2\\x16\\x00\\x0CLogoN\\x14\\x00\\x18Content\t\\x1BLa\",\"img\"],\"long_task!\\xB7B\\x89\\x02\\x19\\x1E\\x0Call.m\\xBF!\\x13\\x156\\x01\\x18\\x08avg=b\\x006!\\xC52 \\x00@slowest_occurrenc\\x81\\xAC\\x08[{\".)\\x02\\x10666,\"9\\xA7\\x0860}6\\x9D\\x00\\x08elfR\\x80\\x00\\x05\\x19n\\x81\\x00\\x05"
		"!\\xE2\\x82\\x00\\x0CttfbR\\x1A\\x01\\x05\\x19\\x00v\\x89\\x07\\x10637.5M\t\\x1477648,\t\\x1F\\x0Cwaita\\xFA\\x19\\xD7\\x0C10.1\r)U2\\x05J\\x10cache\\x1D)\\x000\rC\\x08dnsJ\\x16\\x00\\x14connec\\xA5\\x02\\x19\\\\\\x113\\x0Crequ!n\\x19\\x1A\\x10627.3\rw\\\\85099,\"performance.active\\x1F\\x81\\xA4\\x00r\\xA9\\xA1\\x00v\\xA1\\xEF\\x00s\\x01K(nce_number\"!\\xFB\\x05\\x19\\x08prem7I\\xE5X0,\"characteristics.has_\\x01,P_summary\":true,\"navig\\x05n\\xC1x\\x01r\\xA5\\x16\\x04ex\\x018\\x08ng\"6\""
		"\\x00\\x04yp\\xA13\\x08har\\x81\\x8A.\\xB5\\x00\\x01x\\x18_origin\\x81;,79551957438,2X\\x02\\x0016\\x1B\\x009\\x15\\xC9\\xBA,dt.rum.schem\\xFD]\\x18\"0.23.0aZ\t!\\x14applic\t\\xB7\\x04id\\xE1\"@a7c4b59f27d43eb\",\\xF5O\\x18frame.i6Q\\x0782bdfeb8975cfed7\\x1DZ\\x00g\\x81\\x85\\xF5\\xD7\\\\\"1.337.9.20260504-112723>1\\x00\\x00t)\\x1A$javascript\\x19!\\x00b\\xED\\xD7\\x00s\\x05\\xA9|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16\\x11\\xE4)"
		"\\x131k\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE8\\x04,\"\r)8battery.level\":A\\xC7\r\\x1A$screen.wid\\xA13\\x08153\\x81L\t^\r\\x1B\\x14height\\xA1\\xDF\\x0009\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x08842B8\\x00\tb\\x1C_pixel_r\\x01\\xC1P\":1.25,\"page.url.full\\x8A\\xCA\\x06\\x00ae\\xCC s/Cataloge\\x92\\x18on;jses\\x0E\\xED\t\\x90id=E81E6C649276A0CA5A2415B36BA98F99\",\t"
		"u1\\x92\\x00_%\\xFCJv\\x02\\x05\\x9B\\x1Cdetected\\xD1\\x81\\xFDU\\xFE\\x8B\\x00\\x19\\x8B0title\":\"JPetS\\xE1\\xB1\\x14 Demo\"\\x1A.\n6\\xA9\\x00827e683efd3d3059a\\x1F\\x00v\\x81\\x81\\x00u\\xFED\\x01\\xBAD\\x01\\x05u\\xFE\\x1E\\x01v\\x1E\\x01\\x04},\\xFE\\x99\\x0B:\\x99\\x0B%\\xD2&"
		"\\xD8\\x0B\\xAD\\x92\\x0C7344M\\x89\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B\\xFE\\x99\\x0B6\\x99\\x0BNh\\x0B\\xC1\\x03\\x00_:h\\x0B\\x01\\x14N\\xA8\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B*\\x80\\x0B\\x044,"
		"\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xFE\\x80\\x0B\\xCE\\x80\\x0B\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_12", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=4294341731&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551966761&ss=0&qc=11281098&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xE6\\x1DD{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11? _time\":10\r\\x1A\\x0Cback\tY\r\\x1Ap6642,\"error.http_4xx_count\":02\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!#8us\":\"reported\",\\x05\\x18)^:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x19;\\x0Cnot_\\x1D?"
		"\\x08fidf\\x1C\\x00f7\\x00\\x04in\\x1D\\x1C4below_threshol\\x01\\x95\\x00l.r\\x009x\\x05\\xB1 long_taskbx\\x00\\x0Cttfbb\\x1D\\x00@performance.activ)f\\x0Cstar)\\xB7\\x00vA\\x06Dsequence_number\":1M\\x05 prerenderM\\x04X0,\"characteristics.has_\\x01E4_summary\":true\r@\\x00i6\\x85\\x02<371f51b0a4e9039\"\r&(url.full\":\"!\\xCDl://localhost:8080/jpetstore/\\x01\\xC4(ons/Catalog\\x05\\xD4\\x04on\\x11I(detected_naA\\xCC\\x00\"\\x8E9\\x00\\x10navig%\\x16a7!\\x1A\\x00taX\\x04ex\\x01\\xE0\\x0Cng\",2\""
		"\\x00\\x04yp\\x01\\x1D\\x08har!\\xB8.]\\x01a>\\\\_origin\":1779551926719,\"%n-B\\x11\\x1B$58087,\"dur\\x05|\\x10\":665\\x81\\x02,t.rum.schema\\x99\\x1C$\"0.23.0\",\"\r!\\x14applic\\x05;d.id\":\"ea7c4b59f27d43eb\",\"b\\x8D\\x0E\\x10frame:\\x8B\\x01<96c882976875e951\\x1DZ\\x10gent.\\x95\\x96\\\\\"1.337.9.20260504-112723>1\\x00-\\x1A$javascript\\x19!\\x11\\x88\\x00s\\x05\\xA9|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16Qo)\\x13\\x0417)"
		"\\x86\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE\\xE0\\x04,\"\r)@battery.level\":99\\x15\\x1ADscreen.width\":1536>\\x1B\\x00(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x08796B8\\x00\t\\x97\\x18_pixel_EW0\":1.25,\"page.\\xFEf\\x03af\\x05I1f\\x00_%\\xD0\\x0496BJ\\x02\\x05&\\xCE\\x8C\\x03\\x059\\x0Ctitlae\\x10JPetSa\\xF5\\x1C Demo\"},\\xFE\\x00\\x07"
		":\\x00\\x07.\\xF9\\x03i\\xD7\\x08sofA\\xB7.\\x19\\x00\\x04abN\\x12\\x04N\\x04\\x05\\x196\\xB1\\x02\\x0Cstar>\\xF7\\x03\\x1064738.\\xF7\\x03\\x000u\\xD3f\\xF4\\x03\\x0CviewF\\xA4\\x05\\x002\\xAD>6\\x8F\\x01<fb67c76cd1bca56f\\xB1\\x1B\\xFE\\xFE\\x01!\\xFE\\x05\\x88\\xCE\\xD8\\x01\\x059\\x10sourc\\xEE\\x87\\x02M\\x87\\xA8;jsessionid=E81E6C649276A0CA5A2415B36BA98F9\\xD5b\r|\\xC2\\xBC\\x00\\xBAl\\x00N\\x18\\x02$user_actioU\\x19\\x00u\\x19\\x13:\\xBE\\x01Dada5b3cd362e0dde\","
		"2-\\x00\\x04mu\\x89\\x98*\\xBC\\x08.L\\x00\\x00r\\xE1\\xC7,sts.pending_\r\\x11~/\\x00\\x00d\\x0E\\x88\n\\x08url\\x9E0\\x00&\\xF5\t6~\\x00)f\\x00s\\x1D \\x00l\\x82\\xBE\\x08z\\x1B\t\\x00cZ\\xC8\t23\t\\xAA\\xA5\t\\x01P\\x00u\\x12^\\x0B=\\x15\\x01\\x15&\\x00\n\\x00u=\\x9E4complete_reaso\\xC1\\x10\\x04no%\\xCD\\x0Cvity:\\x9D\\x01\\x9DE.\r\\x04u\\xE0\\x00a\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFA\\xB3\\x07\\x008\\x0E?\r"
		":\\xCF\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07\\xFE\\xB3\\x07z\\xB3\\x07\\x08]}}", 
		LAST);

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CSearch%7C-%7C1779551973164%7C551938627_465%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%7C; DOMAIN=localhost");

	web_reg_find("Text=FI-FW-02", 
		LAST);

	lr_think_time(6);

	web_submit_data("Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99_2", 
		"Action=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=keyword", "Value=fish", ENDITEM, 
		"Name=searchProducts", "Value=Search", ENDITEM, 
		"Name=_sourcePage", "Value=4w7x4brvdcJFkSFGh7AnpanZGY_ihgv-T4x_g7NoQ93CE0nBsBIdoJL68hg1iiSEDzWW4nV2mpaPcJIkUA6V6q_nNyKDIPa9", ENDITEM, 
		"Name=__fp", "Value=HN_IfeZzmnxxR_s-ydw-ZzgPTk3IfjOQ4i4QZkYCrD7juqi_MNr75iD8CMH9beHQ", ENDITEM, 
		LAST);

	web_custom_request("rb_bf32608msb_13", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1403195377&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C10%7C_event_%7C1779551973902%7C_viewend_%7Cinp%7C136%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551964738%7Csvtrg%7C1%7Csvm%7Ci2%5Esk2%5Esh0%2C1%7C11%7C_event_%7C1779551973903%7C_pageend_%7Cinp%7C136%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$rId=RID_1078536306$rpId=-1058516884$domR=1779551938716$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551964738$tvm=i2%3Bk2%3Bh0$tvtrg=1$w=1536$h=796$sw=1536$sh=960$ni=4g|1.6$egf="
		"1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551938627_465$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$nV=1$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action$time=1779551973906", 
		LAST);

	web_custom_request("rb_bf32608msb_14", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3618150718&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551973914&ss=1&qc=874864471&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xB0\"D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11?(_time\":9171\r\\x1C\\x0Cback\t[\r\\x1C\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!\"8us\":\"reported\",\\x05\\x18)]:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x19;\\x0Cnot_\\x1D?"
		"\\x08fidf\\x1C\\x00f7\\x00\\x04in\\x1D\\x1C\\x1DO\\x01\\x18B\\x8E\\x00\\x01\\x15\\x18interac.\\x12\\x01\\x041,\\x05\\x1A\\x1Cloading_\\x01\\xDD!\\xFF complete\"\t\\x1F\\x10start-\\xAE\\x185553.29\t\\x01\\x0C8882\t#\\x08dur%k\\x10\":136\t\\x13\\x04na!\\xFA\\x1C\"keydown\rK\\x18process\rm(rt\":5672.70\t\\x01\\x0C1118\t>\\x1D)\\x08end\\x05'Nx\\x00<cancelable\":true\t=8ui_element.tag_\r\\x8A\\x10INPUT\r\\x88\\x1D\"\\xA8xpath\":[\"html\",\"body\",\"div[@id=\\\\\"Header\\\\\"]\""
		".\\x16\\x00\\x14SearchV\\x16\\x00\\x18Content\t\\x1D\\x0Cform\tv\\x1Cut\"],\"lc=\\xB8:\\x0B\\x02 long_task!tIh:\"\\x00\\x0Cttfbb\\x1D\\x00\\x00va}8sequence_number\\x85\\x03\\x05\\x19 prerender-\\xCB\\x140,\"chaA\\x120eristics.has_\\x01,\\x1C_summary1U\\x10navig%\\xE1\\x81\\x06U(\\x04ex\\x018\\x0Cng\",2\"\\x00\\x04ypAE$soft\",\"per!\\x02!\\xA8\\x00.\\x81\r\\x14_origiA)4779551926719,\".e\\x02\\x11\\x1B\\x1864739,\"Y]\\x89H,dt.rum.schem\\x9D\\xEB\\x18\"0.23.0!\\xBC\t!\\x14applic\t"
		"\\xB7\\x04id\\x81\\xB08a7c4b59f27d43eb!\\xEE\\x8D\\xDD\\x10frame:\\xDF\\x04<96c882976875e951\\x1DZ\\x00gA\\\\\\x00v\\xB1e\\\\\"1.337.9.20260504-112723>1\\x00-\\x1A javascrip! \r\\xAC\\x11\\x88\\x00s\\x05\\xA9|D456F9D9707C4F014CD0FFC5C4A12D92\\x19Y\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16\\x00i\\xAD\\xC3)\\x13\\x001-\\x86\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE8\\x04,\"\r)<battery.level\":9!\\xCF\tC$screen.wida\\x7F\\x0C1536\\x155\r\\x1B,height\":960"
		",\\xD5\\x86\\x14window67\\x001=\r\\x1C\\x118\\x08842B8\\x00\t}\\x1C_pixel_r\\x01\\xC1\\xE0\":1.25,\"page.url.full\":\"http://localhost:8080/jpetstore/a\\xA5J(s/Catalog.a\\x05\\x10A\\xF2\\x01I1f\\x00_%\\xD0\\x0496BJ\\x02\\x05&\\x1Cdetected\\x91\\xA3\\xA2_\\x00\\x08tit\\x81\\xF3\\x14\"JPetS\\x01\\x8F\\x14 Demo\"\\xEDd6}\\x00<fb67c76cd1bca56f\\x11&\\xFE\\xEC\\x00\\x01\\xEC\\x00v\\x81r\\xC6\\xC6\\x00\\x04},\\xFEw\\x08:w\\x08%N&"
		"\\xB6\\x08\\x8D\\xE2\\x0C9180-\\xD9Bw\\x08\\x0466A\\x1E\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xFEz\\x08\\xAAz\\x08\\x1412204.\\xFE{\\x08.{\\x08\\x1012323\\x8A|\\x08\\x01(Nz\\x00\\xFE}\\x08\\xFE}\\x08\\xFE}\\x08y\\x14\\x12\\xC7\n\\xFA}\\x08.\\xE9\\x07\\xA1\\x0C\\x00v\\xA1]\\x00n\\x0E,\\x08\\x04rt\\x12\\x04\\x0BNm\\x08a\\xB8\\x00_:m\\x08\\x01\\x14N\\xAD\\x08\\xCE\\x85\\x08\\x08har\\x0E\\xA2\\x0B.\\x9C\\x00\\xBE\\x85\\x08\\x1A\\xA0\\x08&\\x85\\x08\\x1447191,"
		"\\xF1\\xB9\\x00s\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xFE\\x86\\x08\\xEA\\x86\\x08\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779553774050|1779551938632; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=4$551973955_464h-vHHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_15", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1229973126&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CSearch%7CC%7C-%7C551938627_465%7C1779551973164%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%7C%7C%7C%2Fjpetstore%2Factions%2FCatalog.action%7C1779551964738%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551973169%7C1779551974052%7Cdn%7C83%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%2C2%7C3%7C_event_%7C1779551973169%7C_vc_%7CV%7C873%5Epc%7CVCD%7C1012%7CVCDS%7C1%7CVCS%7C943%7"
		"CVCO%7C1945%7CVCI%7C0%7CTS%7C0%7CVE%7C465%5Ep261%5Ep15625%5Eps%5Estr%3Anth-of-type%283%29%3Etd%3Afirst-child%3Ea%3Afirst-child%3Eimg%3Afirst-child%7CS%7C825%2C2%7C4%7C_event_%7C1779551973169%7C_wv_%7ClcpE%7CIMG%7ClcpSel%7C%23LogoContent%3Ea%3Afirst-child%3Eimg%3Afirst-child%7ClcpS%7C17220%7ClcpT%7C854%7ClcpU%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7ClcpLT%7C831%7Cfcp%7C854%7Cfp%7C854%7Ccls%7C0.0343%7Clt%7C59%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551974052%7C177955197"
		"4052%7Cdn%7C83%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551973169%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551964738%7Csvtrg%7C1%7Csvm%7Ci2%5Esk2%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_1338253259$rpId=812274335$domR=1779551974048$tvn=%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551973169$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$nt="
		"a0b1779551973169e10f10g10h10i10k12l731m732o826p826q833r879s883t883u4942v4642w4642M812274335V0$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551973955_464$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551975130", 
		LAST);

	web_custom_request("rb_bf32608msb_16", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=738695413&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551976066&ss=0&qc=3585452970&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xE3\\x8A\\x02D{\"data_version\":2,\\x05\\x11\\xF0\\x8A\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"start_time\":1779551973921,\"duratio\\x01\\x95\\x08.19\r\\x01\\x80254942,\"performance.initiator_typ\\x01\\x8F\\xF0Xlink\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/\\x15\\x0Eh.css\",\"network.protocol.nam\\x01\\x81\\x01L\\x00\"6\\xA5\\x00(time_origin.\\xEA\\x00@168,\""
		"dt.rum.schem=\\x8C\\x18\"0.23.0:I\\x00\\x00s=2\\x10753.56h\\x00 next_hop_\\x11\\x94\\x08\":\":B\\x004domain_lookup_\\x05P\\x00\"NK\\x006(\\x00\\x08endR&\\x00\\x18connectjH\\x00\\x11\"^B\\x00\\x18secure_\r'\\x08ion\\x11L\\x0006\\xDB\\x00\\x00r)\\xBC\\x11\\x1E\\x10755.3M\\x17\\x1085099>.\\x00\\x14sponse\\xBE/\\x00\r\\xA6\\x085.6\r\\\\Et>\\\\\\x00\\x08dir\\x1D\\xF5B\\xA9\\x00\r\\x1F\\x05L:\\x1D\\x00A1\\x04er\\x11\\x96:\\x1D\\x00\\x10fetch\\x11\\x1CJ\\xDE\\x018render_blocking\\x01*\\x14tus\":\""
		"\\x11\\x12:\\xEB\\x01\\x14transf\\x01o\\x0Cize\">n\\x000encoded_body_\t\"\\x0C60146\\xEC\\x00\\x04deZ%\\x00-\\x8F(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xE6\\x00tE\\xA3\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.\\x85,|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\xD5N\\xF8\\x03,w3c_resource\r\\xAB\\x00s\\x110m\\x7F\\x18applicaA\\x81\t\\x83<ea7c4b59f27d43eb\\x9D\\xDC\\x0Cfram\\x81y\\x00s\\x9D\\xDE@4154bb0d36778f26\"u\\xD9\\x14agent.\\xB5d\\\\\"1.337.9.20260504-112723"
		">1\\x00\\x8D\\xCE$javascript\\x19!\\x00b\\xADd\\x00s%,|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-\\x81t-\\x16\\x00i\r\\xE4)\\x13\\x001\\xAD\\xA3\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[L\":\"landscape-primary\\x19)Lscreen.width\":1536,\"\rD\r\\x1B,height\":960,\\xD5k\\x14window67\\x001#\r\\x1C\\x118\\x008\\xC1>:\\x1C\\x00\tb\\x1C_pixel_r\\x01\\xA7\\x10\":1.2\\xA1Z\\x10age.u\\xA6%\\x06\\x04acA?$s/Catalog.\t\\x10\\x10;jses\\xE1`\\x88id="
		"E81E6C649276A0CA5A2415B36BA98F99a\\xC1\\x01u1x\\x00_%\\xE2J\\\\\\x02\\x05& detected_\\xCDy\\x00/\\xD5\\xA2\\xFE\\x8B\\x00\\x1D\\x8B\\x0Ctitl\\xC1\\xD6PJPetStore Demo\",\"view:\\xA9\\x00809643967384258dAI\\x05&\\x00u\\xFED\\x01\\xBAD\\x01\\x05u\\xFE\\x1E\\x01v\\x1E\\x01\\x04},\\xFE\\x0C\t\\xCE\\x0C\t:1\\x06B\\xFC\\x08\\x95*N\\x06\\x05\\xAD\\xB3\\x91\\xF9\\xAA\\x95\\x01\\x10ruxit\\x85\\xC8pjs_ICA15789NPRTUVXfqrux_10337\\x89\\xD0\\x89\\xCF\\x04.j\\xFE#\t\\xFE#\t\\x1E#\tj\\xCA\\x07\\xEE/\tjW\\x00Z;\t"
		"j2\\x00\\x1A\\xFE\\x08\\xE1\\xD2\\x00r\\x1A\\x8F\t\\x8A.\\x00\\x12a\\x08\\x0E(\\x08j,\\x00\\xDA_\t\\x0006\\x07\\x08\\x00r:O\t^\\x1F\\x00\\x8E\\x92\\x00\\x00r\\x1E \t\\x1A|\nBL\\x00\\xFE?\t\"?\tj\\x17\\x01\\xFEK\t\\x82K\t\\x1013290\\x86M\t\\x14362149&'\t\\x16\r\t\\x1A\\xA4\\x08\\x1EO\t@not_available_htt\\x0E_\\x0Cm\\xCEVY\t\\x012\\x04se\\x0E3\\x08N\t\\x04\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t"
		"\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xFE\\x0F\t\\xA2\\x0F\t\\x04im\\x0E\\x13\\x0FN\\x03\\x05\\xAD>\\xCA\\x0C\tTimages/logo-topbar.gif\\xFE\\x0F\\x12\\xFE\\x0F\\x12\\x1A\\x0F\\x12\\x0480\r\\x01\\x0C74516\\xC3\\x07\\xEE\\xEC\\x08jW\\x00Z\\xEC\\x08j2\\x00J\\xEC\\x08\\x8A.\\x00\"Z\\x08j,\\x00\\xFE\\xEC\\x08\\xDA\\xEC\\x08j\\x92\\x00\\xFE\\xEC\\x08\\xA6\\xEC\\x08r\\x85\\x00Z7\\x12\\x0Cnon-\\xFE;\\x12\\x1E;\\x12\\x0C38086q\\x02J;\\x12\t%m|V\\xEC\\x08\\xEE;\\x12\\x12;"
		"\\x12x3881223f689a154f0643b8963dcd5a3\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12\\xFE;\\x12b;\\x12\\xFE,\tj,\t\\x0Ccart\\xFE%\t\\xFE%\t.%\t\\x1A\\xDB\\x19J7\\x1A\\xF2%\tfW\\x00^%\tf2\\x00N%\t\\x86.\\x00&%\tf,\\x00\\xFE%\t\\xDE%\tf\\x92\\x00\\xFE%\t\\xAA%\tn\\x85\\x00\\xFE%\t\\x8A%\t\\x0496\\x82#\t\\x01#\\xFE!\tv!\t"
		"@570492c08c75f09b2\\x0Es\\x1F(4998fb21c09\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xFE\\\\\\x1B\\xAA\\\\\\x1B\\x0E\\xF0$\"h$:\\x88\\x18B\\\\\\x1B\\xFE!\tj!\t\\x10separ\\x0E\\xC4$\\xFE&\t\\xFE&\t\"&\t\\x084.0\\xED,\\x0C7764:\\xDA\\x0F\\xE6&\trW\\x00R&\tr2\\x00B&\t\\x92.\\x00\\x1A&\tr,"
		"\\x00\\xFE&\t\\xD2&\tr\\x92\\x00\\xFE&\t\\x9E&\tz\\x85\\x00\\xFE&\t\\x8A&\t\\x004\\x86&\t\\x01#\\x00r\\x16\\x11&\\xFEG\\x12^G\\x12x48f55f2a3c0905ed28d9435f9189a91\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xCE&\t\\x14m_fish\\xFE$\t\\xFE$\t*$\tj\\x81,\\xEE$\tjW\\x00Z$\tj2\\x00J$\t\\x8A.\\x00\"$\tj,\\x00\\xFE$\t\\xDA$\tj\\x92\\x00\\xFE$\t\\xA6$\tr\\x85\\x00\\xFE$\t\\x8A$\t"
		"\\x0427:\\xDF\\x1DJn\\x1B\\x05$\\xFE&\tv&\tx060253210f8790b19f045d76c7a6383\\x0E\\x06-\\x1A\\xD6-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\xFE\\xA8-\\x82\\xA8-\\xFEL\\x12\\xFEL\\x12\"L\\x12\\x14m_dogs\\xFE&\t\\xFE&\t*&\t\\x0EJ1*\\xB17\\xEE\\x1A\t:K\\x00Z\\x0E\t:&\\x00J\\x02\tZ\"\\x00\"\\xF6\\x08: \\x00\\xFE\\xEA\\x08\\xDA\\xEA\\x08"
		":\\x86\\x00\\xFE\\xDE\\x08\\xA6\\xDE\\x08By\\x00\\xFE\\xD2\\x08\\x8A\\xD2\\x08\\x0430\\x86\\xF7\\x11\\x05$\\xFE\\xD2\\x08v\\xD2\\x08x78c4449186f15ce3a8d1129d5513f44\\x0E\\xE9'\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xFE\\xD2\\x08\\xCA\\xD2\\"
		"x08\\x18reptile\\xFE\\xD6\\x08\\xFE\\xD6\\x082\\xD6\\x08\\xFE \\x1BV \\x1BjW\\x00^\\xEE\\x08f\\x89\\x00N\\xFA\\x08\\x86.\\x00&\\x06\tf,\\x00\\xFE\\x12\t\\xDE\\x12\tf\\x92\\x00\\xFE\\x1E\t\\xAA\\x1E\tn\\x85\\x00\\xFE*\t\\x8E*\t\\x009:\\x90\\x1DJ\\xFC\\x11\\x05$\\xFE*\tz*\tx10e236f5ffa28765b140d44712ee9b4\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE"
		"\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xFE\"\\x1B\\xD6\"\\x1B\\x08cat\\xFE&\t\\xFE&\t.&\tj\\x83=\\xEE\\x08\\x12jW\\x00Z&\tj2\\x00J&\t\\x8A.\\x00\"&\tj,\\x00\\xFE&\t\\xDA&\tj\\x92\\x00\\xFE&\t\\xA6&\tr\\x85\\x00\\xFE&\t\\x8A&\t\\x0428:\\xB7IJ&\t\\x05$\\xFE&\tv&\t|99b04d0d3be1cf52ac7ae8a395db1efa\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xFE&\t\\xD6&\t\\x0Cbird\\xFE'\t\\xFE'\t"
		".'\tj\\xBE=\\xEE'\tjW\\x00Z'\tj2\\x00J'\t\\x8A.\\x00\"'\tj,\\x00\\xFE'\t\\xDA'\tj\\x92\\x00\\xFE'\t\\xA6'\tr\\x85\\x00\\xFE'\t\\x8E'\t>(BN'\t\\x01$\\xFE'\tz'\tt816f19d7e450737bad8f89b94aa411\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956\\xFE\\x956N\\x956>\\x97H\\x0E#)4elf_monitoring\\x1E\\x9EHJ*\\x00\\x1Cinternal\\x11#\\x12LO\\x0E7N\\x00e.`Z\\x0498"
		">\\x96$\\x1A\\xD8UfmZ\\x11!\\x08fm_*\\xF6[ timestamp2^\\x00\\x0C67,\"\\x0E\\x1FX4\":2000,\"messag\\x0E-T\\x12*V\\x1C31483296\\x12,S\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0E<W\\x14 JavaS\\x12\\x04W0 tag\\\\\",[]]\"}]&bW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW\\xFE\\xBCW>\\xA1\\x05\\x0El` long_taskz\\xA3\\x05\\x002\\x0E\\xE5Z\"\\x85"
		"<\\x0459\\x95\\xD6f\\xA4\\x05\\x15[\\x1Er`\\xC18\\x04\",\\x1D\\x18\\x18attribu\\x0E\\x8FZ\\x0E\\xB8\r\\x14tainer\\x16MZ\\x8A(\\x00\\x1AOZ\\x8A*\\x00\\x08src\\x16b`\\x19\\x93V{\\x00\\x1A\\xCE\\\\\\x16\\x8F[bY\\x00\r"
		"y\\x18unknown\\x0E\\x19\\\\\\x16\\x1Ca\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xFE\\xE1\\x05\\xEE\\xE1\\x05\\xA5\\xE1Z_\\x0B\\x0493.\\xA9f\\x044765A\\xA1\\xDA.\\xF9.\\xFERB\\xAERB\\x0E)9\\x002\\xFE\\x040\\xFE\\x040\\x1A\\x040\\x008\\x12Laz\\x020\\x0E\\xD6Z\\x08/1.\\x0EX?.+\\x006\\xA7\\x14%\\x87\\x00"
		"\"FQ\\x006&\\x00\\x12s\\x14Bu\\x00:\\xBF\\x14b \\x00V>\\x00\\xDA\\xA3\\x14\\x10826.3\\x1A\\x93UJ\\x94U>W]\\x088706\\xEDh6/J\\x15/\t\\xA4\\x04726p\\x02>-\\x00\\x1AH]-5:\\xDFD\"\\xE2\\x14\\x05L:\\x1D\\x00\\xA6\\xA6fBG\\x01bY]\\xA6mT\\x0C1361:\\x820J\\xACf\\x08133>&\\x00J\\xBB\\x14\r&\\xFE\\xBD\\x14v\\xBD\\x14x5fa89d3b0ed5004080ef907d1e2ae19\\xFEsT\\xFEsT\\xFEsT\\xFEsT\\xFEsT\\xFEsT\\xFEsTZsT8battery.level\""
		":\\x0E\\x82j\\x16Kf\\x1E\\xADf\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f\\xFE\\xC8f2\\xC8fB+\t\\x001\\xED\\x17\\x14149011:\\xFC5\\xFE+\t\\xBE+\t\\x001\\xFE+\t\\xFE+\t&+\tn[@N\\x0C\\x1E\\xBA9\tn_\\x00VG\tn2\\x00FU\t\\x8E.\\x00\\x12s\\x08\\x0482r,\\x00\\xEAq\t:<\\x08\"6\t\\x1A\t\t\\x0Ee\t^#\\x00\t\\x9A\\x0472F!\\x00\\xFEM\t\\x9AM\tn?\\x01\\xFE[\t\\x0E[\t\\x08293:(\nN[\t\\x0426>&\\x00N[\t\t&\\xFE[\tv[\t"
		"x1f042a18bc93fa43f976da6864cd57e\\xFEe0\\xFEe0\\xFEe0\\xFEe0\\xFEe0\\xFEe0\\xFEe0Ze0\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xFE[\t\\xB2[\t\\x16Ex\"B\\x18\\x08883nD\\x10BZ\t\\x10navig\\x0E\\xF6r\\x0Ep\\x17N\\xC9\\x18\\xAD\\xE1\\x1E\\xC7\\x18\\xAA7p\\x16\\x00s\\xFA\\x10s\\xFEfy\\xFEfy:\\x1B\\x11\\xFE\\x83\t\\x049..\\x85\\\\\\x0488>#n2\\x9Ey\\x12\\x8F\\x08z2\\x00:\\x83\t\\x9A.\\x00\\x8EZ\\x00\\xDA\\x83\t\\x04112\\xD5&\\x0405:q\\x08>\\x90\t\\x08730Fo\t"
		"\\x1A\\xBEy\\x05\\xA7\\x08731F!\\x00\\xFE\\x90\t\\x8E\\x90\tzL\\x01b\\x90\t\\x96TgF\\xCB|J\\x8B\t\\x0446\\x0E\\xB2v2\\x12\\x15F\\x92y\t%m\\xA8\\xFE\\x10UZ\\x10Ux84b7edf6708cda8da63c3fe90ead61fn\\xA1'\\x12\\xACv\\x16}y\\xEE\nv\\x16\nvZ\\xDA}\\x0E\\xD3p\\x99\\xCA\\x0E\t#\\x04in&\\xE4yN\\xD7\\x04\\x19.\\x91\\xDA.f\\x01\\x1A\\xB0\\x1C\r%\\x00e\\x0E\\x98w*\\xC1\\x16\\x14unload\\x16!#\\x1EW\\x0C:(\\x042#\\x00E\\xC7:!\\x00\\x08dom\\x16\\xC6#\\xA1&\\x04ve\\x0E\\xD6\\x16:\\x05\\x0F\\x01\""
		"\\x1Ccontent_\\x01p\\x00e:r\\x00\\x0E]\\x162\\x1B\\x7F6\\x01\\x16b?\\x00\\x05\\x8E\\x08833nl\\x0C\t=\\x0EY{\\x00t\\x01\\x9B\\x0479nj\\x00\\x01\\x9D6\r\\x01\\xC1\\x85\\x000f'=\\x1D1\t\\x8Dv\\xB4\\x06\"\\xAC\\x16\\x08cou\\x0E`|\\x040,1\\x99\\x08ion1\\xAB\\x08har\\x0Ep|-\\xB2\\x05\\x19\\x04ab!\\x9D\\x01\\xC1\\x08\"ex\\x0E\\x07\\x80\\x04ng\\x1E\\xB8x\\x00s\\x0E=X\\x0E\\x9B\\x80 number\":1\""
		"x\\x1F\\xFEm\\x1E\\xFEm\\x1E\\xFEm\\x1E\\xFEm\\x1E\\xFEm\\x1E\\xFEm\\x1E\\x0Em\\x1E\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\xFE\\x01\\x0C\\x1A\\x01\\x0C\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_17", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=1837695386&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551973169$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$rt="
		"1-1779551973169%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb754e0f0g0h0i0k2l2m2v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb754e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb754e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb754e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3"
		"A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb754e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb755e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb755e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb755e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2"
		"Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb755e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish2.gif%7Cb825e0f0g0h0i0k1l45m47u13615v13315w13315E1F15625O125P125I7M1866378948V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish1.gif%7Cb825e0f0g0h0i0k1l45m47u12938v12638w12638E2F15625O125P125I7M-859153008V0$url="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551973955_464$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551977143", 
		LAST);

	lr_think_time(7);

	web_custom_request("rb_bf32608msb_18", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=4186301306&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551982311%7C_wv_%7CAAI%7C1%7CfIS%7C8038%7CfID%7C1$rId=RID_1338253259$rpId=812274335$domR=1779551974048$tvn=%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551973169$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi="
		"HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551973955_464$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551984315", 
		LAST);

	lr_think_time(4);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=12:eZHs6CEW31foLqsjfR02Q1mvDKu8WfW91TLznCQjwBs&cup2hreq=a8422fa7b6de0112b39fee02dd8c1c97b248dbcb2c4411fbddcbd006212ca747", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromium\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{4926bdf7-e55e-4e4a-a33b-3888e56318fa}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate"
		"\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c1e517c38fa346ac30e13d8f2369620749c4bc6b145a914e0fab85b33755f308\"}]},\"ping\":{\"ping_freshness\":\"{97128536-d682-4f90-9898-f2e8f535b360}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"9.68.0\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.b504d7eeb36a91391d3e14f0c11dc3431a1ac1e7f7dddaf8090930f5a0e3348f\"}]},\"ping\":{\"ping_freshness\":\"{760f1947-903a-44c4-a950-5b02706980c1}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"677\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"cohort\":\"1:z1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.56c21927faa028be6ce18c931660eec37e41da4bfbfd47cafa48350f828c0dbd\"}]},\"ping\":{\"ping_freshness\":\"{2e1f5135-fcb1-4ae2-ae91-7941d598bcdc}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"2025.7.24.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\""
		"ping_freshness\":\"{80a32792-3904-4ed3-8f5f-36396edeb788}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{7b4374ff-1a21-4402-b3b6-cf26a7a4286a}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.261bea60d22ebca3a95ce335c03ec751a0b58b2b7bdbd6ea51dfa54381b07775\"}]},\"ping\":{\"ping_freshness\":\"{3c497778-cf92-4fb4-8729-e82e3fe70f88}\",\"rd\":7082},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"145.0.7584.0\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"cohort\":\"1:2879:\",\"cohorthint\":\"Auto androidlowmem\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":7006,\"lang\":\""
		"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c80a7d63372ce080c313e4a2320dc86178ad781914ecf6fb9b3f00d978ee32ff\"}]},\"ping\":{\"ping_freshness\":\"{4a77ab81-b781-43fe-a31f-c431e12294ae}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"10543\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"cohort\":\"1:18ql:\",\"cohorthint\":\"Auto Stage3\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.9b494d3de7d41c7329ee1ffed1ad8674e515e89053651dbbc2489f34200e368a\"}]},\"ping\":{\"ping_freshness\":\"{85af4997-fce7-4292-a7cd-1ee44efc35bc}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"1674\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7b05c14dba04ed522210b733f004cb0e74d7679a653b19bd029f9bc0e6b19903\"}]},\"ping\":{\""
		"ping_freshness\":\"{fdbd5f50-6f7a-465d-8ed5-5f96a7b971f2}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"1.1.0.3\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"cohort\":\"1:ut9/1a0f:\",\"cohorthint\":\"M108 and Above\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c1ac192a5f20b241447721b4bcd7b6dd076398c5eeaccad1f793a4a549a59de3\"}]},\"ping\":{\"ping_freshness\":\"{1f9a77ce-564d-4c1a-82a5-0124584c4f0e}\",\""
		"rd\":7082},\"updatecheck\":{},\"version\":\"2026.5.18.61\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.0c24e9bd976adffa987e08fc54dc0950c84cf18f9cdb4c5caabc6acf24887c4f\"}]},\"ping\":{\"ping_freshness\":\"{3d0a90b5-9b54-4a08-80b1-426de9cb19c7}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"20220505\"},{\"appid\":\""
		"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"All users\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{56735c36-f128-450c-adb4-257fee4345d0}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{94418fd5-4f85-48cc-81d9-6d0e98188b35}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"cohort\":\"1:zor:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\""
		"packages\":{\"package\":[{\"fp\":\"1.9b212fb00a2ff3bc981a89aa8dd0f52c60f7baeb6f958148396af27431c8f097\"}]},\"ping\":{\"ping_freshness\":\"{30412d8e-7d59-479e-94ba-15459c7e9b18}\",\"rd\":7082},\"tag\":\"29.5\",\"updatecheck\":{},\"version\":\"29.0\"},{\"appid\":\"dnhnnofocefcglhjeigmkhcgfoaipbaa\",\"cohort\":\"1:16j3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.831f042cb02b1fc2f9fed3106f544be8b336828681a1613ced571c09ebca4cf2\"}]},\"ping\":{\"ping_freshness\":\"{0d770554-936e-46a5-9c9a-c29054981399}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"2022.11.1.1\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.9bec6c2c0185d3305ac8495047a1aa01e725d58f8f18d219742a2988f07cd93a\"}]},\"ping\":{\""
		"ping_freshness\":\"{781a043a-77c4-4de6-8b7e-a15c8d06df78}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"3091\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"cohort\":\"1:s6f:3cr3@0.025\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.23759e3f6d0119a00038b963cec9fb7abafd7b65a35a7e83c7697511db59e6e7\"}]},\"ping\":{\"ping_freshness\":\""
		"{a0394224-ac3b-4710-b5e5-187bca01b781}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"20251024.824731831.14\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.fd8fd38c229ab33755ff429ccc9919eba21b566551cbfb17d8e11e35e941ee0e\"}]},\"ping\":{\"ping_freshness\":\"{ea77f9a6-d4d4-4d5a-91f8-28bad14f101e}\",\"rd\":7082},\"updatecheck\":{},\""
		"version\":\"2026.3.23.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":7006,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4497d8060d0e53c12b4403aa9ebe7e827d4880bae3f4139a26a4feb7ed64c4a2\"}]},\"ping\":{\"ping_freshness\":\"{b7460226-cb54-4c2c-80c2-9246c2e00c82}\",\"rd\":7082},\"updatecheck\":{},\"version\":\"2025.6.13.84507\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\""
		":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.26200.8457\"},\"prodversion\":\"108.0.5359.125\",\"protocol\":\"3.1\",\"requestid\":\"{62aeb2b6-cdb6-48b2-9114-570833d4fd8a}\",\"sessionid\":\"{8c05d3fd-9338-4c1b-a881-af296b8133c2}\",\"updaterversion\":\"108.0.5359.125\"}}", 
		LAST);

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CFresh%20Water%20fish%20from%20China%7C-%7C1779551988799%7C551973955_464%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7C%7C%7C%7C; DOMAIN=localhost");

	web_url("Catalog.action_2", 
		"URL=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("rb_bf32608msb_19", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3366408938&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C7%7C_event_%7C1779551989762%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7Csvt%7C1779551973169%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C8%7C_event_%7C1779551989762%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$rId=RID_1338253259$rpId=812274335$domR=1779551974048$tvn="
		"%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$tvt=1779551973169$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551973955_464$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99$time=1779551989765", 
		LAST);

	web_custom_request("rb_bf32608msb_20", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=2260470616&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551989772&ss=1&qc=81652567&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action;jsessionid=E81E6C649276A0CA5A2415B36BA98F99", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xE67D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11?,_time\":16599\r\\x1D\\x0Cback\t\\\\\r\\x1D\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!#8us\":\"reported\",\\x05\\x18)^\\x11-\\x001\t\\x150value\":0.0343\t\\x13\\x1Cloading_\\x01H!k,"
		"dom_content_\\x01\\x1C\\x19Q8i_element.shift-.\\x14873.39\t\\x01\\x08850!W\\x01\\x97B.\\x00J{\\x00\\x1D$\\x14tag_na!\\x9B\\x14\"TABLE\\x11\\xC5\\x19t0xpath\":[\"htmlA\\x06@ody\",\"div[@id=\\\\\"C\t\\xB5\\x08\\\\\"]6\\x17\\x00\\x14atalog\t\\x170table\"],\"fcp.\r\\x92\\x10853.5\t\\x12\\x01\\xF0\\x82\\x0C\\x01\\x01;!->u\\x01\\x08fidb\\x18\\x00>Y\\x00$complete\",\\x117\\x00r5P\\x08038=Q\\x001\t\"\\x08durE:E\\x85\\x01j--(pointerdown\rL\\x18process\r\\xC7(rt\":8039.80\r\\x01\\x0474\\x01\\xED\\x04id.)"
		"\\x00\\x08endb'\\x00\\x14cancel%8\\x10:true\t\\x90=\\x99.\\xBB\\x01\\x00D\r\\x85\\x1D\\x1F\\xFE\\xB8\\x01=\\xB8\\x08,\"t-\\xF6\\x0Ctr[2!\\xE7\\x04td\\x01\\x08!\\xD0B\\xCF\\x01\\x00pBu\\x01R\\xDA\\x02\\x04fpR\\xB5\\x01\\x04in\\x1D\\x184below_thresholaa\\x04lc\\x1D\\x1F}y\\x01\\x18By\\x03\\x01\\x15\\x04st=\\xE2Iq\\x01\\x17A\\x18qH\\x0831.e>\\x01\\x18\\x08siz\\x81\\xA6\\x107220,\\x05\\x11\\x14url\":\"\\x81\\x05\\xC8://localhost:8080/jpetstore/images/logo-topbar.gif\"\tC\\x1Cresource\tu2Q\\x02\\x01s="
		"\\xB3Drender_delay\":99.6i\\xDF\\x189925494RO\\x00\t,\\x0C23.3MhAi\\x08058\\x11-\\x05R\\xA9}=\\x00\\x1Du]G\\x0CIMG\"\t8\\x1D \\x82H\\x02\\x14Headeri\\xE8\\x99\\x16\\x0CLogoN\\x14\\x002.\\x04\\x18a\",\"imgAI long_task!\\xB3B\\xE4\\x03\\x19\\x1E\\x0Call.\\xCD\\x17\\x041,:\\x18\\x00\\x08avg=`\\x0459> \\x00@slowest_occurrenc\\xE1\\x05\\x08[{\".%\\x02\\x007!;9\\xA5\\x0C59}].G\\x00\\x0CselfR\\x80\\x00\\x05\\x19n\\x81\\x00\\x05"
		"!\\xE2\\x82\\x00\\x0CttfbR\\x1A\\x01\\x05\\x19\\x00v\\xC9_\\x08730\\xA1R\\x05\\x13\\x0Cwait\\x81\\x8C\\x19\\xCB\\x089.8MO\\xC1/\\x0C884,\t*\\x10cache\\x1D(\\x000\r\\x18\\x08dnsJ\\x16\\x00\\x14connec\\xE5M\\x19[\\x113\\x0Crequ!a\\x19\\x1A\\x10720.6M\\x9A414901,\"perform\\x81\\xDF\\x14.activ\\xA5a\\xE1\\x08\\xA15\\x000\\x1A\\x1E\\x08\\x00s\\x01K(nce_number\"!\\xEE\\x00v\\x0ET\\x08\\x08prem(I\\xD6X0,\"characteristics.has_\\x01,"
		"\\x1C_summary\\xB1A\\x10navig\\x05n\\x0E\\xC4\\x08\\x01r\\xE5z\\x04ex\\x018\\x0Cng\",2\"\\x00\\x04yp\\xE1\\x97\\x08har\\x81y.\\xB5\\x00\\x01xX_origin\":1779551973168,2K\\x02:\\x1B\\x009\\x15\\x1A\\x06\t,dt.rum.schem*\\xAA\t\\x18\"0.23.0\\xE1M\t!\\x14applic\t\\xB8\\x04id\\x0Eo\t@a7c4b59f27d43eb\",\"\\x9C\t\\x10frame:\\x9E\t<4154bb0d36778f26\\x1DZ\\x00g\\x0EV\\x08\"$\n\\\\\"1.337.9.20260504-112723>1\\x00-\\x1B$javascript\\x19!\\x00b\\x1A$\n\\x00s\\x05\\xA9|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t"
		"0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16\\x00i\\x1A\\x82\n)\\x131l\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE9\\x04,\"\r)0battery.level\\xA1\\x9C\\x15\\x1A$screen.wid\\x0E'\t\\x0C1536>\\x1B\\x00(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x08842B8\\x00\t\\x97\\x1C_pixel_r\\x01\\xC1P\":1.25,\"page.url.full\\x8A\\xBC\\x06\\x00ae\\xCD\\x04s/\\x1A\\xB0\te\\x93\\x18on;jses\\x0E:\\x0C\\x90id=E81E6C649276A0CA5A2415B36BA98F99\",\t"
		"u1\\x92\\x00_%\\xFCJv\\x02\\x05\\x9B\\x1Cdetected\\x1Ew\n\\xFDG\\xFE\\x8B\\x00\\x19\\x8B\\x0Ctitla\\xBE\\x10JPetS\\xE1\\xA3\\x14 Demo\"\\x8D\\\\6\\xA9\\x00<09643967384258d0\\x11&\\x00u\\xFED\\x01\\xBAD\\x01\\x00v\\x81\\xDE\\xFE\\x1E\\x01v\\x1E\\x01\\x04},\\xFE\\xE6\r:\\xE6\r%\\xD2&%\\x0E\\xAD\\x93\\x1016600M\\x8A\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r"
		"\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\r\\xFE\\xE6\rb\\xE6\rN\\xB5\r\\x0EO\\x08\\x00_:\\xB5\r\\x01\\x14N\\xF5\r\\xFE\\xCD\r\\xFE\\xCD\r&\\xCD\r\\x12\\xED\\x08\\x1A\\xAC\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r\\xFE\\xCD\r"
		"\\xFE\\xCD\r\\xFE\\xCD\r\\xAE\\xCD\r\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779553789850|1779551938632; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=4$551989795_778h-vHHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_21", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=2003358500&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CFresh%20Water%20fish%20from%20China%7CC%7C-%7C551973955_464%7C1779551988799%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7C%7C%7C%2Fjpetstore%2Factions%2FCatalog.action%3Bjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7C1779551973169%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551988803%7C1779551989852%7Cdn%7C84%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpet"
		"store%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%2C2%7C3%7C_event_%7C1779551988803%7C_vc_%7CV%7C1032%5Epc%7CVCD%7C1020%7CVCDS%7C0%7CVCS%7C1103%7CVCO%7C2111%7CVCI%7C0%7CTS%7C1%7CVE%7C491%5Ep238%5Ep67947%5Eps%5Es%23Banner%7CS%7C1031%2C2%7C4%7C_event_%7C1779551988803%7C_wv_%7ClcpT%7C-5%7Cfcp%7C-6%7Cfp%7C-6%7Ccls%7C0%7Clt%7C0%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551989852%7C1779551989852%7Cdn%7C84%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2"
		"C1%7C5%7C_event_%7C1779551988803%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%5Esjsessionid%3DE81E6C649276A0CA5A2415B36BA98F99%7Csvt%7C1779551973169%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_226265164$rpId=702878224$domR=1779551989849$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551988803$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$nt="
		"a0b1779551988803e4f4g4h4i4k6l954m955o1032p1032q1037r1046s1049t1049u5005v4705w4705M702878224V0$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551989795_778$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$time=1779551990931", 
		LAST);

	web_custom_request("rb_bf32608msb_22", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=1217273912&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551991872&ss=0&qc=2761490776&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xC0\\xCF\\x01D{\"data_version\":2,\\x05\\x11\\xF4,\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"start_time\":1779551989781,\"duration\":0,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x08\",\".\\xA5\\x00(time_origin\\x1D\\xDAD8803,\"dt.rum.schem=|\\x18\"0.23.0:I\\x00\\x00s=\""
		"\\x089786f\\x00(next_hop_pr\t\\x92\\x08\":\":@\\x004domain_lookup_\\x05N\\x00\"FI\\x006&\\x00\\x08endJ$\\x00\\x18connectbD\\x00\\x11 V>\\x00\\x18secure_\r%\\x08ion\\x11H\\x0006\\xD3\\x00-\\xB2b\\x1E\\x00\\x14sponse~\\x1F\\x00V\\x84\\x00\\x10redir\\x1D\\xC3B{\\x00\r\\x1F\\x05>:\\x1D\\x00\\x14workerZx\\x00\\x10fetch\\x11\\x1CB\\xA6\\x018render_blocking\\x01(\\x14tus\":\"\\x11\\x12:\\xB3\\x01\\x14transf\\x01m\\x0Cize\">\\x89\\x000encoded_body_\t\"\\x0C60146F\\x01\\x04deZ%\\x00-_"
		"(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xB6\\x00tEk\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.e\\xE2|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\x9BN\\xBE\\x03,w3c_resource\r\\xAB\\x00s\\x110mE\\x18applicaAQ\t\\x83<ea7c4b59f27d43eb\\x9D\\x92\\x10frame:\\x94\\x04853ca36aa50846a8\\x01\\xFB\\x11Z\\x10gent.\\xB5\\x1A`\"1.337.9.20260504-112723\"u\\xD0\t1\\x04ty\\x85\\x94$javascript\\x19!\\x00b\\xAD\\x1A\\x00s%,|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t"
		"0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-\\x81:\r\\xBC\\x00i\\xADx)\\x13\\x001\\xADY\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[L\":\"landscape-primary\\x19)Lscreen.width\":1536,\"\rD\r\\x1B\\x10heigh\\x81x\\x0860,\\xD5!\\x14window67\\x001#\r\\x1C\\x118\\x08842B8\\x00\tb\\x1C_pixel_r\\x01\\xA74\":1.25,\"page.u\\xA6\\xEB\\x05\\x04acA?$s/Catalog.\t\\x108?viewProduct=&p\t\t$Id=FI-FW-0!\\xA0\\x05i1l\\x00_%\\xD6JP\\x02\\x05&$detected_n\\xC93\\x00/\\xD9j\to"
		">\\x7F\\x00\\x81\\x14\\x01\\xC8\\x0Ctitl\\xE1d@JPetStore Demo\",\"\\x01\\x9F:}\\x0082bbff043c8cea5cA\\x11\\x05&\\xFE\\x0C\\x01\\x8E\\x0C\\x01\\x05i\\xC6\\xE6\\x00\\x04},\\xFER\\x08\\xFER\\x08NR\\x08u\\xBAN\\x96\\x04\\xADC\\x91\\x89\\xAA]\\x01\\x10ruxit\\x85'pjs_ICA15789NPRTUVXfqrux_10337\\x89`\\x89_\\x0C.js\"\\xFEy\\x08\\xFEy\\x08\\x12y\\x08\\x08.09\t\\x01\\x0C7764\\xFE\\x87\\x08&\\x87\\x08nW\\x00V\\x95\\x08n2\\x00\\x1A^\\x08\\xE1b\\x00r\\x81o\\x007\\x92.\\x00\\xE5\\xEFz,"
		"\\x00\\xFE\\xBF\\x08\\xD6\\xBF\\x08n\\xEC\\x00\\xFE\\xCD\\x08\\xA2\\xCD\\x08v\\x85\\x00\\xFE\\xDB\\x08z\\xDB\\x08\\x1013290\\x86\\xDD\\x08\\x14362149&\\xB7\\x08\\x16\\x9D\\x08\\x1A4\\x08\\x1E\\xDF\\x08@not_available_htt\\x0E\\xB5\\x0B\\x18requestV\\xE9\\x08\\x012\\x04se\\xE1\\xC3N\t"
		"\\x04\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xFE\\x9F\\x08\\xE2\\x9F\\x08\\x04im\\x0E3\\x0EN\\x93\\x04\\x8D\\xCE\\xCA\\x9C\\x08Timages/logo-topbar.gif\\xFE|\\x08\\xFE|\\x08\\x1A|\\x08\\x002\\x16{\\x08\\x1097019\\xFE|\\x08*|\\x08jW\\x00Z|\\x08j2\\x00J|\\x08\\x8A.\\x00\"|\\x08j,\\x00\\xFE|\\x08\\xDA|"
		"\\x08j\\x92\\x00\\xFE|\\x08\\xA6|\\x08r\\x85\\x00Z|\\x08\\x0Cnon-\\xFE[\\x11\\x1E[\\x11\\x08380:q\\x02J[\\x11\t%m|V|\\x08\\xEE[\\x11\\x12[\\x11x3881223f689a154f0643b8963dcd5a3\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xFE[\\x11\\xA2"
		"[\\x11\\xFE\\xBC\\x08j\\xBC\\x08\\x0Ccart\\xFE\\xB5\\x08\\xFE\\xB5\\x08*\\xB5\\x08\\x003\\x1A\\xB5\\x08\\x10850996\\x9F\\x17\\xEA\\xB8\\x19nW\\x00Z\\xB5\\x08j\\x89\\x00J\\xB5\\x08\\x8A.\\x00\"\\xB5\\x08j,\\x00\\xFE\\xB5\\x08\\xDA\\xB5\\x08j\\x92\\x00\\xFE\\xB5\\x08\\xA6\\xB5\\x08r\\x85\\x00\\xFE\\xB5\\x08\\x8A\\xB5\\x08\\x04966o\\x02J\\xB3\\x08\\x01#\\xFE\\xB1\\x08v\\xB1\\x08|"
		"570492c08c75f09b297394998fb21c09\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\xFE\\x0C\\x1A\\x9E\\x0C\\x1A\\xFE\\xB1\\x08j\\xB1\\x08\\x1Cseparato\\xFEk\\x11\\xFEk\\x11.k\\x11\\x0E@\\x1D\\x04er\"m#\\xEE\\xAA\\x08:K\\x00Z\\x9E\\x08:&\\x00J\\x92\\x08Z\"\\x00\"\\x86\\x08: "
		"\\x00\\xFEz\\x08\\xDAz\\x08:\\x86\\x00\\xFEn\\x08\\xA6n\\x08By\\x00\\xFEb\\x08\\x8Ab\\x08\\x004\\x86b\\x08\\x01#\\xFEb\\x08vb\\x08|"
		"348f55f2a3c0905ed28d9435f9189a91\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\xFEb\\x08\\x0Eb\\x08\\x14m_fish\\xFE\\x16\\x11\\xFE\\x16\\x11*\\x16\\x11\\x006\\x1A\\x16\\x11\\x08925\\x0E\\xB1\\x1F\\xFEl\\x08\\x1El\\x08jW\\x00Zx\\x08j2\\x00J\\x84\\x08\\x8A.\\x00\"\\x90\\x08j,"
		"\\x00\\xFE\\x9C\\x08\\xDA\\x9C\\x08j\\x92\\x00\\xFE\\xA8\\x08\\xA6\\xA8\\x08r\\x85\\x00\\xFE\\xB4\\x08\\x8A\\xB4\\x08\\x08271\\x82\\x17\\x11\\x05$\\xFE\\xB6\\x08v\\xB6\\x08|"
		"060253210f8790b19f045d76c7a63836\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\x16\\xB6\\x08\\x0Cdogs\\xFE\\xB6\\x08\\xFE\\xB6\\x08*\\xB6\\x08\\x007\\x1A\\xB6\\x08\\xFE\\x81\":\\x81\"jW\\x00Z\\xB6\\x08j2\\x00J\\xB6\\x08\\x8A.\\x00\"\\xB6\\x08j,"
		"\\x00\\xFE\\xB6\\x08\\xDA\\xB6\\x08j\\x92\\x00\\xFE\\xB6\\x08\\xA6\\xB6\\x08r\\x85\\x00\\xFE\\xB6\\x08\\x8A\\xB6\\x08\\x0430\\x86k\\x11\\x05$\\xFE\\xB6\\x08v\\xB6\\x08x78c4449186f15ce3a8d1129d5513f44\\x0E)&\\x1A\\x084\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3\\xFE\\xDA3v\\xDA3\\xFE\\xCE\\x19n\\xCE\\x19 "
		"m_reptile\\xFE\\xBA\\x08\\xFE\\xBA\\x08.\\xBA\\x08\\x008\\x1A\\xBA\\x08\\xFE\\x86\":\\x86\"jW\\x00Z\\xBA\\x08j2\\x00J\\xBA\\x08\\x8A.\\x00\"\\xBA\\x08j,\\x00\\xFE\\xBA\\x08\\xDA\\xBA\\x08j\\x92\\x00\\xFE\\xBA\\x08\\xA6\\xBA\\x08r\\x85\\x00\\xFE\\xBA\\x08\\x8E\\xBA\\x08\\x009\\x8A:+"
		"\\x01$\\xFE\\xBA\\x08z\\xBA\\x08x10e236f5ffa28765b140d44712ee9b4\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xFEp\\x11\\xEAp\\x11\\x0EnE\\xA2\\xE6D\\xFE\\xBA\\x08v\\xBA\\x08\\x08cat\\xFE\\xB6\\x08\\xFE\\xB6\\x08&\\xB6\\x08\\x009ns:\\xE6\\x92\"rW\\x00R\\xB6\\x08r2\\x00B\\xB6\\x08\\x92.\\x00\\x1A\\xB6\\x08r,"
		"\\x00\\xFE\\xB6\\x08\\xD2\\xB6\\x08r\\x92\\x00\\xFE\\xB6\\x08\\x9E\\xB6\\x08z\\x85\\x00\\xFE\\xB6\\x08\\x8A\\xB6\\x08\\x0428:\\xAC-J=+\\x05$\\xFE\\xB6\\x08v\\xB6\\x08|"
		"99b04d0d3be1cf52ac7ae8a395db1efa\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\xFE\\xB6\\x08\\x16\\xB6\\x08\\x0Cbird\\xFE\\xB7\\x08\\xFE\\xB7\\x08.\\xB7\\x08j\\xAE:\\xEE\\xB7\\x08jW\\x00Z\\xB7\\x08j2\\x00J\\xB7\\x08\\x8A.\\x00\"\\xB7\\x08j,"
		"\\x00\\xFE\\xB7\\x08\\xDA\\xB7\\x08j\\x92\\x00\\xFE\\xB7\\x08\\xA6\\xB7\\x08r\\x85\\x00\\xFE\\xB7\\x08\\x8E\\xB7\\x08\\x005\\x8A\\xDD\"\\x01$\\xFE\\xB7\\x08z\\xB7\\x08t816f19d7e450737bad8f89b94aa411\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\xFE\\xF53\\x8E\\xF53"
		">\\x17E\\x0E\\x91\\x1E4elf_monitoring\\x1E\\x1EEJ*\\x00\\x1Cinternal\\x11#\\x120U\\x0EGJ\\x00e*\\xC6U\\x08982\\x0E\\xE2P.\\xBA\\x11\\x1AxQf\\xD3U\\x11!\\x08fm_*LW timestamp2^\\x00\\x0C15,\"\\x0E\\xBFS4\":2000,\"messag\\x0E\\x05P\\x12\\xCAQ\\x1C31483296\\x12<O\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0E\\xDCR\\x14 JavaS\\x12\\xA4R0 tag\\\\\",[]]\"}]&"
		"\\xD1R\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\xFE\\\\S\\x92\\\\S\\x1A\\xD4Z\\xB5\\x0E\\x0C1048n6%B\\xBF[\\x10navig\\x0E\\xC0U\\x0E\\xF4T>\\x94\\x05\\xF6\\xC5[V[U\\x8A\\xDAU\\x04ne\\xFE\\xEA[\\xF6\\xEA[\\x0006\\xAA.N=\\x0E\\x0E\\xC0P\\x08/1.\\x0E\\xE66.E16\\x11\\x0E\\xC5\\xC0\\x10\":4.1\\x1A\\x07 \\x12w1\\x0ENWf4\\x00\\x12\\xEB\rz2\\x00"
		":E\\x0E\\x9A.\\x00\\x8EZ\\x00\\xDAE\\x0E\\x0052\\xEF\\x1E\\x088846A\\x01\\x00r:8\\\\\\x0895321\\x00:\\xF4\\x15\\x15/\\x05\\xB2\\x0495Bc9\\x1A)\\\\-_:\\xAE\\x01\"v\\x0E\\x05>:\\x1D\\x00\\xA6H\\\\zU\\x01\\xFAV\\\\\\x08500:\\xD6\\x00JY\\\\\\x0447>%\\x00J\\x0E\\x17\t%\\xFEX\\x0EvX\\x0E|5bfb20dbb2dc7227b8ca144f57d6cdbej\\x0F\\x17\\x12FY\\x16D\\\\\\xEE\tY\\x16\tY\\x10;jses\\x0E+a\\x88id=E81E6C649276A0CA5A2415B36BA98F99Z\\x93`\\x0E6T\\x99\\xF3\\x0E\\\\\n\\x04in&\\xD7\\\\N\\x00\\x05\\x19.\\x1E\\x97\n"
		".\\xBD\\x03\\x1Aq\\\\\r%!\n.\\x1E\\x00\\x14unload\\x16t\nQ\\xAF\\x08972na\\x1B23\\x00E\\xC3z1\\x00\\x08dom\\x169\\x0B\\xA1o\\x00v\\x0E*\\x0B\\x10031.5\\x8DrJ0X\\x011\\x1Ccontent_\\x01\\x9F\\x00e:\\xA1\\x00\\x0C1032.\\xB2\\x04:\\xA9\\x02b?\\x00\\x05\\xAD\\x0C10376\\xFD\\x03\t0\\x0En^\\x00t\\x05\\x9D\\x0445n\\x9D\\x00\\x01\\x9160\\x01\\xC5\\xD2*\\xBE4:\\x8F\\x00\\x1D1\r\\x81v\\x01\\x07\\x95\\x1F\\x08cou\\x0Ew_\\x040,1\\xBD\\x08ion1\\xCF\\x08har\\x0E\\x8C^-\\xD6\\x05\\x19\\x04ab!\\xC1\\x01\\xC3\\x08"
		"\"ex\\x0E\\xE4b\\x04ng\\x1E\\x07\\\\\\x00s\\x0E\\xC5V\\x0Ehc number\":1\\xFE\\xC5\\x0B\\xFE\\xC5\\x0B\\xFE\\xC5\\x0B\\xFE\\xC5\\x0B\\xFE\\xC5\\x0B\\xFE\\xC5\\x0B2\\xC5\\x0B8battery.level\":\\xC1n\\x16\\xBE^\\x1E _\\xFE;_\\xFE;_\\xFE;_\\xFE;_\\xFE;_\\xFE;_\\xFE;_\\xFE;_\\xD6;_\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_23", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=3739920193&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551988803$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$rt="
		"1-1779551988803%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb978e0f0g0h0i0m0v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb978e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb978e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb979e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F"
		"%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb979e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb979e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb979e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb979e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Floc"
		"alhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb979e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551989795_778$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$time=1779551992941", 
		LAST);

	web_add_cookie("dtSaf4o018pw=true%7CC%7C-1%7CEST-20%7C-%7C1779551995579%7C551989795_778%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02%7C%7C%7C%7C; DOMAIN=localhost");

	web_url("Catalog.action_3", 
		"URL=http://localhost:8080/jpetstore/actions/Catalog.action?viewItem=&itemId=EST-20", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("rb_bf32608msb_24", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=32155370&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C6%7C_event_%7C1779551995584%7C_wv_%7CAAI%7C1%7CfIS%7C6556%7CfID%7C1%2C1%7C7%7C_event_%7C1779551996163%7C_viewend_%7Cinp%7C0%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7C1779551988803%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C1%7C8%7C_event_%7C1779551996163%7C_pageend_%7Cinp%7C0%7Curl%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$rId=RID_226265164$rpId=702878224$domR=1779551989849$tvn="
		"%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551988803$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$title=JPetStore%20Demo$isUnload=1$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551989795_778$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf="
		"http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02$time=1779551996166", 
		LAST);

	web_custom_request("rb_bf32608msb_25", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=2&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=3798817301&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551996175&ss=1&qc=674269616&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\x8C.D{\"data_version\":2,\\x05\\x11\\xF0o\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"view.fo\\x11?(_time\":7367\r\\x1C\\x0Cback\t[\r\\x1C\\\\0,\"error.http_4xx_count\":\\x19\\x00\\x005J\\x19\\x00 exceptionB3\\x00 csp_violaR\\x1E\\x00\\x1Cdropped_f@\\x00\\x05\\x8C\\x10other\\x1D[\\x0Ccls.!\"8us\":\"reported\",\\x05\\x18)]:-\\x00\\x10value\\x05\\xC9\\x08fcp\\x11\\x0E\\x181054.39\t\\x01\\x1485099,"
		"\\x05\\x1F\\x1Cloading_\\x01b!\\x84 complete\"\t\\x1F\\x01\\x17>y\\x00\\x08fidb\\x18\\x00nO\\x00\t7\\x04rt-\\x82\\x186555.5,\\x05O\\x08dur%4\t\\xB6\\x10id.na!\\xC1,\"pointerdown\\x01\\x91$id.process\r\\xB3\\x08rt\"\\x01H\\x086.8\t\\xD9\\x0C9851\tR\\x1D(\\x08end\\x05&\\x007\t\\x1A<cancelable\":true\t\\x168ui_element.tag_\r\\x80\\x00A\rv\\x1D\\x1E\\xA8xpath\":[\"html\",\"body\",\"div[@id=\\\\\"Content\\\\\"]6\\x17\\x00\\x18atalog\\\\\\x05\\x17\\x00t\\x05\\x7F\\x08,\"t\r>\\x10tr[2]\\x01\\x10"
		"!\\xD9\\x14a\"],\"fv\\xBA\\x01\\x00prj\\x01\\x00pR\\xA0\\x01\\x04in\\x1D\\x184below_threshol\\x01w\\x04lc\\x1D\\x1F]h\\x01\\x186h\\x02\\x041,\\x05\\x15\\x04st9\\xCDQ_\t\\x1AA\\x06-\\xE6\\x141035.1An\\x01H(size\":17220\t*\\x14url\":\"A\\xF8\\xC8://localhost:8080/jpetstore/images/logo-topbar.gif\"\tC\\x1Cresource\tv2J\\x02\\x01s=\\xBBPrender_delay\":76.0990\\x01\\x01\\x14298012RO\\x00\t,\\x0026<\\x03\\x08884\\x11-\\x05R\\x89o6\\x04\\x01\\x1Dx]Q\\x0CIMG\"\t;\\x1D \\x82S\\x02\\x14HeaderI;"
		"Yi\\x0CLogoN\\x14\\x002\\x81\\x02\\x18a\",\"imgAS long_task!\\xBAi\\xD6\\x0Cnot_=\\xEB\\x0Cttfb\\x19\\x1D>\\x19\\x00\\x00v\\x89X\\x08953}o\\x85I\\x058\\x0Cwaita\\x979\\x82\\x004!\\xF9\t\\x01\\x18254942,\t*\\x10cache\\x1D(\\x000\r\\x18\\x08dnsJ\\x16\\x00\\x14connec\\xA5R\\x19[\\x113\\x18request\\x1D\\x1A\\x10949.6\tu\\x009\\x05w ,\"performa\\xF8\\x14.activ\\x85l\\x81\\xF3\\x00r\\xA9\\xF1\\x00v\\xC1?\\x00s\\x01K(nce_number\"A\\xE7\\x05\\x19\\x08preM:)\\xE8X0,\"characteristics.has_\\x01,"
		"\\x1C_summary\\x91Z\\x10navig\\x05n\\xC1\\xC8\\x01r\\xA5e\\x04ex\\x018\\x0Cng\",2\"\\x00\\x04yp\\xA1\\x82\\x08hara\\x8F.\\xB5\\x00\\x01x\\x18_origina>079551988803,\"2\\x86\\x036\\x1B\\x009/D7366,\"dt.rum.schem\\xFD\\xAD\\x18\"0.23.0\\x81\\xAE\t!\\x14applic\t\\xB7\\x04id\\xE1r@a7c4b59f27d43eb\",\\xF5\\x9F\\x10frame:\\xA1\\x07853ca36aa50846a8\\x01\\xCE\\x11Z\\x00g\\xA1a\"'\\x08\\\\\"1.337.9.20260504-112723\\x1D\\x8B\\x051-\\x1A$javascript\\x19!\\x00b\\x1A'\\x08\\x00s\\x05\\xA9|"
		"D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-=\\x16\\x00i\\x1A\\x85\\x08)\\x131k\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[<\":\"landscape-priE8\\x04,\"\r)8battery.level\":\\xA1A\r\\x1A$screen.wid\\xC1\\x88\\x08153!\\xDA\t^\r\\x1B(height\":9609\\xA9\\x14window67\\x001=\r\\x1C\\x118\\x008a\\xAA:\\x1C\\x00\tb\\x1C_pixel_r\\x01\\xC1P\":1.25,\"page.url.full\\x8A\\xCD\\x05\\x00ae\\xCC\\x04s/\\xED\\x11e\\x92@on?viewProduct=&p\t\t$Id=FI-FW-0"
		"!\\xBA\\x05i1\\x86\\x00_%\\xF0Jj\\x02\\x05&\\x1Cdetected\\xF1\\xC8\\xDDLV\\x7F\\x00\\x00\"\r\\xC8\\x08tit\\x0E\\x18\\x08\\x14\"JPetS\\xC1|\\x14 Demo\"\\x1AF\n6}\\x00<2bbff043c8cea5c0\\x11&\\xFE\\x0C\\x01\\x8E\\x0C\\x01!.\\xCA\\xE6\\x00\\x04},\\xFEy\\x0B:y\\x0B%n&\\xB8\\x0B\\xAD\""
		"\\x16y\\x0B\\x05\\x1C\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0B\\xFEy\\x0Bvy\\x0BNH\\x0B\\xC17\\x00_"
		":H\\x0B\\x01\\x14N\\x88\\x0B\\xFE`\\x0B\\xFE`\\x0B*`\\x0B\\x007\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\xFE`\\x0B\\x12`\\x0B\\x08]}}", 
		LAST);

	web_add_cookie("rxvtf4o018pw=1779553796275|1779551938632; DOMAIN=localhost");

	web_add_cookie("dtPCf4o018pw=4$551996214_261h-vHHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0e0; DOMAIN=localhost");

	web_custom_request("rb_bf32608msb_26", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=2488562829&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewItem=&itemId=EST-20", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CEST-20%7CC%7C-%7C551989795_778%7C1779551995579%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02%7C%7C%7C%2Fjpetstore%2Factions%2FCatalog.action%7C1779551988803%2C1%7C1%7C_load_%7C_load_%7C-%7C1779551995583%7C1779551996278%7Cdn%7C78%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewProduct%3D%26productId%3DFI-FW-02%2C2%7C3%7C_ev"
		"ent_%7C1779551995583%7C_vc_%7CV%7C678%5Epc%7CVCD%7C1031%7CVCDS%7C2%7CVCS%7C762%7CVCO%7C1785%7CVCI%7C0%7CTS%7C1%7CVE%7C491%5Ep380%5Ep67947%5Eps%5Es%23Banner%7CS%7C675%2C2%7C4%7C_event_%7C1779551995583%7C_wv_%7ClcpT%7C-5%7Cfcp%7C-6%7Cfp%7C-6%7Ccls%7C0%7Clt%7C60%2C2%7C2%7C_onload_%7C_load_%7C-%7C1779551996278%7C1779551996278%7Cdn%7C78%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C5%7C_event_%7C1779551995583%7C_view_%7Csvn%7C%2Fjpetstore%2Factions%2FCatalog.action%7Csvt%7"
		"C1779551988803%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$dO=localhost,$rId=RID_-853543835$rpId=-402246853$domR=1779551996274$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551995583$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$nt=a0b1779551995583e9f9g9h9i9k11l575m576o678p678q681r691s695t695u4655v4355w4355M-402246853V0$ni=4g|1.6$egf=1589PRTUX$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewItem%3D%26itemId%3DEST-20$title="
		"JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551996214_261$v=10337260504112723$vID=1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewItem%3D%26itemId%3DEST-20$time=1779551997383", 
		LAST);

	web_custom_request("rb_bf32608msb_27", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?sc=5&ty=js&pv=4&ai=ea7c4b59f27d43eb&en=f4o018pw&cr=1779531483296&av=1.337.9&cy=event&bc=902152733&co=snappy&si=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&st=1779551998298&ss=0&qc=3421673107&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewItem=&itemId=EST-20", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=\\xF1\\xE9\\x01D{\"data_version\":2,\\x05\\x11\\xF4,\\x01\":{\"updates\":{},\"events\":[{\"visibility.state\":\"foreground\",\"browser.tab.instance_id\":\"ed681ae559437672\",\"start_time\":1779551996183,\"duration\":0,\"performance.initiator_type\":\"link\",\"characteristics.has_request\":true,\"url.full\":\"http://localhost:8080/jpetstore/css/jpetstore.css\",\"network.protocol.name\"\tL\\x08\",\".\\xA5\\x00(time_origin\\x1D\\xDAD5583,\"dt.rum.schem=|\\x18\"0.23.0:I\\x00\\x00s=\""
		"\\x14600.69\r\\x01\\x0C25496t\\x00(next_hop_pr\t\\xA0\\x08\":\":N\\x004domain_lookup_\\x05\\\\\\x00\"~W\\x0064\\x00\\x08end\\x822\\x00\\x18connect\\x9A`\\x00\\x11.\\x8EZ\\x00\\x18secure_\r3\\x08ion\\x11d\\x0006\\x0B\\x01-\\xF8b\\x1E\\x00\\x14sponse~\\x1F\\x00\\x8E\\x92\\x00\\x10redir\\x1D\\xEDB\\x89\\x00\r\\x1F\\x05L:\\x1D\\x00\\x14workerZ\\x86\\x00\\x10fetch\\x11\\x1Cz\\xFA\\x018render_blocking\\x016\\x14tus\":\"\\x11\\x12:\\x07\\x02\\x14transf\\x01{\\x0Cize\">\\x97\\x000encoded_body_\t\""
		"\\x0C60146b\\x01\\x04deZ%\\x00-{(.server_tim\\x01\\x92@hint\":\"received\",\\x15(\\x0Ctrac%\\xD2\\x00tE\\xBF\t(\\x10from_\tB\\x08\",\"\\x05#\\x00.\\x85D|6343452934a6cc116081301249311005\\x19.$s_sampled\"m\\xFDN \\x04,w3c_resource\r\\xAB\\x00s\\x110m\\xA7\\x18applicaAm\t\\x83<ea7c4b59f27d43eb\\x9D\\xF4\\x10frame>\\xF6\\x0403677c536b3fec\\x85\\xF6\\x11Z\\x10gent.\\xB5|`\"1.337.9.20260504-112723\"\\x952\t1\\x04ty\\x85\\xF6$javascript\\x19!\\x00b\\xAD|\\x00s%,|D456F9D9707C4F014CD0FFC5C4A12D92\\x198\t"
		"0\\x80HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-\\x81\\x9C\r\\xBC\\x00i\\xAD\\xDA)\\x13\\x001\\xAD\\xBB\\x9038630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM\\x01w,evice.orient%[L\":\"landscape-primary\\x19)Lscreen.width\":1536,\"\rD\r\\x1B,height\":960,\\xD5\\x83\\x14window67\\x001#\r\\x1C\\x118\\x08842B8\\x00\tb\\x1C_pixel_r\\x01\\xA74\":1.25,\"page.u\\xA6M\\x06\\x04acA?$s/Catalog.\t\\x10X?viewItem=&itemId=EST-2!f\\x05a1d\\x00_%\\xCEJH\\x02\\x05&$detected_n\\xC9\\x8D\\x00/\\xD9\\xC4\tg"
		">w\\x00\\x81\\x0C\\x01\\xC0\\x0Ctitl\\xE1\\xBE@JPetStore Demo\",\"\\x01\\x97:}\\x00<a6e24e91e7614c96\\x11&\\xFE\\x04\\x01n\\x04\\x01\\x05\\x87\\xC6\\xDE\\x00\\x04},\\xFE\\xA4\\x08\\x9A\\xA4\\x08\\x004\\xAE\\xA4\\x08u\\xAAN\\x86\\x04\\xAD3\\x91y\\xAAU\\x01\\x10ruxit\\x85\\x17pjs_ICA15789NPRTUVXfqrux_10337\\x89P\\x89O\\x0C.js\"\\xFE\\xCB\\x08\\xFE\\xCB\\x08\\x0E\\xCB\\x08\\x0016P\\x06\\xE6\\xBD\\x08:I\\x00R\\xAF\\x08:$\\x00\\x1A@\\x08\\xE1(\\x04rt\\x0E\\xCF\\x08Z \\x00\\xE5\\xB5\\x006"
		">\\x1E\\x00\\xFE\\x85\\x08\\xD2\\x85\\x08:\\xA2\\x00\\xFEw\\x08\\x9Ew\\x08Bw\\x00\\xFEi\\x08zi\\x08\\x1013290\\x86k\\x08\\x0C3621\\x0E\\xFF\nm:Vm\\x08@not_available_htt\\x0E\\xA5\\x0B\\x112\\x12T\\x08\\x0EI\n.w\\x08\\x012\\x04se\\xE1QN\\xA7\\x03\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xFE-\\x08\\xA2-\\x08\\x04im\\x0E\\xB1\rN\\x83\\x04\\x8D\\xBE\\xCA*\\x08Timages/"
		"logo-topbar.gif\\xFE\n\\x08\\xFE\n\\x08\\x16\n\\x08\\x08.10\t\\x01\\x08149>r\\x06\\xEA\\x18\\x08nW\\x00V&\\x08n2\\x00F4\\x08\\x8E.\\x00\\x1EB\\x08n,\\x00\\xFEP\\x08\\xD6P\\x08n\\x92\\x00\\xFE^\\x08\\xA2^\\x08v\\x85\\x00Zl\\x08\\x0Cnon-\\xFE\\xD9\\x10\\x1E\\xD9\\x10\\x0C38086\\x89\nJ\\xD9\\x10\t%m|"
		"Vl\\x08\\xEE\\xD9\\x10\\x12\\xD9\\x10x3881223f689a154f0643b8963dcd5a3\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10\\xFE\\xD9\\x10b\\xD9\\x10\\xFE\\xAC\\x08j\\xAC\\x08\\x0Ccart\\xFE\\xA5\\x08\\xFE\\xA5\\x08.\\xA5\\x08\\x1Ay\\x19\\x009\\xFEz\\x19.z\\x19\\x041.jW\\x00^"
		"\\xA5\\x08f\\x89\\x00N\\xA5\\x08\\x86.\\x00&\\xA5\\x08f,\\x00\\xFE\\xA5\\x08\\xDE\\xA5\\x08f\\x92\\x00\\xFE\\xA5\\x08\\xAA\\xA5\\x08n\\x85\\x00\\xFE\\xA5\\x08\\x8A\\xA5\\x08\\x0496\\x82\\xA3\\x08\\x01#\\xFE\\xA1\\x08v\\xA1\\x08|570492c08c75f09b297394998fb21c09\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19\\xFEz\\x19^"
		"z\\x19\\xFE\\xA1\\x08j\\xA1\\x08\\x1Cseparato\\xFEK\\x11\\xFEK\\x112K\\x11f\\xAC\\x06\\xF2K\\x11fW\\x00\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\x1E\\xA6\\x08\\x004\\x86\\xA6\\x08\\x01#\\xFE\\xA6\\x08v\\xA6\\x08|"
		"348f55f2a3c0905ed28d9435f9189a91\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xCE\\xA6\\x08\\x14m_fish\\xFEJ\\x11\\xFEJ\\x11*J\\x11\\x004\\x16\\xEE\\x19\\x140223526\\xDB\\x0E\\xEE\\xA4\\x08jW\\x00Z\\xA4\\x08j2\\x00JJ\\x11\\x8A.\\x00\"J\\x11j,"
		"\\x00\\xFEJ\\x11\\xDAJ\\x11j\\x92\\x00\\xFEJ\\x11\\xA6J\\x11r\\x85\\x00\\xFEJ\\x11\\x8AJ\\x11\\x0427:\\xD1\"J\\xEE\\x19\\x05$\\xFE\\xA6\\x08v\\xA6\\x08x060253210f8790b19f045d76c7a6383\\x0E_'\\x12\\xA0\"\\x00.\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*\\xFE\\xC6*"
		":\\xC6*\\xFEL\\x11nL\\x11\\x14m_dogs\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\x12\\xA6\\x08\\x0430\\x86K\\x11\\x05$\\xFE\\xA6\\x08v\\xA6\\x08x78c4449186f15ce3a8d1129d5513f44\\x0E=&"
		"\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xCA\\xA6\\x08\\x18reptile\\xFE\\xAA\\x08\\xFE\\xAA\\x08.\\xAA\\x08\\x006\\x1AP\\x11\\xFE?+:?+jW\\x00ZP\\x11j2\\x00JP\\x11\\x8A.\\x00\"P\\x11j,"
		"\\x00\\xFEP\\x11\\xDAP\\x11j\\x92\\x00\\xFEP\\x11\\xA6P\\x11r\\x85\\x00\\xFEP\\x11\\x8AP\\x11\\x0439\\x8A>+"
		"\\x01$\\xFE\\xAA\\x08z\\xAA\\x08x10e236f5ffa28765b140d44712ee9b4\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xFE\\xF6\\x19\\xD6\\xF6\\x19\\x08cat\\xFE\\xA6\\x08\\xFE\\xA6\\x082\\xA6\\x08fC\"\\xEE\\xF6\\x19jW\\x00^\\xA6\\x08f\\x89\\x00N\\xA6\\x08\\x86.\\x00&\\xA6\\x08f,"
		"\\x00\\xFE\\xA6\\x08\\xDE\\xA6\\x08f\\x92\\x00\\xFE\\xA6\\x08\\xAA\\xA6\\x08n\\x85\\x00\\xFE\\xA6\\x08\\x8A\\xA6\\x08\\x0428:*GN\\xF6\\x19\\x01$\\xFE\\xA6\\x08v\\xA6\\x08|"
		"99b04d0d3be1cf52ac7ae8a395db1efa\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xFE\\xA6\\x08\\xD6\\xA6\\x08\\x0Cbird\\xFE\\xA7\\x08\\xFE\\xA7\\x08.\\xA7\\x08\\x008\\x1AM\\x11\\x0C0745:- \\xEE\\xA7\\x08jW\\x00Z\\xA7\\x08j2\\x00J\\xA7\\x08\\x8A.\\x00\"\\xA7\\x08j,"
		"\\x00\\xFE\\xA7\\x08\\xDA\\xA7\\x08j\\x92\\x00\\xFE\\xA7\\x08\\xA6\\xA7\\x08r\\x85\\x00\\xFE\\xA7\\x08\\x8E\\xA7\\x08>p\\x02N\\xA7\\x08\\x01$\\xFE\\xA7\\x08z\\xA7\\x08t816f19d7e450737bad8f89b94aa411\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93\\xFE\\xE93N\\xE93>\\xEBD\\x0E\\xF7&"
		"4elf_monitoring\\x1E\\xF2DJ*\\x00\\x1Cinternal\\x11#\\x12\\xD6T\\x0E\\xCDQ\\x00e*zU\\x0462\\x0E\\xE1O\\x00d.TV\\x1A\\xCAPf\\x87U\\x11!\\x08fm_*\\x00W timestamp2^\\x00\\x0C29,\"\\x0E\\x11S4\":2000,\"messag\\x0E_O\\x12\\x1CQ\\x1C31483296\\x12\\x9EN\\x8AB\\x00\\x003.B\\x00\\x18[\\\\\"OneA\\x0E.R\\x14 JavaS\\x12\\xF6Q0 tag\\\\\",[]]\"}]&"
		"#R\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER\\xFE\\xAER>!\\x05\\x0E\\x06[ long_taskv#\\x05\\x08187.\\xD3R\\x0EJU\\xB1\\x03b\\xABZ\\x15[\\x00.\\x1A\\x7FT\\xA1\\xB8\\x04\",\\x1D\\x18\\x18attribu\\x0E\\x01U\\x0E\\xB8\\x0C\\x14tainer\\x16\\xD3T\\x8A(\\x00\rV\\x8A*\\x00\\x08src\\x16\\xF0Z\\x19\\x93V{\\x00\\x1A@W\\x16\\x01VbY\\x00\r"
		"y\\x14unknow\\x0E4U-\\x0B\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xFEa\\x05\\xEEa\\x05\\xA5aZ_\n\\xA5.._\n.\\x0E`B\\xB3`\\xFEI-jI-\\x0E\\xEC5\\x002\\xFEG-\\xFEG-\\x1EG-\\x0877.\\x0E/[\\x04er\"\\xBEaND\\x13\\x0E\\x9BU\\x08/1.\\x0E\\x9D;.+\\x006\\x18\\x13%x\\x04\":JS\\x006(\\x00\\x16\\xE6\\x12Fy\\x00>4\\x13f\"\\x00^"
		"B\\x00\\xFE\\x1C\\x13\\xCE\\x1C\\x13F\\xA6\\x00\\xFE\\x10\\x13\\x9A\\x10\\x13Ny\\x00\\xFE\\x04\\x13\\x8A\\x04\\x13\\x0C1331:2\\x02J\\x06\\x13\r&\\xFE\\x08\\x13v\\x08\\x13x5fa89d3b0ed5004080ef907d1e2ae19\\xFE\\x92O\\xFE\\x92O\\xFE\\x92O\\xFE\\x92O\\xFE\\x92O\\xFE\\x92O\\xFE\\x92OZ\\x92O@battery.level\":99>j`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`\\xFE\\x85`*\\x85`\\x005\\x16Oh\""
		"v\\x08\\x08694n\\xC5\\x18B\\x86\\x08\\x10navig\\x0E\\xD8b\\x0E\\xE0\\x0CN9\\x0E\\xADa\\x1E7\\x0E\\xAA\\x99`V{bj\\xF2b\\x04ne\\xFE\\\\i\\xF6\\\\i\\x000\\x86\\x88>\\xAE\\xA7\\x08\\x089.3*H\\x1C\\x0405>'+2\\x88i\\x12q\\x08z2\\x00:\\xBF\\x08\\x9A.\\x00\\x8EZ\\x00\\xDA\\xD7\\x08\\x001:\\x1D\\x1D\\x00r:Ui\\x08575n\\xDCP\\x15/\\x05\\xA3\\x08576v\\x1C>\\x1AFi\\x1A\\x05\n:\\xAD\\x01\"\\x13\t\\x05L:\\x1D\\x00\\xA6eizT\\x01\\xFAei\\x08465:\\xD9\\x08Jhi\\x0443>%\\x00J\\xFE\\x08\t"
		"%m\\x9C\\xFE\\x8FXZ\\x8FXx540693103ac8ed92ed19b81b0223c72n\\x05\\x1C\\x12]f\\x04so\\x0ESi\\xFE f\\x1A f$Product=&p\t\t$Id=FI-FW-0\\x0E\\xC4hN\\xB9\\x04\\x0E\\xABa\\x99\\xDE\\x0E\r\\x18\\x04in&\\xDAiN2\\x00\\x19.\\x91\\xEE.\\x8B\\x0C\\x1A4\\x12\r%\\x00e\\x0ECg*\\xD4\\x0C\\x14unload\\x16%\\x18Z\\xA3\\x022#\\x00N\\xA7\\x02\\x08dom\\x16\\xCA\\x18\\xA1:\\x08ve\"\\x12\\xE9\\x0Cj\\x92\\x1E\\x010\\x1Ccontent_\\x01~\\x00e:\\x80\\x00\\x08678nR\\x03b?\\x00\\x05\\x9C\\x0468:\\xDD\\x03\t/"
		"\\x0EOk\\x00t\\x01\\x9B\\x0C90.9\\x8D\\xDFJ\\xC4C\\x01\\x8F6\r\\x01\\xC1\\x99j\\x05(\\x1D1\t\\x7Fv\\xC8\\x06u\\xEF\\x08cou\\x0EVl\\x040,1\\x99\\x08ion1\\xAB\\x08har\\x0Efl-\\xB2\\x05\\x19\\x04ab!\\x9D\\x01\\xC1\\x08\"ex\\x0E%p\\x04ng\\x1E\\xC8h\\x10seque\\x0E\\xA9p number\""
		":1\\xFER\\x19\\xFER\\x19\\xFER\\x19\\xFER\\x19\\xFER\\x19\\xFER\\x192R\\x19\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\xFE\\x95\\x0B\\x1A\\x95\\x0B\\x08]}}", 
		LAST);

	web_custom_request("rb_bf32608msb_28", 
		"URL=http://localhost:8080/jpetstore/rb_bf32608msb?type=js3&sn=v_4_srv_4_sn_D456F9D9707C4F014CD0FFC5C4A12D92_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_1&svrid=4&flavor=post&vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0&modifiedSince=1779531483296&bp=3&app=ea7c4b59f27d43eb&crc=509419014&en=f4o018pw&end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://localhost:8080/jpetstore/actions/Catalog.action?viewItem=&itemId=EST-20", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$tvn=%2Fjpetstore%2Factions%2FCatalog.action$tvt=1779551995583$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1536$h=842$sw=1536$sh=960$ni=4g|1.6$egf=1589PRTUX$rt="
		"1-1779551995583%3Bhttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fcss%2Fjpetstore.css%7Cb601e0f0g0h0i0m0v6014w6014I11M-68001081V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Flogo-topbar.gif%7Cb601e0f0g0h0i0m0v3808w3808E1F17220O287P60I7M761912964V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fcart.gif%7Cb601e0f0g0h0i0m0v96w96E1F288O16P18I7M-1891668168V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fseparator.gif%7Cb601e0f0g0h0i0m0v46w46F18N2O1P18I7M688934799V0%7Chttp%3A%2F"
		"%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Ffish.gif%7Cb601e0f0g0h0i0m0v271w271E1F390O26P15I7M-302972535V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fdogs.gif%7Cb601e0f0g0h0i0m0v306w306E1F450O30P15I7M1822807848V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Freptiles.gif%7Cb602e0f0g0h0i0m0v398w398E1F780O52P15I7M-620539332V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fcats.gif%7Cb602e0f0g0h0i0m0v289w289E1F420O28P15I7M1231591079V0%7Chttp%3A%2F%2Floc"
		"alhost%3A8080%2Fjpetstore%2Fimages%2Fsm_5Fbirds.gif%7Cb602e0f0g0h0i0m0v251w251E1F495O33P15I7M-1591609649V0%7Chttp%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Fimages%2Ffish2.gif%7Cb678e0f0g0h0i0m0v13315w13315E1F15625O125P125I7M1866378948V0$url=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewItem%3D%26itemId%3DEST-20$title=JPetStore%20Demo$latC=0$app=ea7c4b59f27d43eb$vi=HHFIMBUJAUHURMNBNIWELHPRKUOHJFAN-0$fId=551996214_261$v=10337260504112723$vID="
		"1779551938630BL43GI64CTTIHTJ7KCQJB8ODUK03QNKM$rf=http%3A%2F%2Flocalhost%3A8080%2Fjpetstore%2Factions%2FCatalog.action%3FviewItem%3D%26itemId%3DEST-20$time=1779551999399", 
		LAST);

	lr_end_transaction("Search_Transaction",LR_AUTO);

	return 0;
}